import 'dart:async';
import 'dart:io';
import 'package:crypto/crypto.dart';
import 'package:flutter/material.dart';
import 'package:path/path.dart' as p;
import 'package:permission_handler/permission_handler.dart';

void main() {
  runApp(const FileAiApp());
}

class FileAiApp extends StatelessWidget {
  const FileAiApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'File AI Assistant',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF2563EB)),
        useMaterial3: true,
      ),
      home: const HomePage(),
    );
  }
}

class FileItem {
  final File file;
  final int size;
  String? sha256;
  FileItem(this.file, this.size);
}

class Finding {
  final String type;
  final String reason;
  final double confidence;
  final List<FileItem> files;
  Finding(this.type, this.reason, this.confidence, this.files);
}

class RenameSuggestion {
  final FileItem item;
  final String newName;
  final double confidence;
  bool selected;
  RenameSuggestion(this.item, this.newName, this.confidence, this.selected);
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final folderController = TextEditingController(text: '/storage/emulated/0/Download');
  final commandController = TextEditingController();
  List<FileItem> files = [];
  List<Finding> findings = [];
  bool busy = false;
  double progress = 0;
  String status = 'Choisis ou indique un dossier Android puis lance le scan.';

  @override
  void dispose() {
    folderController.dispose();
    commandController.dispose();
    super.dispose();
  }

  Future<bool> _requestStorageAccess() async {
    if (!Platform.isAndroid) return true;

    // Android 10: READ/WRITE_EXTERNAL_STORAGE + legacy external storage.
    final status = await Permission.storage.request();
    if (status.isGranted) return true;

    if (status.isPermanentlyDenied) {
      await openAppSettings();
    }
    return false;
  }

  Future<void> scanFolder() async {
    final allowed = await _requestStorageAccess();
    if (!allowed) {
      setState(() {
        status = 'Autorisation de stockage refusée. Autorise Fichiers et contenus multimédias dans les paramètres Android.';
      });
      await openAppSettings();
      return;
    }

    final root = Directory(folderController.text.trim());
    if (!await root.exists()) {
      setState(() => status = 'Dossier introuvable : ${root.path}');
      return;
    }

    setState(() {
      busy = true;
      progress = 0;
      files = [];
      findings = [];
      status = 'Scan en cours...';
    });

    final collected = <FileItem>[];
    try {
      int count = 0;
      await for (final entity in root.list(recursive: true, followLinks: false)) {
        if (entity is File) {
          try {
            if (entity.path.contains('/_FileAI_Quarantine/')) continue;
            final stat = await entity.stat();
            collected.add(FileItem(entity, stat.size));
            count++;
            if (count % 25 == 0 && mounted) {
              setState(() {
                progress = (progress + .01).clamp(0.0, 0.85).toDouble();
                status = '$count fichiers trouvés...';
              });
            }
          } catch (_) {}
        }
      }
      setState(() {
        files = collected;
        busy = false;
        progress = 1;
        status = '${files.length} fichiers trouvés.';
      });
    } catch (e) {
      setState(() {
        busy = false;
        status = 'Erreur de scan : $e';
      });
    }
  }

  Future<String> hashFile(File file) async {
    final digest = await sha256.bind(file.openRead()).first;
    return digest.toString();
  }

  Future<void> findExactDuplicates() async {
    if (files.isEmpty) {
      return _needScan();
    }
    setState(() { busy = true; progress = 0; status = 'Calcul des empreintes SHA-256...'; });

    final groups = <String, List<FileItem>>{};
    for (int i = 0; i < files.length; i++) {
      final item = files[i];
      try {
        item.sha256 ??= await hashFile(item.file);
        final key = '${item.size}:${item.sha256}';
        groups.putIfAbsent(key, () => []).add(item);
      } catch (_) {}
      if (mounted && i % 5 == 0) {
        setState(() => progress = (i + 1) / files.length);
      }
    }

    final result = <Finding>[];
    for (final g in groups.values) {
      if (g.length > 1) {
        result.add(Finding(
          'Doublon exact',
          'Même taille et même empreinte SHA-256',
          1,
          g,
        ));
      }
    }
    setState(() {
      findings = result;
      busy = false;
      progress = 1;
      status = '${result.length} groupe(s) de doublons exacts.';
    });
  }

  int levenshtein(String a, String b) {
    a = a.toLowerCase();
    b = b.toLowerCase();
    if (a.isEmpty) return b.length;
    if (b.isEmpty) return a.length;
    final prev = List<int>.generate(b.length + 1, (i) => i);
    final curr = List<int>.filled(b.length + 1, 0);
    for (int i = 1; i <= a.length; i++) {
      curr[0] = i;
      for (int j = 1; j <= b.length; j++) {
        final cost = a[i - 1] == b[j - 1] ? 0 : 1;
        curr[j] = [
          curr[j - 1] + 1,
          prev[j] + 1,
          prev[j - 1] + cost
        ].reduce((x, y) => x < y ? x : y);
      }
      for (int j = 0; j <= b.length; j++) {
        prev[j] = curr[j];
      }
    }
    return prev[b.length];
  }

  double nameSimilarity(String a, String b) {
    final aa = p.basenameWithoutExtension(a);
    final bb = p.basenameWithoutExtension(b);
    final maxLen = aa.length > bb.length ? aa.length : bb.length;
    if (maxLen == 0) return 1;
    return 1 - (levenshtein(aa, bb) / maxLen);
  }

  Future<void> findSimilarNames() async {
    if (files.isEmpty) {
      return _needScan();
    }
    setState(() { busy = true; status = 'Comparaison des noms...'; progress = 0; });
    final result = <Finding>[];

    for (int i = 0; i < files.length; i++) {
      final a = files[i];
      for (int j = i + 1; j < files.length && j < i + 80; j++) {
        final b = files[j];
        if (p.extension(a.file.path).toLowerCase() != p.extension(b.file.path).toLowerCase()) continue;
        final sim = nameSimilarity(p.basename(a.file.path), p.basename(b.file.path));
        if (sim >= .82) {
          result.add(Finding(
            'Nom similaire',
            'Noms proches à ${(sim * 100).toStringAsFixed(0)} %',
            sim,
            [a, b],
          ));
        }
      }
      if (mounted && i % 10 == 0) {
        setState(() => progress = (i + 1) / files.length);
      }
    }

    setState(() {
      findings = result;
      busy = false;
      progress = 1;
      status = '${result.length} paire(s) avec noms similaires.';
    });
  }

  Future<void> findSimilarSizes() async {
    if (files.isEmpty) {
      return _needScan();
    }
    final ordered = [...files]..sort((a, b) => a.size.compareTo(b.size));
    final result = <Finding>[];
    for (int i = 0; i < ordered.length; i++) {
      final a = ordered[i];
      for (int j = i + 1; j < ordered.length && j < i + 30; j++) {
        final b = ordered[j];
        final maxSize = a.size > b.size ? a.size : b.size;
        if (maxSize == 0) continue;
        final diff = (a.size - b.size).abs() / maxSize;
        if (diff <= .03) {
          result.add(Finding(
            'Taille proche',
            'Écart de ${(diff * 100).toStringAsFixed(2)} %',
            1 - diff,
            [a, b],
          ));
        } else if (b.size > a.size * 1.03) {
          break;
        }
      }
    }
    setState(() {
      findings = result;
      status = '${result.length} paire(s) avec tailles proches.';
    });
  }

  List<String> _tokens(String stem) {
    final cleaned = stem.replaceAll(RegExp(r'[_\-.]+'), ' ');
    return cleaned.split(RegExp(r'\s+')).where((e) => e.trim().length > 1).toList();
  }

  String dominantTitle() {
    final stop = {
      'scan','vf','fr','gratuit','free','final','copie','copy','chapter',
      'chapitre','chap','ch','partie','part','pt','volume','vol','tome'
    };
    final counts = <String, int>{};
    for (final item in files) {
      for (final t in _tokens(p.basenameWithoutExtension(item.file.path))) {
        final low = t.toLowerCase();
        if (stop.contains(low) || int.tryParse(low) != null) continue;
        counts[low] = (counts[low] ?? 0) + 1;
      }
    }
    if (counts.isEmpty) return 'Fichier';
    final threshold = files.length < 5 ? 2 : (files.length * .35).floor();
    final common = counts.entries.where((e) => e.value >= threshold).map((e) => e.key).toSet();

    for (final item in files) {
      final chosen = _tokens(p.basenameWithoutExtension(item.file.path))
          .where((t) => common.contains(t.toLowerCase()))
          .take(6)
          .toList();
      if (chosen.isNotEmpty) {
        return chosen.map((e) => e[0].toUpperCase() + e.substring(1)).join('_');
      }
    }
    final best = counts.entries.reduce((a, b) => a.value >= b.value ? a : b);
    return best.key;
  }

  int? extractNumber(String stem, List<RegExp> patterns) {
    for (final rx in patterns) {
      final m = rx.firstMatch(stem);
      if (m != null) return int.tryParse(m.group(1)!);
    }
    return null;
  }

  List<RenameSuggestion> buildRenameSuggestions() {
    final title = dominantTitle();
    final ordered = [...files]..sort((a,b) => p.basename(a.file.path).compareTo(p.basename(b.file.path)));
    final out = <RenameSuggestion>[];

    final chapterPatterns = [
      RegExp(r'(?:chapitre|chapter|chap|ch)[ _.-]*(\d{1,4})', caseSensitive: false),
    ];
    final partPatterns = [
      RegExp(r'(?:partie|part|pt)[ _.-]*(\d{1,3})', caseSensitive: false),
    ];
    final volumePatterns = [
      RegExp(r'(?:volume|vol|tome)[ _.-]*(\d{1,3})', caseSensitive: false),
    ];

    for (int i = 0; i < ordered.length; i++) {
      final item = ordered[i];
      final stem = p.basenameWithoutExtension(item.file.path);
      final ext = p.extension(item.file.path);
      final chapter = extractNumber(stem, chapterPatterns);
      final part = extractNumber(stem, partPatterns);
      final volume = extractNumber(stem, volumePatterns);

      double conf = .45;
      final parts = <String>[title];
      if (volume != null) { parts.add('Tome_${volume.toString().padLeft(2, '0')}'); conf += .10; }
      if (chapter != null) { parts.add('Chapitre_${chapter.toString().padLeft(3, '0')}'); conf += .30; }
      if (part != null) { parts.add('Partie_${part.toString().padLeft(2, '0')}'); conf += .15; }

      if (chapter == null && part == null && volume == null) {
        parts.add((i + 1).toString().padLeft(3, '0'));
        conf = .65;
      }
      if (conf > .99) conf = .99;
      out.add(RenameSuggestion(item, '${parts.join('_')}$ext', conf, conf >= .75));
    }
    return out;
  }

  Future<void> showRenameSuggestions() async {
    if (files.isEmpty) {
      return _needScan();
    }
    final suggestions = buildRenameSuggestions();

    await showDialog(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setLocal) => AlertDialog(
          title: const Text('Suggestions de renommage'),
          content: SizedBox(
            width: double.maxFinite,
            height: 520,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('Aucun fichier ne sera renommé sans validation.'),
                const SizedBox(height: 10),
                Expanded(
                  child: ListView.builder(
                    itemCount: suggestions.length,
                    itemBuilder: (_, i) {
                      final s = suggestions[i];
                      return CheckboxListTile(
                        value: s.selected,
                        onChanged: (v) => setLocal(() => s.selected = v ?? false),
                        title: Text(p.basename(s.item.file.path)),
                        subtitle: Text(
                          '→ ${s.newName}\nConfiance ${(s.confidence * 100).toStringAsFixed(0)} %'
                        ),
                        isThreeLine: true,
                      );
                    },
                  ),
                ),
              ],
            ),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Annuler')),
            FilledButton(
              onPressed: () async {
                Navigator.pop(ctx);
                await applyRenameSuggestions(suggestions.where((s) => s.selected).toList());
              },
              child: const Text('Appliquer la sélection'),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> applyRenameSuggestions(List<RenameSuggestion> selected) async {
    if (selected.isEmpty) return;
    int done = 0;
    for (final s in selected) {
      try {
        final src = s.item.file;
        var destPath = p.join(p.dirname(src.path), s.newName);
        int n = 2;
        while (await File(destPath).exists() && destPath != src.path) {
          final ext = p.extension(s.newName);
          final stem = p.basenameWithoutExtension(s.newName);
          destPath = p.join(p.dirname(src.path), '${stem}_${n.toString().padLeft(3,'0')}$ext');
          n++;
        }
        if (destPath != src.path) {
          await src.rename(destPath);
          done++;
        }
      } catch (_) {}
    }
    setState(() => status = '$done fichier(s) renommé(s).');
    await scanFolder();
  }

  Future<void> quarantineDuplicates() async {
    if (findings.isEmpty) return;
    final root = Directory(folderController.text.trim());
    final q = Directory(p.join(root.path, '_FileAI_Quarantine'));
    await q.create(recursive: true);
    int moved = 0;

    for (final f in findings.where((x) => x.type == 'Doublon exact')) {
      for (final item in f.files.skip(1)) {
        try {
          var dest = p.join(q.path, p.basename(item.file.path));
          int n = 2;
          while (await File(dest).exists()) {
            final ext = p.extension(dest);
            final stem = p.basenameWithoutExtension(dest);
            dest = p.join(q.path, '${stem}_${n.toString().padLeft(3,'0')}$ext');
            n++;
          }
          await item.file.rename(dest);
          moved++;
        } catch (_) {}
      }
    }

    setState(() => status = '$moved doublon(s) déplacé(s) en quarantaine.');
    await scanFolder();
  }

  Future<void> runCommand() async {
    final text = commandController.text.trim().toLowerCase();
    if (text.isEmpty) {
      return;
    }

    if (text.contains('renomm') || text.contains('uniform') || text.contains('normalis')) {
      setState(() => status = 'Je propose d’abord les nouveaux noms avant toute modification.');
      await showRenameSuggestions();
      return;
    }
    if (text.contains('doublon') || text.contains('double') || text.contains('copie')) {
      await findExactDuplicates();
      return;
    }
    if (text.contains('nom') && (text.contains('simil') || text.contains('proche') || text.contains('sembl'))) {
      await findSimilarNames();
      return;
    }
    if (text.contains('taille') && (text.contains('simil') || text.contains('proche'))) {
      await findSimilarSizes();
      return;
    }
    if (text.contains('quarantaine')) {
      await quarantineDuplicates();
      return;
    }

    setState(() {
      status = 'Commande non reconnue. Essaie : trouve les doublons, noms similaires, tailles proches, ou uniformise les noms.';
    });
  }

  void _needScan() {
    setState(() => status = 'Scanne d’abord le dossier.');
  }

  String formatBytes(int bytes) {
    if (bytes >= 1024 * 1024 * 1024) return '${(bytes / (1024*1024*1024)).toStringAsFixed(2)} Go';
    if (bytes >= 1024 * 1024) return '${(bytes / (1024*1024)).toStringAsFixed(2)} Mo';
    if (bytes >= 1024) return '${(bytes / 1024).toStringAsFixed(1)} Ko';
    return '$bytes o';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('File AI Assistant'),
      ),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Column(
            children: [
              TextField(
                controller: folderController,
                decoration: InputDecoration(
                  labelText: 'Dossier Android',
                  hintText: '/storage/emulated/0/Download',
                  border: const OutlineInputBorder(),
                  suffixIcon: IconButton(
                    icon: const Icon(Icons.folder_open),
                    onPressed: () => setState(() {
                      status = 'Entre le chemin du dossier. Exemple : /storage/emulated/0/Download';
                    }),
                  ),
                ),
              ),
              const SizedBox(height: 10),
              Row(
                children: [
                  Expanded(
                    child: FilledButton.icon(
                      onPressed: busy ? null : scanFolder,
                      icon: const Icon(Icons.search),
                      label: const Text('Scanner le dossier'),
                    ),
                  ),
                ],
              ),
              if (busy) ...[
                const SizedBox(height: 8),
                LinearProgressIndicator(value: progress > 0 ? progress : null),
              ],
              const SizedBox(height: 10),
              TextField(
                controller: commandController,
                onSubmitted: (_) => runCommand(),
                decoration: InputDecoration(
                  labelText: 'Commande assistant',
                  hintText: 'Ex : uniformise les noms de ce dossier',
                  border: const OutlineInputBorder(),
                  suffixIcon: IconButton(
                    icon: const Icon(Icons.send),
                    onPressed: busy ? null : runCommand,
                  ),
                ),
              ),
              const SizedBox(height: 8),
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: Theme.of(context).colorScheme.surfaceContainerHighest,
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Text(status),
              ),
              const SizedBox(height: 8),
              Wrap(
                spacing: 6,
                runSpacing: 6,
                children: [
                  ActionChip(label: const Text('Doublons'), onPressed: busy ? null : findExactDuplicates),
                  ActionChip(label: const Text('Noms similaires'), onPressed: busy ? null : findSimilarNames),
                  ActionChip(label: const Text('Tailles proches'), onPressed: busy ? null : findSimilarSizes),
                  ActionChip(label: const Text('Suggérer renommage'), onPressed: busy ? null : showRenameSuggestions),
                  ActionChip(label: const Text('Quarantaine doublons'), onPressed: busy ? null : quarantineDuplicates),
                ],
              ),
              const Divider(),
              Expanded(
                child: findings.isNotEmpty
                    ? ListView.builder(
                        itemCount: findings.length,
                        itemBuilder: (_, i) {
                          final f = findings[i];
                          return Card(
                            child: ExpansionTile(
                              title: Text('${f.type} • ${(f.confidence * 100).toStringAsFixed(0)} %'),
                              subtitle: Text(f.reason),
                              children: f.files.map((x) => ListTile(
                                dense: true,
                                title: Text(p.basename(x.file.path)),
                                subtitle: Text('${formatBytes(x.size)}\n${x.file.path}'),
                              )).toList(),
                            ),
                          );
                        },
                      )
                    : ListView(
                        children: [
                          ListTile(
                            leading: const Icon(Icons.folder_copy_outlined),
                            title: Text('${files.length} fichiers scannés'),
                            subtitle: const Text('Les résultats d’analyse apparaîtront ici.'),
                          ),
                        ],
                      ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
