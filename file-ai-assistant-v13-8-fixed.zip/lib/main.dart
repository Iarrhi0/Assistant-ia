import 'dart:io';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'dart:typed_data';
import 'package:image/image.dart' as img;
import 'package:archive/archive_io.dart';
import 'package:archive/archive.dart';
import 'package:file_picker/file_picker.dart';
import 'package:pdfx/pdfx.dart';
import 'package:crypto/crypto.dart';
import 'package:flutter/material.dart';
import 'package:path/path.dart' as p;
import 'package:permission_handler/permission_handler.dart';


String normalizedFileName(String path) {
  var name = p.basenameWithoutExtension(path).toLowerCase();
  name = name.replaceAll(RegExp(r'[_\-.]+'), ' ');
  name = name.replaceAll(RegExp(r'\b(copy|copie|scan|vf|fr|gratuit|final|new)\b'), ' ');
  name = name.replaceAll(RegExp(r'\s+'), ' ').trim();
  return name;
}

double nameSimilarity(String a, String b) {
  final x = normalizedFileName(a);
  final y = normalizedFileName(b);
  if (x == y) return 1.0;
  if (x.isEmpty || y.isEmpty) return 0.0;

  final ax = x.split(' ').where((e) => e.length > 1).toSet();
  final by = y.split(' ').where((e) => e.length > 1).toSet();
  if (ax.isEmpty || by.isEmpty) return 0.0;

  final intersection = ax.intersection(by).length;
  final union = ax.union(by).length;
  final jaccard = union == 0 ? 0.0 : intersection / union;

  final contains = (x.contains(y) || y.contains(x)) ? 0.18 : 0.0;
  return (jaccard + contains).clamp(0.0, 1.0);
}

double sizeSimilarity(int a, int b) {
  if (a <= 0 || b <= 0) return 0.0;
  final maxSize = a > b ? a : b;
  final minSize = a < b ? a : b;
  return minSize / maxSize;
}

class SimilarFileGroup {
  final List<ExplorerEntry> files;
  final double confidence;
  final bool exact;
  const SimilarFileGroup(this.files, this.confidence, {this.exact = false});
}


class VisualFingerprint {
  final String path;
  final String hash;
  final String sourceType;
  const VisualFingerprint(this.path, this.hash, this.sourceType);
}

String averageHashFromImage(img.Image source) {
  final resized = img.copyResize(source, width: 16, height: 16);
  int total = 0;
  final values = <int>[];

  for (int y = 0; y < resized.height; y++) {
    for (int x = 0; x < resized.width; x++) {
      final pixel = resized.getPixel(x, y);
      final gray = ((pixel.r * 299) + (pixel.g * 587) + (pixel.b * 114)) ~/ 1000;
      values.add(gray);
      total += gray;
    }
  }

  if (values.isEmpty) return '';
  final avg = total / values.length;
  final bits = StringBuffer();
  for (final value in values) {
    bits.write(value >= avg ? '1' : '0');
  }
  return bits.toString();
}

double bitSimilarity(String a, String b) {
  if (a.isEmpty || b.isEmpty || a.length != b.length) return 0.0;
  int equal = 0;
  for (int i = 0; i < a.length; i++) {
    if (a.codeUnitAt(i) == b.codeUnitAt(i)) equal++;
  }
  return equal / a.length;
}

void main() => runApp(const FileAiApp());

class FileAiApp extends StatelessWidget {
  const FileAiApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'File AI Assistant',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF2563EB)),
        useMaterial3: true,
      ),
      home: const ExplorerPage(),
    );
  }
}

enum EntryKind { folder, image, video, audio, document, archive, apk, other }

class ExplorerEntry {
  final FileSystemEntity entity;
  final EntryKind kind;
  final int size;
  final DateTime modified;
  const ExplorerEntry(this.entity, this.kind, this.size, this.modified);

  bool get isFolder => entity is Directory;
  String get name => p.basename(entity.path);
}

class ExplorerPage extends StatefulWidget {
  const ExplorerPage({super.key});

  @override
  State<ExplorerPage> createState() => _ExplorerPageState();
}

class _ExplorerPageState extends State<ExplorerPage> {
  static const storageRoot = '/storage/emulated/0';
  static const minimumUsefulFileSize = 2;

  static const ignoredFolderNames = {
    'android',
    '.android_secure',
    'lost.dir',
    '.thumbnails',
    '.trash',
    '.trashed',
    '.recycle',
    '.recyclebin',
    '.git',
    '__pycache__',
    '_fileai_quarantine',
  };

  final Set<String> selectedPaths = {};
  final Set<EntryKind> activeFilters = {};

  Directory currentDirectory = Directory(storageRoot);
  List<ExplorerEntry> entries = [];
  bool loading = false;
  bool recursiveAnalysis = true;
  bool globalScan = false;
  List<SimilarFileGroup> similarGroups = [];
  List<SimilarFileGroup> visualGroups = [];
  String status = 'Prêt';
  String openAiApiKey = '';
  bool aiBusy = false;
  String aiMode = 'local';
  String localApiKey = '';
  bool scanWholeStorage = true;
  bool actionBusy = false;
  List<Map<String, dynamic>> pendingActions = [];
  bool snapshotBusy = false;
  bool planImportBusy = false;
  String lastSnapshotId = '';
  String lastSnapshotPath = '';
  int lastSnapshotFileCount = 0;
  final TextEditingController aiInstructionController = TextEditingController(
    text: 'Regroupe les fichiers similaires par nom, conserve les numéros de chapitre quand ils existent, uniformise les noms et signale les doublons.',
  );

  @override
  void initState() {
    super.initState();
    _loadAiSettings();
    _start();
  }

  @override
  void dispose() {
    aiInstructionController.dispose();
    super.dispose();
  }

  Future<void> _loadAiSettings() async {
    final prefs = await SharedPreferences.getInstance();
    final key = prefs.getString('openai_api_key') ?? '';
    final gKey = prefs.getString('local_api_key') ?? '';
    final savedSnapshotId = prefs.getString('last_snapshot_id') ?? '';
    final savedSnapshotPath = prefs.getString('last_snapshot_path') ?? '';
    final savedSnapshotCount = prefs.getInt('last_snapshot_file_count') ?? 0;
    if (mounted) {
      setState(() {
        openAiApiKey = key;
        localApiKey = gKey;
        lastSnapshotId = savedSnapshotId;
        lastSnapshotPath = savedSnapshotPath;
        lastSnapshotFileCount = savedSnapshotCount;
      });
    }
  }

  Future<void> _saveApiKey(String key) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('openai_api_key', key.trim());
    if (mounted) {
      setState(() {
        openAiApiKey = key.trim();
      });
    }
  }

  Future<void> _start() async {
    final permission = await Permission.storage.request();
    if (!permission.isGranted) {
      if (permission.isPermanentlyDenied) await openAppSettings();
      if (mounted) setState(() => status = 'Autorisation stockage nécessaire');
      return;
    }
    await _loadDirectory(currentDirectory);
  }

  bool _ignored(String path) {
    final lower = path.toLowerCase().replaceAll('\\', '/');
    if (lower.contains('/android/data/') ||
        lower.contains('/android/obb/') ||
        lower.contains('/android/media/')) {
      return true;
    }

    final parts = p.split(path).map((e) => e.toLowerCase());
    return parts.any(ignoredFolderNames.contains);
  }

  EntryKind _kind(String path, {bool folder = false}) {
    if (folder) return EntryKind.folder;
    final ext = p.extension(path).toLowerCase();

    if ({'.jpg','.jpeg','.png','.webp','.gif','.bmp','.heic'}.contains(ext)) {
      return EntryKind.image;
    }
    if ({'.mp4','.mkv','.avi','.mov','.webm','.3gp','.m4v'}.contains(ext)) {
      return EntryKind.video;
    }
    if ({'.mp3','.wav','.m4a','.aac','.flac','.ogg','.opus'}.contains(ext)) {
      return EntryKind.audio;
    }
    if ({'.pdf','.doc','.docx','.xls','.xlsx','.ppt','.pptx','.txt','.rtf','.csv','.epub'}.contains(ext)) {
      return EntryKind.document;
    }
    if ({'.zip','.rar','.7z','.tar','.gz'}.contains(ext)) {
      return EntryKind.archive;
    }
    if (ext == '.apk') return EntryKind.apk;
    return EntryKind.other;
  }

  Future<ExplorerEntry?> _entry(FileSystemEntity entity) async {
    try {
      if (_ignored(entity.path)) return null;
      final stat = await entity.stat();

      if (entity is Directory) {
        return ExplorerEntry(entity, EntryKind.folder, 0, stat.modified);
      }

      if (entity is File) {
        if (stat.size < minimumUsefulFileSize) return null;
        return ExplorerEntry(entity, _kind(entity.path), stat.size, stat.modified);
      }
    } catch (_) {}
    return null;
  }

  Future<void> _loadDirectory(Directory dir) async {
    setState(() {
      loading = true;
      selectedPaths.clear();
      status = 'Ouverture...';
    });

    final list = <ExplorerEntry>[];

    try {
      await for (final entity in dir.list(followLinks: false)) {
        final item = await _entry(entity);
        if (item != null) list.add(item);
      }

      list.sort((a, b) {
        if (a.isFolder != b.isFolder) return a.isFolder ? -1 : 1;
        return a.name.toLowerCase().compareTo(b.name.toLowerCase());
      });

      if (!mounted) return;
      setState(() {
        currentDirectory = dir;
        entries = list;
        loading = false;
        status = '${list.where((e) => e.isFolder).length} dossier(s) • '
            '${list.where((e) => !e.isFolder).length} fichier(s)';
      });
    } catch (_) {
      if (!mounted) return;
      setState(() {
        loading = false;
        status = 'Dossier inaccessible';
      });
    }
  }

  List<ExplorerEntry> get visibleEntries {
    if (activeFilters.isEmpty) return entries;
    return entries.where((e) => e.isFolder || activeFilters.contains(e.kind)).toList();
  }

  Future<void> _goUp() async {
    if (currentDirectory.path == storageRoot) return;
    final parent = currentDirectory.parent;
    if (parent.path.startsWith(storageRoot)) await _loadDirectory(parent);
  }

  void _toggleSelection(ExplorerEntry entry) {
    if (entry.isFolder) return;
    setState(() {
      if (!selectedPaths.add(entry.entity.path)) {
        selectedPaths.remove(entry.entity.path);
      }
    });
  }

  void _selectAllVisible() {
    setState(() {
      selectedPaths
        ..clear()
        ..addAll(visibleEntries.where((e) => !e.isFolder).map((e) => e.entity.path));
    });
  }

  void _selectKinds(Set<EntryKind> kinds) {
    setState(() {
      selectedPaths
        ..clear()
        ..addAll(entries.where((e) => !e.isFolder && kinds.contains(e.kind))
            .map((e) => e.entity.path));
    });
  }

  Future<void> _autoSelect() async {
    final chosen = <EntryKind>{};

    await showDialog(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, local) => AlertDialog(
          title: const Text('Sélection automatique'),
          content: SingleChildScrollView(
            child: Column(
              children: [
                _kindCheck(local, chosen, EntryKind.image, 'Images', Icons.image_outlined),
                _kindCheck(local, chosen, EntryKind.video, 'Vidéos', Icons.movie_outlined),
                _kindCheck(local, chosen, EntryKind.audio, 'Audio', Icons.music_note_outlined),
                _kindCheck(local, chosen, EntryKind.document, 'Documents / textes', Icons.description_outlined),
                _kindCheck(local, chosen, EntryKind.archive, 'Archives', Icons.archive_outlined),
                _kindCheck(local, chosen, EntryKind.apk, 'APK', Icons.android_outlined),
                _kindCheck(local, chosen, EntryKind.other, 'Autres', Icons.insert_drive_file_outlined),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(ctx),
              child: const Text('Annuler'),
            ),
            FilledButton(
              onPressed: () {
                Navigator.pop(ctx);
                _selectKinds(chosen);
              },
              child: const Text('Sélectionner'),
            ),
          ],
        ),
      ),
    );
  }

  Widget _kindCheck(
    StateSetter local,
    Set<EntryKind> chosen,
    EntryKind kind,
    String label,
    IconData icon,
  ) {
    return CheckboxListTile(
      value: chosen.contains(kind),
      secondary: Icon(icon),
      title: Text(label),
      onChanged: (v) {
        local(() {
          if (v == true) {
            chosen.add(kind);
          } else {
            chosen.remove(kind);
          }
        });
      },
    );
  }

  Future<void> _rename(ExplorerEntry entry) async {
    final c = TextEditingController(text: entry.name);
    final name = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(entry.isFolder ? 'Renommer le dossier' : 'Renommer le fichier'),
        content: TextField(
          controller: c,
          autofocus: true,
          decoration: const InputDecoration(
            labelText: 'Nouveau nom',
            border: OutlineInputBorder(),
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Annuler')),
          FilledButton(
            onPressed: () => Navigator.pop(ctx, c.text.trim()),
            child: const Text('Renommer'),
          ),
        ],
      ),
    );

    if (name == null || name.isEmpty || name == entry.name) return;

    try {
      final target = p.join(p.dirname(entry.entity.path), name);
      if (entry.entity is Directory) {
        await (entry.entity as Directory).rename(target);
      } else {
        await (entry.entity as File).rename(target);
      }
      await _loadDirectory(currentDirectory);
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Renommage impossible')),
        );
      }
    }
  }

  Future<List<ExplorerEntry>> _analysisFiles() async {
    final chosen = entries.where((e) => selectedPaths.contains(e.entity.path) && !e.isFolder).toList();
    if (chosen.isNotEmpty) return chosen;

    if (!recursiveAnalysis) {
      return entries.where((e) => !e.isFolder).toList();
    }

    final result = <ExplorerEntry>[];
    await for (final entity in currentDirectory.list(recursive: true, followLinks: false)) {
      final item = await _entry(entity);
      if (item != null && !item.isFolder) result.add(item);
    }
    return result;
  }

  Future<String> _hash(File file) async {
    final digest = await sha256.bind(file.openRead()).first;
    return digest.toString();
  }

  Future<void> _duplicates() async {
    setState(() {
      loading = true;
      status = 'Recherche des doublons...';
    });

    final files = await _analysisFiles();
    final bySize = <int, List<ExplorerEntry>>{};

    for (final f in files) {
      bySize.putIfAbsent(f.size, () => []).add(f);
    }

    final byHash = <String, List<ExplorerEntry>>{};

    for (final group in bySize.values.where((g) => g.length > 1)) {
      for (final f in group) {
        try {
          final hash = await _hash(f.entity as File);
          byHash.putIfAbsent('${f.size}:$hash', () => []).add(f);
        } catch (_) {}
      }
    }

    final groups = byHash.values.where((g) => g.length > 1).toList();

    if (!mounted) return;
    setState(() {
      loading = false;
      status = '${groups.length} groupe(s) de doublons';
    });

    await showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (ctx) => DraggableScrollableSheet(
        expand: false,
        initialChildSize: .82,
        maxChildSize: .95,
        builder: (_, controller) => Column(
          children: [
            const ListTile(
              title: Text('Doublons exacts', style: TextStyle(fontWeight: FontWeight.bold)),
              subtitle: Text('Même taille + même empreinte SHA-256'),
            ),
            Expanded(
              child: groups.isEmpty
                  ? const Center(child: Text('Aucun doublon exact détecté'))
                  : ListView.builder(
                      controller: controller,
                      itemCount: groups.length,
                      itemBuilder: (_, i) {
                        final group = groups[i];
                        return ExpansionTile(
                          title: Text('${group.length} copies'),
                          subtitle: Text(formatBytes(group.first.size)),
                          children: group.map((e) => ListTile(
                            dense: true,
                            leading: Icon(_icon(e.kind)),
                            title: Text(e.name),
                            subtitle: Text(e.entity.path),
                          )).toList(),
                        );
                      },
                    ),
            ),
          ],
        ),
      ),
    );
  }


  Future<List<ExplorerEntry>> _globalUserFiles() async {
    final roots = <Directory>[
      Directory('$storageRoot/Download'),
      Directory('$storageRoot/Documents'),
      Directory('$storageRoot/DCIM'),
      Directory('$storageRoot/Pictures'),
      Directory('$storageRoot/Movies'),
      Directory('$storageRoot/Music'),
    ];

    // Also include the currently opened user folder even if it is custom.
    if (!roots.any((d) => d.path == currentDirectory.path)) {
      roots.add(currentDirectory);
    }

    final seen = <String>{};
    final result = <ExplorerEntry>[];

    for (final root in roots) {
      if (!await root.exists()) continue;
      try {
        await for (final entity in root.list(recursive: true, followLinks: false)) {
          if (seen.contains(entity.path)) continue;
          seen.add(entity.path);
          final item = await _entry(entity);
          if (item != null && !item.isFolder) result.add(item);
        }
      } catch (_) {}
    }
    return result;
  }


  bool _isVisualCandidate(ExplorerEntry entry) {
    final ext = p.extension(entry.name).toLowerCase();
    return entry.kind == EntryKind.image || ext == '.pdf';
  }

  Future<VisualFingerprint?> _fingerprintImage(ExplorerEntry entry) async {
    try {
      final bytes = await (entry.entity as File).readAsBytes();
      final decoded = img.decodeImage(bytes);
      if (decoded == null) return null;

      final hash = averageHashFromImage(decoded);
      if (hash.isEmpty) return null;
      return VisualFingerprint(entry.entity.path, hash, 'image');
    } catch (_) {
      return null;
    }
  }

  Future<VisualFingerprint?> _fingerprintPdf(ExplorerEntry entry) async {
    PdfDocument? doc;
    PdfPage? page;

    try {
      doc = await PdfDocument.openFile(entry.entity.path);
      if (doc.pagesCount < 1) return null;

      page = await doc.getPage(1);

      final width = page.width <= 0 ? 300.0 : page.width;
      final height = page.height <= 0 ? 420.0 : page.height;

      final scale = width > 256 ? 256 / width : 1.0;
      final targetWidth = (width * scale).round().clamp(64, 320);
      final targetHeight = (height * scale).round().clamp(64, 480);

      final rendered = await page.render(
        width: targetWidth.toDouble(),
        height: targetHeight.toDouble(),
        format: PdfPageImageFormat.png,
      );

      if (rendered == null) return null;

      final decoded = img.decodeImage(Uint8List.fromList(rendered.bytes));
      if (decoded == null) return null;

      final hash = averageHashFromImage(decoded);
      if (hash.isEmpty) return null;
      return VisualFingerprint(entry.entity.path, hash, 'pdf');
    } catch (_) {
      return null;
    } finally {
      try {
        await page?.close();
      } catch (_) {}
      try {
        await doc?.close();
      } catch (_) {}
    }
  }

  Future<VisualFingerprint?> _visualFingerprint(ExplorerEntry entry) async {
    if (entry.kind == EntryKind.image) {
      return _fingerprintImage(entry);
    }

    if (p.extension(entry.name).toLowerCase() == '.pdf') {
      return _fingerprintPdf(entry);
    }

    return null;
  }

  Future<List<SimilarFileGroup>> _findVisualGroups(
    List<ExplorerEntry> files,
  ) async {
    final candidates = files.where(_isVisualCandidate).toList();
    final fingerprints = <String, VisualFingerprint>{};

    // Limit work per run to keep Android 10 responsive on very large libraries.
    // Exact duplicate scan still covers the full library.
    final limited = candidates.take(80).toList();

    for (int i = 0; i < limited.length; i++) {
      final entry = limited[i];

      if (mounted && i % 10 == 0) {
        setState(() {
          status = 'Analyse visuelle ${i + 1}/${limited.length}...';
        });
      }

      final fp = await _visualFingerprint(entry);
      if (fp != null) {
        fingerprints[entry.entity.path] = fp;
      }
    }
    final buckets = <String, List<ExplorerEntry>>{};

    // Bucket by type + approximate size range to avoid comparing everything with everything.
    for (final f in limited) {
      if (!fingerprints.containsKey(f.entity.path)) continue;
      final sizeMb = f.size / (1024 * 1024);
      final bucketBand = (sizeMb / 8).floor();
      final type = p.extension(f.name).toLowerCase() == '.pdf' ? 'pdf' : 'image';
      buckets.putIfAbsent('$type:$bucketBand', () => []).add(f);

      // Also compare with adjacent size band because compressed versions can differ.
      buckets.putIfAbsent('$type:${bucketBand - 1}', () => []).add(f);
      buckets.putIfAbsent('$type:${bucketBand + 1}', () => []).add(f);
    }

    final pairKeys = <String>{};
    final groups = <SimilarFileGroup>[];

    for (final bucket in buckets.values) {
      if (bucket.length < 2) continue;

      for (int i = 0; i < bucket.length; i++) {
        final a = bucket[i];
        final fa = fingerprints[a.entity.path];
        if (fa == null) continue;

        final cluster = <ExplorerEntry>[a];
        double best = 0;

        for (int j = i + 1; j < bucket.length; j++) {
          final b = bucket[j];
          if (a.entity.path == b.entity.path) continue;

          final pair = [a.entity.path, b.entity.path]..sort();
          final pairKey = pair.join('|');
          if (!pairKeys.add(pairKey)) continue;

          final fb = fingerprints[b.entity.path];
          if (fb == null || fa.sourceType != fb.sourceType) continue;

          final visual = bitSimilarity(fa.hash, fb.hash);
          final names = nameSimilarity(a.name, b.name);
          final sizes = sizeSimilarity(a.size, b.size);

          // Visual similarity dominates. Names and size reinforce confidence.
          final confidence = (visual * 0.70) + (names * 0.18) + (sizes * 0.12);

          if (visual >= 0.89 && confidence >= 0.82) {
            cluster.add(b);
            if (confidence > best) best = confidence;
          }
        }

        if (cluster.length > 1) {
          final unique = <String, ExplorerEntry>{};
          for (final f in cluster) {
            unique[f.entity.path] = f;
          }
          final values = unique.values.toList();

          if (values.length > 1) {
            groups.add(
              SimilarFileGroup(
                values,
                best.clamp(0.0, 0.995),
              ),
            );
          }
        }
      }
    }

    // De-duplicate near-identical groups by sorted path signature.
    final seenGroups = <String>{};
    final clean = <SimilarFileGroup>[];

    for (final g in groups) {
      final paths = g.files.map((e) => e.entity.path).toList()..sort();
      final sig = paths.join('||');
      if (seenGroups.add(sig)) clean.add(g);
    }

    clean.sort((a, b) => b.confidence.compareTo(a.confidence));
    return clean.take(150).toList();
  }




  Future<void> _localSettings() async {
    final controller = TextEditingController(text: localApiKey);
    final value = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Assistant intelligent local'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text(
              'Colle ta clé Intelligent API. Elle reste enregistrée localement sur ce téléphone.',
            ),
            const SizedBox(height: 12),
            TextField(
              controller: controller,
              obscureText: true,
              autocorrect: false,
              enableSuggestions: false,
              decoration: const InputDecoration(
                labelText: 'Clé Intelligent API',
                border: OutlineInputBorder(),
              ),
            ),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Annuler')),
          FilledButton(
            onPressed: () => Navigator.pop(ctx, controller.text.trim()),
            child: const Text('Enregistrer'),
          ),
        ],
      ),
    );
    if (value != null) {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString('local_api_key', value);
      if (mounted) setState(() => localApiKey = value);
    }
  }

  Future<List<ExplorerEntry>> _scanAccessibleStorage() async {
    final result = <ExplorerEntry>[];
    final seen = <String>{};

    final roots = scanWholeStorage
        ? <Directory>[
            Directory(storageRoot),
          ]
        : <Directory>[currentDirectory];

    const blocked = <String>[
      '/Android/data/',
      '/Android/obb/',
      '/.thumbnails/',
      '/cache/',
    ];

    for (final root in roots) {
      if (!await root.exists()) continue;
      try {
        await for (final entity in root.list(recursive: true, followLinks: false)) {
          if (result.length >= 12000) break;
          final normalized = entity.path.replaceAll('\\', '/');
          if (blocked.any(normalized.contains)) continue;
          if (seen.contains(entity.path)) continue;
          seen.add(entity.path);

          final item = await _entry(entity);
          if (item == null || item.isFolder) continue;
          if (item.size <= 1) continue;
          result.add(item);

          if (mounted && result.length % 250 == 0) {
            setState(() {
              status = 'Inventaire : ${result.length} fichiers accessibles...';
            });
            await Future<void>.delayed(const Duration(milliseconds: 20));
          }
        }
      } catch (_) {}
    }
    return result;
  }

  Map<String, dynamic> _localSchema() {
    return {
      'type': 'object',
      'properties': {
        'summary': {'type': 'string'},
        'tree_preview': {
          'type': 'array',
          'items': {'type': 'string'}
        },
        'actions': {
          'type': 'array',
          'items': {
            'type': 'object',
            'properties': {
              'type': {
                'type': 'string',
                'enum': ['create_folder', 'move', 'rename', 'quarantine']
              },
              'source': {'type': 'string'},
              'destination': {'type': 'string'},
              'reason': {'type': 'string'},
              'confidence': {'type': 'number'}
            },
            'required': ['type', 'source', 'destination', 'reason', 'confidence']
          }
        }
      },
      'required': ['summary', 'tree_preview', 'actions']
    };
  }

  Future<Map<String, dynamic>> _askIntelligentForActions(
    List<ExplorerEntry> files,
    String instruction,
  ) async {
    if (localApiKey.trim().isEmpty) {
      await _localSettings();
      if (localApiKey.trim().isEmpty) {
        throw Exception('Clé Intelligent absente');
      }
    }

    // Send compact metadata only. The phone remains the file-system authority.
    final compact = files.take(2500).map((f) => {
      'path': f.entity.path,
      'name': f.name,
      'size': f.size,
      'ext': p.extension(f.name).toLowerCase(),
    }).toList();

    final prompt = jsonEncode({
      'instruction': instruction,
      'rules': [
        'Never invent a source path.',
        'Prefer grouping files with strongly similar logical names.',
        'Preserve detected chapter, episode, tome and part numbers.',
        'For sequential rename, use zero-padded numbers when appropriate.',
        'Never permanently delete. Duplicate/corrupt candidates must use quarantine.',
        'Do not touch Android system folders.',
        'Return only actions justified by the supplied inventory.',
        'Destination paths must stay under $storageRoot.'
      ],
      'inventory': compact,
    });

    final body = {
      'contents': [
        {
          'role': 'user',
          'parts': [{'text': prompt}]
        }
      ],
      'generationConfig': {
        'responseMimeType': 'application/json',
        'responseSchema': _localSchema(),
        'temperature': 0.2,
      }
    };

    final response = await http.post(
      Uri.parse(
        'offline://disabled/v1beta/models/'
        'offline-disabled:generateContent',
      ),
      headers: {
        'x-goog-api-key': localApiKey.trim(),
        'Content-Type': 'application/json',
      },
      body: jsonEncode(body),
    ).timeout(const Duration(seconds: 75));

    if (response.statusCode < 200 || response.statusCode >= 300) {
      throw Exception('Intelligent ${response.statusCode}: ${response.body}');
    }

    final outer = jsonDecode(response.body) as Map<String, dynamic>;
    final candidates = outer['candidates'] as List<dynamic>? ?? [];
    if (candidates.isEmpty) throw Exception('Intelligent n’a retourné aucun plan');

    final content = candidates.first['content'] as Map<String, dynamic>?;
    final parts = content?['parts'] as List<dynamic>? ?? [];
    if (parts.isEmpty) throw Exception('Réponse Intelligent vide');

    final text = (parts.first as Map<String, dynamic>)['text']?.toString() ?? '';
    if (text.isEmpty) throw Exception('Plan Intelligent vide');
    return jsonDecode(text) as Map<String, dynamic>;
  }

  bool _isSafeDestination(String destination) {
    final normalized = p.normalize(destination);
    final root = p.normalize(storageRoot);
    return normalized == root || p.isWithin(root, normalized);
  }

  Set<String> _extractProtectedTerms(String instruction) {
    final terms = <String>{};
    final lower = instruction.toLowerCase();
    final patterns = <RegExp>[
      RegExp(r'ne touche pas (?:à|au|aux)?\s*([^,.;\n]+)'),
      RegExp(r'ignore\s+([^,.;\n]+)'),
      RegExp(r'ne déplace pas\s+([^,.;\n]+)'),
      RegExp(r'ne renomme pas\s+([^,.;\n]+)'),
      RegExp(r'protège\s+([^,.;\n]+)'),
    ];
    for (final rx in patterns) {
      for (final m in rx.allMatches(lower)) {
        final value = (m.group(1) ?? '').trim();
        if (value.length >= 2) terms.add(value);
      }
    }
    return terms;
  }

  bool _isProtectedByInstruction(String path, Set<String> terms) {
    final lower = path.toLowerCase();
    return terms.any((t) => lower.contains(t));
  }

  int? _extractSequenceNumber(String name) {
    final stem = p.basenameWithoutExtension(name);
    final regexes = <RegExp>[
      RegExp(r'(?:chapitre|chapter|chap|ch)[ _.-]*(\d{1,4})', caseSensitive: false),
      RegExp(r'(?:episode|ep)[ _.-]*(\d{1,4})', caseSensitive: false),
      RegExp(r'(?:partie|part|pt)[ _.-]*(\d{1,4})', caseSensitive: false),
      RegExp(r'(?:tome|volume|vol)[ _.-]*(\d{1,4})', caseSensitive: false),
    ];
    for (final rx in regexes) {
      final match = rx.firstMatch(stem);
      if (match != null) return int.tryParse(match.group(1)!);
    }
    return null;
  }

  String _groupKeyForFile(String fileName) {
    var value = normalizedFileName(fileName);
    value = value.replaceAll(
      RegExp(
        r'\b(chapitre|chapter|chap|ch|episode|ep|partie|part|pt|tome|volume|vol)\s*\d+\b',
        caseSensitive: false,
      ),
      ' ',
    );
    value = value.replaceAll(RegExp(r'\b\d{1,4}\b'), ' ');
    value = value.replaceAll(RegExp(r'\s+'), ' ').trim();

    final stop = <String>{
      'scan', 'vf', 'fr', 'gratuit', 'free', 'final', 'copy', 'copie',
      'page', 'pages', 'pdf', 'document', 'new', 'nouveau',
    };
    return value
        .split(' ')
        .where((w) => w.length >= 2 && !stop.contains(w))
        .take(5)
        .join(' ')
        .trim();
  }

  String _niceFolderName(String key) {
    if (key.trim().isEmpty) return 'A_verifier';
    return key
        .split(' ')
        .where((x) => x.isNotEmpty)
        .map((x) => '${x[0].toUpperCase()}${x.substring(1)}')
        .join(' ');
  }

  Future<Map<String, dynamic>> _buildSmartActionPlan(
    List<ExplorerEntry> files,
    String instruction,
  ) async {
    final protectedTerms = _extractProtectedTerms(instruction);
    final lower = instruction.toLowerCase();

    final wantsRename = !lower.contains('ne renomme pas');
    final wantsMove = !lower.contains('ne déplace pas');
    final wantsDuplicates = !lower.contains('ignore les doublons');
    final preserveNumbers =
        lower.contains('garde les numéros') ||
        lower.contains('conserve les numéros') ||
        lower.contains('chapitre') ||
        lower.contains('episode');

    final groups = <String, List<ExplorerEntry>>{};
    final protectedFiles = <ExplorerEntry>[];

    for (final file in files) {
      if (_isProtectedByInstruction(file.entity.path, protectedTerms)) {
        protectedFiles.add(file);
        continue;
      }
      final key = _groupKeyForFile(file.name);
      if (key.isNotEmpty) {
        groups.putIfAbsent(key, () => []).add(file);
      }
    }

    final classifyEverything =
        lower.contains('tout ranger') ||
        lower.contains('tous les fichiers') ||
        lower.contains('par type');

    final organizeRoot = scanWholeStorage
        ? p.join(storageRoot, 'FileAI_Organise')
        : p.join(currentDirectory.path, 'FileAI_Organise');

    final actions = <Map<String, dynamic>>[];
    final tree = <String>[];
    final sortedGroups = groups.entries.toList()
      ..sort((a, b) => b.value.length.compareTo(a.value.length));

    int groupCount = 0;
    int renameCount = 0;
    int moveCount = 0;

    for (final entry in sortedGroups) {
      final items = entry.value;
      if (items.length < 2 && !classifyEverything) continue;

      final folderName = _niceFolderName(entry.key);
      final folderPath = p.join(organizeRoot, folderName);

      actions.add({
        'type': 'create_folder',
        'source': '',
        'destination': folderPath,
        'reason': 'Créer le groupe $folderName',
        'confidence': items.length >= 3 ? .93 : .81,
        'selected': true,
      });
      tree.add('📁 $folderName (${items.length})');
      groupCount++;

      final ordered = [...items]..sort((a, b) {
        final na = _extractSequenceNumber(a.name);
        final nb = _extractSequenceNumber(b.name);
        if (na != null && nb != null) return na.compareTo(nb);
        if (na != null) return -1;
        if (nb != null) return 1;
        return a.name.toLowerCase().compareTo(b.name.toLowerCase());
      });

      for (int i = 0; i < ordered.length; i++) {
        final file = ordered[i];
        final ext = p.extension(file.name);
        final detected = _extractSequenceNumber(file.name);

        String newName = file.name;
        if (wantsRename) {
          if (preserveNumbers && detected != null) {
            newName =
                '${folderName.replaceAll(' ', '_')}_${detected.toString().padLeft(3, '0')}$ext';
          } else {
            newName =
                '${folderName.replaceAll(' ', '_')}_${(i + 1).toString().padLeft(3, '0')}$ext';
          }
          renameCount++;
        }

        if (wantsMove || wantsRename) {
          actions.add({
            'type': wantsRename ? 'rename' : 'move',
            'source': file.entity.path,
            'destination': p.join(folderPath, newName),
            'reason': wantsRename
                ? 'Regrouper et uniformiser le nom'
                : 'Regrouper dans $folderName',
            'confidence': items.length >= 3 ? .91 : .79,
            'selected': true,
          });
          moveCount++;
        }
      }
    }

    int duplicateCount = 0;
    if (wantsDuplicates) {
      final bySize = <int, List<ExplorerEntry>>{};
      for (final file in files) {
        if (_isProtectedByInstruction(file.entity.path, protectedTerms)) continue;
        bySize.putIfAbsent(file.size, () => []).add(file);
      }

      for (final sameSize in bySize.values.where((g) => g.length > 1)) {
        final hashes = <String, List<ExplorerEntry>>{};
        for (final file in sameSize.take(40)) {
          try {
            final hash = await _hash(file.entity as File)
                .timeout(const Duration(seconds: 5));
            hashes.putIfAbsent(hash, () => []).add(file);
          } catch (_) {}
        }
        for (final duplicates in hashes.values.where((g) => g.length > 1)) {
          for (final duplicate in duplicates.skip(1)) {
            actions.add({
              'type': 'quarantine',
              'source': duplicate.entity.path,
              'destination': p.join(
                storageRoot,
                'FileAI_Quarantaine',
                duplicate.name,
              ),
              'reason': 'Doublon exact SHA-256',
              'confidence': 1.0,
              'selected': true,
            });
            duplicateCount++;
          }
        }
      }
    }

    if (protectedFiles.isNotEmpty) {
      tree.add('🔒 Protégés / intouchables (${protectedFiles.length})');
    }
    if (duplicateCount > 0) {
      tree.add('🧹 Quarantaine doublons ($duplicateCount)');
    }
    if (actions.isEmpty) {
      tree.add('ℹ️ Aucun changement suffisamment fiable');
    }

    return {
      'summary':
          '$groupCount groupe(s), $moveCount fichier(s) à déplacer, '
          '$renameCount renommage(s), $duplicateCount doublon(s).',
      'tree_preview': tree,
      'actions': actions,
    };
  }


  Future<bool> _ensureSharedStorageWritable() async {
    var permission = await Permission.storage.status;
    if (!permission.isGranted) {
      permission = await Permission.storage.request();
    }
    if (!permission.isGranted) {
      if (permission.isPermanentlyDenied) {
        await openAppSettings();
      }
      return false;
    }

    final probeDir = Directory(p.join(storageRoot, 'Download', 'FileAI_Exports'));
    try {
      await probeDir.create(recursive: true);
      final probe = File(p.join(probeDir.path, '.fileai_write_test'));
      await probe.writeAsString('ok', flush: true);
      if (await probe.exists()) await probe.delete();
      return true;
    } catch (_) {
      return false;
    }
  }

  Future<Directory> _privateSnapshotTemp(String snapshotId) async {
    final root = Directory(
      p.join(Directory.systemTemp.path, 'file_ai_assistant', snapshotId),
    );
    if (await root.exists()) {
      await root.delete(recursive: true);
    }
    await root.create(recursive: true);
    return root;
  }

  String _safeSnapshotFileId(
    String path,
    int size,
    DateTime modified,
  ) {
    final source = utf8.encode(
      '${p.normalize(path)}|$size|${modified.millisecondsSinceEpoch}',
    );
    return sha256.convert(source).toString().substring(0, 20);
  }

  String _snapshotIdNow() {
    final now = DateTime.now();
    String two(int v) => v.toString().padLeft(2, '0');
    return 'PHONE_${now.year}${two(now.month)}${two(now.day)}_'
        '${two(now.hour)}${two(now.minute)}${two(now.second)}';
  }

  Map<String, dynamic> _planSchemaForChat() {
    return {
      'format': 'FILEAI_PLAN',
      'version': 1,
      'snapshot_id': 'MUST_MATCH_SNAPSHOT_ID',
      'summary': 'Short explanation of the proposed organization',
      'tree_preview': [
        'FileAI_Organise/',
        '  Mangas/',
        '    Example Series/',
      ],
      'actions': [
        {
          'action': 'create_folder',
          'path': '/storage/emulated/0/FileAI_Organise/Mangas',
          'reason': 'Why this folder should be created',
        },
        {
          'action': 'move_rename',
          'file_id': 'FILE_ID_FROM_INVENTORY',
          'from': '/exact/source/path/file.pdf',
          'to': '/storage/emulated/0/FileAI_Organise/Mangas/Series/Series_084.pdf',
          'reason': 'Group and normalize filename',
        },
        {
          'action': 'quarantine',
          'file_id': 'FILE_ID_FROM_INVENTORY',
          'from': '/exact/source/path/duplicate.pdf',
          'reason': 'Exact duplicate',
        }
      ]
    };
  }

  Future<Uint8List?> _makeSnapshotPreview(
    ExplorerEntry entry,
  ) async {
    try {
      if (entry.kind == EntryKind.image) {
        // Avoid decoding huge camera images in RAM on older Android devices.
        if (entry.size > 12 * 1024 * 1024) return null;
        final bytes = await (entry.entity as File).readAsBytes();
        final decoded = img.decodeImage(bytes);
        if (decoded == null) return null;
        final resized = img.copyResize(
          decoded,
          width: 160,
          maintainAspect: true,
        );
        return Uint8List.fromList(
          img.encodeJpg(resized, quality: 68),
        );
      }

      if (p.extension(entry.name).toLowerCase() == '.pdf') {
        // Very large/corrupt PDFs are indexed but not previewed.
        if (entry.size > 80 * 1024 * 1024) return null;
        PdfDocument? doc;
        PdfPage? page;
        try {
          doc = await PdfDocument.openFile(entry.entity.path);
          if (doc.pagesCount < 1) return null;
          page = await doc.getPage(1);

          final width = page.width <= 0 ? 300.0 : page.width;
          final height = page.height <= 0 ? 420.0 : page.height;
          final scale = width > 160 ? 160 / width : 1.0;

          final rendered = await page.render(
            width: (width * scale).clamp(80.0, 180.0),
            height: (height * scale).clamp(100.0, 260.0),
            format: PdfPageImageFormat.png,
          );
          if (rendered == null) return null;

          final decoded = img.decodeImage(
            Uint8List.fromList(rendered.bytes),
          );
          if (decoded == null) return null;
          return Uint8List.fromList(
            img.encodeJpg(decoded, quality: 65),
          );
        } finally {
          try {
            await page?.close();
          } catch (_) {}
          try {
            await doc?.close();
          } catch (_) {}
        }
      }
    } catch (_) {}
    return null;
  }

  Future<void> _createPhoneSnapshot() async {
    if (snapshotBusy) return;

    setState(() {
      snapshotBusy = true;
      status = 'Préparation du snapshot ChatGPT...';
    });

    final snapshotId = _snapshotIdNow();

    final writable = await _ensureSharedStorageWritable();
    if (!writable) {
      if (mounted) {
        setState(() {
          snapshotBusy = false;
          status = 'Écriture dans Download refusée';
        });
        await showDialog(
          context: context,
          builder: (ctx) => AlertDialog(
            title: const Text('Autorisation de stockage requise'),
            content: const Text(
              'File AI Assistant peut lire le stockage mais Android refuse encore '
              'l’écriture dans Download. Autorise l’accès aux fichiers dans les '
              'paramètres Android, puis relance Créer Snapshot.',
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(ctx),
                child: const Text('Fermer'),
              ),
              FilledButton(
                onPressed: () async {
                  Navigator.pop(ctx);
                  await openAppSettings();
                },
                child: const Text('Ouvrir les paramètres'),
              ),
            ],
          ),
        );
      }
      return;
    }

    final tempRoot = await _privateSnapshotTemp(snapshotId);
    final previewsDir = Directory(p.join(tempRoot.path, 'previews'));
    final exportDir = Directory(
      p.join(storageRoot, 'Download', 'FileAI_Exports'),
    );

    IOSink? inventorySink;
    IOSink? treeSink;

    try {
      await tempRoot.create(recursive: true);
      await previewsDir.create(recursive: true);
      await exportDir.create(recursive: true);

      final inventoryFile = File(p.join(tempRoot.path, 'inventory.json'));
      final treeFile = File(p.join(tempRoot.path, 'folder_tree.txt'));
      final statsFile = File(p.join(tempRoot.path, 'statistics.json'));
      final rulesFile = File(
        p.join(tempRoot.path, 'INSTRUCTIONS_FOR_CHATGPT.txt'),
      );
      final schemaFile = File(
        p.join(tempRoot.path, 'FILEAI_PLAN_SCHEMA.json'),
      );
      final previewIndexFile = File(
        p.join(tempRoot.path, 'previews', 'index.json'),
      );

      inventorySink = inventoryFile.openWrite();
      treeSink = treeFile.openWrite();

      inventorySink.write(
        '{"format":"FILEAI_SNAPSHOT","version":1,'
        '"snapshot_id":${jsonEncode(snapshotId)},'
        '"storage_root":${jsonEncode(storageRoot)},'
        '"files":[',
      );

      final folderCounts = <String, int>{};
      final typeCounts = <String, int>{};
      final sizeBuckets = <int, List<Map<String, dynamic>>>{};
      final previewIndex = <Map<String, dynamic>>[];

      int fileCount = 0;
      int totalBytes = 0;
      int previewCount = 0;
      bool firstInventory = true;

      final ignored = <String>[
        '/Android/data/',
        '/Android/obb/',
        '/.thumbnails/',
        '/FileAI_Temp/',
        '/FileAI_Quarantaine/',
      ];

      final rootDir = Directory(storageRoot);

      await for (final entity in rootDir.list(
        recursive: true,
        followLinks: false,
      )) {
        final normalized = entity.path.replaceAll('\\', '/');
        if (ignored.any(normalized.contains)) continue;
        if (entity is! File) continue;

        FileStat stat;
        try {
          stat = await entity.stat();
        } catch (_) {
          continue;
        }
        if (stat.size <= 1) continue;

        final kind = _kind(entity.path);
        final fileId = _safeSnapshotFileId(
          entity.path,
          stat.size,
          stat.modified,
        );
        final folder = p.dirname(entity.path);
        final record = <String, dynamic>{
          'file_id': fileId,
          'path': entity.path,
          'name': p.basename(entity.path),
          'extension': p.extension(entity.path).toLowerCase(),
          'size': stat.size,
          'modified': stat.modified.toIso8601String(),
          'folder': folder,
          'kind': kind.name,
        };

        if (!firstInventory) inventorySink.write(',');
        firstInventory = false;
        inventorySink.write(jsonEncode(record));

        folderCounts[folder] = (folderCounts[folder] ?? 0) + 1;
        typeCounts[kind.name] = (typeCounts[kind.name] ?? 0) + 1;
        totalBytes += stat.size;
        fileCount++;

        sizeBuckets.putIfAbsent(stat.size, () => []).add(record);

        if (previewCount < 24 &&
            (kind == EntryKind.image ||
                p.extension(entity.path).toLowerCase() == '.pdf')) {
          final entry = ExplorerEntry(
            entity,
            kind,
            stat.size,
            stat.modified,
          );
          try {
            final bytes = await _makeSnapshotPreview(entry)
                .timeout(const Duration(seconds: 6));
            if (bytes != null) {
              final previewName =
                  '${previewCount.toString().padLeft(3, '0')}_$fileId.jpg';
              await File(
                p.join(previewsDir.path, previewName),
              ).writeAsBytes(bytes, flush: true);

              previewIndex.add({
                'file_id': fileId,
                'preview': 'previews/$previewName',
                'source_path': entity.path,
              });
              previewCount++;
            }
          } catch (_) {}
        }

        if (fileCount % 250 == 0) {
          if (mounted) {
            setState(() {
              status = 'Snapshot : $fileCount fichiers indexés...';
            });
          }
          await Future<void>.delayed(
            const Duration(milliseconds: 15),
          );
        }
      }

      inventorySink.write(']}');
      await inventorySink.flush();
      await inventorySink.close();
      inventorySink = null;

      final sortedFolders = folderCounts.entries.toList()
        ..sort((a, b) => a.key.compareTo(b.key));

      treeSink.writeln('SNAPSHOT $snapshotId');
      treeSink.writeln('Stockage : $storageRoot');
      treeSink.writeln('');
      for (final entry in sortedFolders) {
        treeSink.writeln('${entry.key}  [${entry.value} fichier(s)]');
      }
      await treeSink.flush();
      await treeSink.close();
      treeSink = null;

      final duplicateCandidates = <Map<String, dynamic>>[];
      for (final entry in sizeBuckets.entries) {
        if (entry.value.length > 1) {
          duplicateCandidates.add({
            'size': entry.key,
            'files': entry.value
                .take(30)
                .map((x) => {
                      'file_id': x['file_id'],
                      'path': x['path'],
                      'name': x['name'],
                    })
                .toList(),
          });
        }
      }

      await File(
        p.join(tempRoot.path, 'duplicate_candidates.json'),
      ).writeAsString(
        const JsonEncoder.withIndent('  ').convert({
          'note':
              'Same-size candidates only. Validate before quarantine.',
          'groups': duplicateCandidates.take(500).toList(),
        }),
        flush: true,
      );

      await statsFile.writeAsString(
        const JsonEncoder.withIndent('  ').convert({
          'snapshot_id': snapshotId,
          'file_count': fileCount,
          'folder_count': folderCounts.length,
          'total_bytes': totalBytes,
          'types': typeCounts,
          'preview_count': previewCount,
        }),
        flush: true,
      );

      await previewIndexFile.writeAsString(
        const JsonEncoder.withIndent('  ').convert(previewIndex),
        flush: true,
      );

      await schemaFile.writeAsString(
        const JsonEncoder.withIndent('  ').convert(_planSchemaForChat()),
        flush: true,
      );

      final instructions = [
        'FILE AI ASSISTANT - INSTRUCTIONS POUR CHATGPT',
        '',
        'Tu analyses PHONE_SNAPSHOT.zip pour proposer une organisation du téléphone.',
        '',
        'REGLES OBLIGATOIRES :',
        '1. Ne jamais inventer un file_id ou un chemin source.',
        '2. Le snapshot_id du FILEAI_PLAN.json doit être exactement : $snapshotId',
        '3. Ne jamais demander de suppression définitive.',
        '4. Utiliser quarantine pour les doublons à isoler.',
        '5. Préserver les numéros de chapitre/tome/épisode lorsqu’ils sont fiables.',
        '6. Les destinations doivent rester sous $storageRoot',
        '7. Si un classement est incertain, utiliser A_verifier.',
        '8. Présenter d’abord le plan dans ChatGPT.',
        '9. Attendre les modifications/validation de l’utilisateur.',
        '10. Quand l’utilisateur demande le fichier final, générer FILEAI_PLAN.json selon FILEAI_PLAN_SCHEMA.json.',
        '',
        'inventory.json contient les identifiants et chemins autorisés.',
        'folder_tree.txt décrit l’état actuel.',
        'statistics.json résume le stockage.',
        'duplicate_candidates.json contient des candidats basés sur la taille.',
        'previews/ contient quelques miniatures représentatives.',
      ].join('\n');

      await rulesFile.writeAsString(instructions, flush: true);

      final zipPath = p.join(
        exportDir.path,
        'PHONE_SNAPSHOT_$snapshotId.zip',
      );

      final encoder = ZipFileEncoder();
      encoder.create(zipPath);

      // Archive 3.x addFile is synchronous. Every mandatory file is added
      // before close(), then the resulting ZIP is reopened and validated.
      encoder.addFile(inventoryFile, 'inventory.json');
      encoder.addFile(treeFile, 'folder_tree.txt');
      encoder.addFile(statsFile, 'statistics.json');
      encoder.addFile(rulesFile, 'INSTRUCTIONS_FOR_CHATGPT.txt');
      encoder.addFile(schemaFile, 'FILEAI_PLAN_SCHEMA.json');
      encoder.addFile(
        File(p.join(tempRoot.path, 'duplicate_candidates.json')),
        'duplicate_candidates.json',
      );
      encoder.addFile(previewIndexFile, 'previews/index.json');

      if (await previewsDir.exists()) {
        for (final entity in previewsDir.listSync()) {
          if (entity is File &&
              p.basename(entity.path) != 'index.json') {
            encoder.addFile(
              entity,
              'previews/${p.basename(entity.path)}',
            );
          }
        }
      }
      encoder.close();

      // Never announce success for an empty/corrupt snapshot.
      final zipFile = File(zipPath);
      if (!await zipFile.exists()) {
        throw Exception('Le ZIP snapshot n’a pas été créé.');
      }
      final zipSize = await zipFile.length();
      if (zipSize < 200) {
        throw Exception(
          'Snapshot invalide : ZIP anormalement petit ($zipSize octets).',
        );
      }

      final zipBytes = await zipFile.readAsBytes();
      final decodedArchive = ZipDecoder().decodeBytes(
        zipBytes,
        verify: true,
      );
      final archiveNames = decodedArchive.files
          .map((f) => f.name)
          .toSet();

      const mandatory = <String>{
        'inventory.json',
        'folder_tree.txt',
        'statistics.json',
        'duplicate_candidates.json',
        'FILEAI_PLAN_SCHEMA.json',
        'INSTRUCTIONS_FOR_CHATGPT.txt',
        'previews/index.json',
      };

      final missingArchiveFiles =
          mandatory.difference(archiveNames);
      if (missingArchiveFiles.isNotEmpty) {
        try {
          await zipFile.delete();
        } catch (_) {}
        throw Exception(
          'Snapshot incomplet. Fichiers absents du ZIP : '
          '${missingArchiveFiles.join(', ')}',
        );
      }

      final inventoryArchive = decodedArchive.files
          .where((f) => f.name == 'inventory.json')
          .first;
      if (inventoryArchive.size <= 32) {
        try {
          await zipFile.delete();
        } catch (_) {}
        throw Exception(
          'Snapshot invalide : inventory.json est vide.',
        );
      }

      final prefs = await SharedPreferences.getInstance();
      await prefs.setString('last_snapshot_id', snapshotId);
      await prefs.setString('last_snapshot_path', zipPath);
      await prefs.setInt('last_snapshot_file_count', fileCount);

      if (!mounted) return;
      setState(() {
        lastSnapshotId = snapshotId;
        lastSnapshotPath = zipPath;
        lastSnapshotFileCount = fileCount;
        status = 'Snapshot créé : $fileCount fichiers';
      });

      await showDialog(
        context: context,
        builder: (ctx) => AlertDialog(
          title: const Text('PHONE_SNAPSHOT prêt'),
          content: SelectableText(
            'Le snapshot est prêt à être envoyé dans ChatGPT.\n\n'
            '$zipPath\n\n'
            '$fileCount fichiers indexés\n'
            '$previewCount miniatures légères\n''ZIP vérifié : ${(zipSize / 1024).toStringAsFixed(1)} Ko\n\n'
            'Après discussion avec ChatGPT, télécharge FILEAI_PLAN.json '
            'dans Download puis reviens dans l’app.',
          ),
          actions: [
            FilledButton(
              onPressed: () => Navigator.pop(ctx),
              child: const Text('Compris'),
            ),
          ],
        ),
      );
    } catch (e) {
      try {
        await inventorySink?.close();
      } catch (_) {}
      try {
        await treeSink?.close();
      } catch (_) {}

      if (!mounted) return;
      await showDialog(
        context: context,
        builder: (ctx) => AlertDialog(
          title: const Text('Snapshot interrompu'),
          content: Text('$e'),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(ctx),
              child: const Text('Fermer'),
            ),
          ],
        ),
      );
    } finally {
      try {
        if (await tempRoot.exists()) {
          await tempRoot.delete(recursive: true);
        }
      } catch (_) {}
      if (mounted) {
        setState(() {
          snapshotBusy = false;
        });
      }
    }
  }

  Future<File?> _findLatestPlanFile() async {
    final download = Directory(
      p.join(storageRoot, 'Download'),
    );
    if (!await download.exists()) return null;

    final candidates = <File>[];
    try {
      await for (final entity in download.list(
        recursive: true,
        followLinks: false,
      )) {
        if (entity is! File) continue;
        final name = p.basename(entity.path).toUpperCase();
        if (name.startsWith('FILEAI_PLAN') &&
            name.endsWith('.JSON')) {
          candidates.add(entity);
        }
      }
    } catch (_) {}

    if (candidates.isEmpty) return null;
    candidates.sort((a, b) {
      final am = a.statSync().modified;
      final bm = b.statSync().modified;
      return bm.compareTo(am);
    });
    return candidates.first;
  }

  Future<void> _importLatestChatPlan() async {
    if (planImportBusy) return;

    setState(() {
      planImportBusy = true;
      status = 'Choisis le fichier de plan JSON...';
    });

    try {
      final picked = await FilePicker.platform.pickFiles(
        dialogTitle: 'Choisir FILEAI_PLAN.json',
        type: FileType.custom,
        allowedExtensions: ['json'],
        allowMultiple: false,
        withData: true,
      );

      if (picked == null || picked.files.isEmpty) {
        if (mounted) {
          setState(() {
            status = 'Import annulé';
          });
        }
        return;
      }

      final selected = picked.files.single;
      String raw;

      if (selected.bytes != null) {
        raw = utf8.decode(selected.bytes!, allowMalformed: false);
      } else if (selected.path != null) {
        raw = await File(selected.path!).readAsString();
      } else {
        throw Exception(
          'Android n’a pas fourni le contenu du fichier sélectionné.',
        );
      }

      dynamic decoded;
      try {
        decoded = jsonDecode(raw);
      } catch (_) {
        throw Exception(
          'Le fichier choisi n’est pas un JSON valide.',
        );
      }

      if (decoded is! Map) {
        throw Exception(
          'Le JSON sélectionné n’est pas un plan File AI.',
        );
      }

      final plan = Map<String, dynamic>.from(decoded);

      if (plan['format']?.toString() != 'FILEAI_PLAN') {
        throw Exception(
          'Format non reconnu. Le fichier doit contenir '
          '"format": "FILEAI_PLAN".',
        );
      }

      final snapshotId = plan['snapshot_id']?.toString() ?? '';
      if (snapshotId.isEmpty) {
        throw Exception('Le plan ne contient aucun snapshot_id.');
      }

      if (lastSnapshotId.isEmpty) {
        throw Exception(
          'Aucun snapshot local connu. Crée d’abord un PHONE_SNAPSHOT.',
        );
      }

      if (snapshotId != lastSnapshotId) {
        throw Exception(
          'Plan incompatible : il correspond à $snapshotId, '
          'mais le dernier snapshot de l’app est $lastSnapshotId.',
        );
      }

      final actionsRaw = plan['actions'];
      if (actionsRaw is! List) {
        throw Exception('Le plan ne contient aucune liste actions.');
      }

      final converted = <Map<String, dynamic>>[];

      for (final rawAction in actionsRaw) {
        if (rawAction is! Map) continue;
        final a = Map<String, dynamic>.from(rawAction);
        final action = a['action']?.toString() ?? '';

        if (action == 'create_folder') {
          final destination = p.normalize(
            a['path']?.toString() ?? '',
          );
          if (destination.isEmpty ||
              !_isSafeDestination(destination)) {
            continue;
          }

          converted.add({
            'type': 'create_folder',
            'source': '',
            'destination': destination,
            'reason': a['reason']?.toString() ?? 'Plan ChatGPT',
            'confidence': 1.0,
            'selected': true,
          });
        } else if (action == 'move_rename') {
          final source = p.normalize(
            a['from']?.toString() ?? '',
          );
          final destination = p.normalize(
            a['to']?.toString() ?? '',
          );

          if (source.isEmpty ||
              destination.isEmpty ||
              !_isSafeDestination(destination)) {
            continue;
          }

          converted.add({
            'type': 'rename',
            'source': source,
            'destination': destination,
            'file_id': a['file_id']?.toString() ?? '',
            'reason': a['reason']?.toString() ?? 'Plan ChatGPT',
            'confidence': 1.0,
            'selected': true,
          });
        } else if (action == 'quarantine') {
          final source = p.normalize(
            a['from']?.toString() ?? '',
          );
          if (source.isEmpty) continue;

          converted.add({
            'type': 'quarantine',
            'source': source,
            'destination': p.join(
              storageRoot,
              'FileAI_Quarantaine',
              p.basename(source),
            ),
            'file_id': a['file_id']?.toString() ?? '',
            'reason': a['reason']?.toString() ?? 'Plan ChatGPT',
            'confidence': 1.0,
            'selected': true,
          });
        }
      }

      if (converted.isEmpty) {
        throw Exception(
          'Aucune action compatible n’a été trouvée dans ce plan.',
        );
      }

      int valid = 0;
      int missing = 0;
      int conflict = 0;

      for (final a in converted) {
        final type = a['type'].toString();

        if (type == 'create_folder') {
          valid++;
          continue;
        }

        final source = a['source'].toString();

        if (!await File(source).exists()) {
          a['selected'] = false;
          a['validation'] = 'source_missing';
          missing++;
          continue;
        }

        final destination = a['destination'].toString();

        if (type != 'quarantine' &&
            await File(destination).exists()) {
          a['validation'] = 'destination_conflict';
          conflict++;
        }

        valid++;
      }

      if (!mounted) return;

      setState(() {
        pendingActions = converted;
        status =
            '$valid action(s) vérifiée(s) • '
            '$missing source(s) absente(s)';
      });

      final planForUi = <String, dynamic>{
        'summary':
            plan['summary']?.toString() ??
            'Plan importé depuis ${selected.name}',
        'tree_preview':
            plan['tree_preview'] is List
                ? plan['tree_preview'] as List<dynamic>
                : <dynamic>[],
      };

      await _showIntelligentActionPlan(
        planForUi,
        converted,
      );

      if (missing > 0 || conflict > 0) {
        if (!mounted) return;

        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              '$missing source(s) introuvable(s), '
              '$conflict conflit(s) de destination. '
              'Les sources manquantes ont été décochées.',
            ),
          ),
        );
      }
    } catch (e) {
      if (!mounted) return;

      await showDialog(
        context: context,
        builder: (ctx) => AlertDialog(
          title: const Text('Import du plan impossible'),
          content: Text('$e'),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(ctx),
              child: const Text('Fermer'),
            ),
          ],
        ),
      );
    } finally {
      if (mounted) {
        setState(() {
          planImportBusy = false;
        });
      }
    }
  }


  Future<void> _localAssistantPlan() async {
    if (aiBusy) return;
    setState(() {
      aiBusy = true;
      status = scanWholeStorage
          ? 'Analyse intelligente de tout le stockage accessible...'
          : 'Analyse intelligente du dossier...';
    });

    try {
      final files = await _scanAccessibleStorage();
      if (files.isEmpty) throw Exception('Aucun fichier accessible détecté');

      final instruction = aiInstructionController.text.trim().isEmpty
          ? 'Regroupe les fichiers par série, uniformise les noms, garde les numéros de chapitre et mets les doublons en quarantaine.'
          : aiInstructionController.text.trim();

      setState(() => status = 'Construction du plan local...');
      final plan = await _buildSmartActionPlan(files, instruction);
      final rawActions = (plan['actions'] as List<dynamic>? ?? []);
      final validPaths = {for (final f in files) p.normalize(f.entity.path)};
      final sanitized = <Map<String, dynamic>>[];

      for (final raw in rawActions) {
        final action = Map<String, dynamic>.from(raw as Map);
        final type = action['type']?.toString() ?? '';
        final source = p.normalize(action['source']?.toString() ?? '');
        final destination = p.normalize(action['destination']?.toString() ?? '');

        if (!{'create_folder', 'move', 'rename', 'quarantine'}.contains(type)) {
          continue;
        }
        if (!_isSafeDestination(destination)) continue;
        if (type != 'create_folder' && !validPaths.contains(source)) continue;

        action['source'] = source;
        action['destination'] = destination;
        action['selected'] = action['selected'] != false;
        sanitized.add(action);
      }

      if (!mounted) return;
      setState(() {
        pendingActions = sanitized;
        status = '${sanitized.length} action(s) proposées';
      });
      await _showIntelligentActionPlan(plan, sanitized);
    } catch (e) {
      if (!mounted) return;
      await showDialog(
        context: context,
        builder: (ctx) => AlertDialog(
          title: const Text('Assistant intelligent local'),
          content: Text('$e'),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(ctx),
              child: const Text('Fermer'),
            ),
          ],
        ),
      );
    } finally {
      if (mounted) setState(() => aiBusy = false);
    }
  }

  Future<void> _showIntelligentActionPlan(
    Map<String, dynamic> plan,
    List<Map<String, dynamic>> actions,
  ) async {
    final tree = (plan['tree_preview'] as List<dynamic>? ?? []).map((e) => e.toString()).toList();

    await showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setSheetState) => DraggableScrollableSheet(
          expand: false,
          initialChildSize: .94,
          maxChildSize: .98,
          minChildSize: .60,
          builder: (_, controller) => Column(
            children: [
              ListTile(
                leading: const Icon(Icons.psychology_alt_outlined),
                title: const Text('Plan intelligent', style: TextStyle(fontWeight: FontWeight.bold)),
                subtitle: Text(plan['summary']?.toString() ?? 'Organisation proposée'),
              ),
              if (tree.isNotEmpty)
                Container(
                  width: double.infinity,
                  margin: const EdgeInsets.symmetric(horizontal: 12),
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    border: Border.all(color: Theme.of(ctx).dividerColor),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Text(
                    tree.take(30).join('\n'),
                    style: const TextStyle(fontFamily: 'monospace'),
                  ),
                ),
              const Divider(),
              Expanded(
                child: ListView.builder(
                  controller: controller,
                  itemCount: actions.length,
                  itemBuilder: (_, i) {
                    final a = actions[i];
                    return CheckboxListTile(
                      value: a['selected'] == true,
                      onChanged: (v) {
                        setSheetState(() => a['selected'] = v == true);
                      },
                      title: Text('${a['type']} → ${p.basename(a['destination'].toString())}'),
                      subtitle: Text(
                        '${a['reason']}\n'
                        '${a['source']}\n→ ${a['destination']}',
                      ),
                      isThreeLine: true,
                      controlAffinity: ListTileControlAffinity.leading,
                    );
                  },
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(12, 6, 12, 0),
                child: Wrap(
                  spacing: 6,
                  runSpacing: 6,
                  children: [
                    ActionChip(
                      label: const Text('Tout'),
                      onPressed: () => setSheetState(() {
                        for (final a in actions) {
                          a['selected'] = true;
                        }
                      }),
                    ),
                    ActionChip(
                      label: const Text('Regrouper'),
                      onPressed: () => setSheetState(() {
                        for (final a in actions) {
                          a['selected'] =
                              a['type'] == 'create_folder' || a['type'] == 'move';
                        }
                      }),
                    ),
                    ActionChip(
                      label: const Text('Renommer'),
                      onPressed: () => setSheetState(() {
                        for (final a in actions) {
                          a['selected'] = a['type'] == 'rename';
                        }
                      }),
                    ),
                    ActionChip(
                      label: const Text('Doublons'),
                      onPressed: () => setSheetState(() {
                        for (final a in actions) {
                          a['selected'] = a['type'] == 'quarantine';
                        }
                      }),
                    ),
                    ActionChip(
                      label: const Text('Aucun'),
                      onPressed: () => setSheetState(() {
                        for (final a in actions) {
                          a['selected'] = false;
                        }
                      }),
                    ),
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(12),
                child: Row(
                  children: [
                    Expanded(
                      child: OutlinedButton(
                        onPressed: () => Navigator.pop(ctx),
                        child: const Text('Modifier plus tard'),
                      ),
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: FilledButton.icon(
                        onPressed: actions.any((a) => a['selected'] == true)
                            ? () async {
                                Navigator.pop(ctx);
                                await _confirmAndExecuteActions(actions);
                              }
                            : null,
                        icon: const Icon(Icons.play_arrow),
                        label: Text(
                          'AGIR (${actions.where((a) => a['selected'] == true).length})',
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _confirmAndExecuteActions(List<Map<String, dynamic>> actions) async {
    final selected = actions.where((a) => a['selected'] == true).toList();
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Appliquer les actions ?'),
        content: Text(
          '${selected.length} opération(s) seront exécutées.\n\n'
          'Les suppressions définitives ne sont pas autorisées : '
          'les fichiers concernés passent par Quarantaine.',
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Annuler')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('AGIR')),
        ],
      ),
    );
    if (ok != true) return;

    setState(() {
      actionBusy = true;
      status = 'Application des actions...';
    });

    int done = 0, failed = 0;
    final quarantine = Directory(p.join(storageRoot, 'FileAI_Quarantaine'));
    try {
      for (final a in selected) {
        try {
          final type = a['type'].toString();
          var source = a['source'].toString();
          var destination = a['destination'].toString();

          if (!_isSafeDestination(destination)) {
            failed++;
            continue;
          }

          if (type == 'create_folder') {
            await Directory(destination).create(recursive: true);
          } else if (type == 'quarantine') {
            await quarantine.create(recursive: true);
            final src = File(source);
            if (!await src.exists()) { failed++; continue; }
            destination = p.join(
              quarantine.path,
              '${DateTime.now().millisecondsSinceEpoch}_${p.basename(source)}',
            );
            await src.rename(destination);
          } else if (type == 'move' || type == 'rename') {
            final src = File(source);
            if (!await src.exists()) { failed++; continue; }
            await Directory(p.dirname(destination)).create(recursive: true);
            if (await File(destination).exists()) {
              final ext = p.extension(destination);
              final stem = p.basenameWithoutExtension(destination);
              destination = p.join(
                p.dirname(destination),
                '${stem}_${DateTime.now().millisecondsSinceEpoch}$ext',
              );
            }
            await src.rename(destination);
          }
          done++;
        } catch (_) {
          failed++;
        }
        if (mounted) setState(() => status = 'Actions : $done réussie(s), $failed échec(s)');
      }
      await _loadDirectory(currentDirectory);
    } finally {
      if (mounted) {
        setState(() {
          actionBusy = false;
          status = '$done action(s) appliquée(s) • $failed échec(s)';
        });
      }
    }
  }

  Future<void> _openAiSettings() async {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Aucune clé API nécessaire : cette version fonctionne hors ligne.'),
      ),
    );
  }

  Future<List<ExplorerEntry>> _filesForCurrentOrganization() async {
    final result = <ExplorerEntry>[];
    try {
      await for (final entity in currentDirectory.list(
        recursive: true,
        followLinks: false,
      )) {
        final item = await _entry(entity);
        if (item != null && !item.isFolder) {
          result.add(item);
        }
        if (result.length >= 1500) break;
      }
    } catch (_) {}
    return result;
  }

  Future<Map<String, dynamic>?> _askOpenAiForPlan(
    List<ExplorerEntry> files,
    String instruction,
  ) async {
    throw Exception('Mode cloud désactivé dans cette version hors ligne.');
  }

  Future<Map<String,dynamic>> _buildOfflinePlan(List<ExplorerEntry> files) async {
    final buckets=<String,List<ExplorerEntry>>{};
    for(final f in files){
      final words=normalizedFileName(f.name).split(' ').where((w)=>
        w.length>=3&&!RegExp(r'^\d+$').hasMatch(w)&&
        !{'chapitre','chapter','partie','scan','page','final','copie'}.contains(w)).take(3).toList();
      final key=words.isEmpty?p.extension(f.name).replaceFirst('.','').toUpperCase():words.take(2).join(' ');
      buckets.putIfAbsent(key,()=>[]).add(f);
    }
    final groups=<Map<String,dynamic>>[];
    for(final e in buckets.entries){
      if(e.value.length<2)continue;
      final title=e.key.split(' ').map((w)=>w.isEmpty?w:'${w[0].toUpperCase()}${w.substring(1)}').join(' ');
      groups.add({'folder':title,'confidence':.78,'files':e.value.map((x)=>x.entity.path).toList(),
        'rename_pattern':'${title.replaceAll(' ','_')}_{number}'});
    }
    final duplicates=<Map<String,dynamic>>[],bySize=<int,List<ExplorerEntry>>{};
    for(final f in files)bySize.putIfAbsent(f.size,()=>[]).add(f);
    for(final g in bySize.values.where((x)=>x.length>1)){
      final hashes=<String,List<String>>{};
      for(final f in g.take(15)){
        try{
          final h=await _hash(f.entity as File).timeout(const Duration(seconds:4));
          hashes.putIfAbsent(h,()=>[]).add(f.entity.path);
        }catch(_){}
      }
      for(final paths in hashes.values.where((x)=>x.length>1)){
        duplicates.add({'files':paths,'reason':'Doublon exact','confidence':1.0});
      }
    }
    return {'summary':'Mode hors ligne : regroupement par noms similaires et doublons exacts.',
      'groups':groups.take(100).toList(),'duplicates':duplicates.take(100).toList()};
  }

  Future<bool> _openAiReachable() async => false;

  Future<void> _aiOrganizeCurrentFolder() async {
    if (aiBusy) return;

    setState(() {
      aiBusy = true;
      status = 'Préparation du plan de rangement...';
    });

    try {
      final files = await _filesForCurrentOrganization();
      if (files.isEmpty) {
        if (mounted) {
          setState(() {
            status = 'Aucun fichier utile dans ce dossier';
          });
        }
        return;
      }

      final instruction = aiInstructionController.text.trim().isEmpty
          ? 'Regroupe les fichiers similaires par nom et uniformise leurs noms.'
          : aiInstructionController.text.trim();

      Map<String,dynamic>? plan;
      if(aiMode=='local'){
        plan=await _buildOfflinePlan(files);
      }else{
        final reachable=await _openAiReachable();
        if(reachable){
          try{
            plan=await _askOpenAiForPlan(files,instruction);
          }catch(e){
            if(aiMode=='hybrid'){plan=await _buildOfflinePlan(files);}else{rethrow;}
          }
        }else if(aiMode=='hybrid'){
          plan=await _buildOfflinePlan(files);
        }else{
          throw Exception('Cloud désactivé inaccessible. Vérifie Internet ou DNS.');
        }
      }
      if(plan==null||!mounted)return;
      await _showAiPlan(plan);
    } catch (e) {
      if (!mounted) return;
      await showDialog(
        context: context,
        builder: (ctx) => AlertDialog(
          title: const Text('Assistant IA'),
          content: Text(
            'La demande IA a échoué.\n\n$e\n\n'
            'Le rangement local reste disponible.',
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(ctx),
              child: const Text('Fermer'),
            ),
          ],
        ),
      );
    } finally {
      if (mounted) {
        setState(() {
          aiBusy = false;
          status = 'Prêt';
        });
      }
    }
  }

  Future<void> _showAiPlan(Map<String, dynamic> plan) async {
    final groups = (plan['groups'] as List<dynamic>? ?? []);
    final duplicates = (plan['duplicates'] as List<dynamic>? ?? []);
    final summary = plan['summary']?.toString() ?? 'Plan proposé par l’IA';

    await showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (ctx) => DraggableScrollableSheet(
        expand: false,
        initialChildSize: .9,
        maxChildSize: .97,
        builder: (_, controller) => Column(
          children: [
            ListTile(
              leading: const Icon(Icons.auto_awesome),
              title: const Text(
                'Plan IA',
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
              subtitle: Text(summary),
            ),
            const Divider(height: 1),
            Expanded(
              child: ListView(
                controller: controller,
                children: [
                  ...groups.map((raw) {
                    final group = raw is Map<String, dynamic>
                        ? raw
                        : Map<String, dynamic>.from(raw as Map);
                    final folder = group['folder']?.toString() ?? 'A_verifier';
                    final confidence = group['confidence']?.toString() ?? '?';
                    final files = (group['files'] as List<dynamic>? ?? []);
                    final pattern = group['rename_pattern']?.toString() ?? '';

                    return ExpansionTile(
                      leading: const Icon(Icons.folder_copy_outlined),
                      title: Text(folder),
                      subtitle: Text(
                        '${files.length} fichier(s) • confiance $confidence',
                      ),
                      children: [
                        if (pattern.isNotEmpty)
                          ListTile(
                            dense: true,
                            title: const Text('Format de renommage'),
                            subtitle: Text(pattern),
                          ),
                        ...files.take(80).map(
                          (f) => ListTile(
                            dense: true,
                            leading: const Icon(Icons.insert_drive_file_outlined),
                            title: Text(f.toString()),
                          ),
                        ),
                      ],
                    );
                  }),
                  if (duplicates.isNotEmpty)
                    const ListTile(
                      title: Text(
                        'Doublons / versions proches',
                        style: TextStyle(fontWeight: FontWeight.bold),
                      ),
                    ),
                  ...duplicates.map((raw) {
                    final d = raw is Map<String, dynamic>
                        ? raw
                        : Map<String, dynamic>.from(raw as Map);
                    final files = (d['files'] as List<dynamic>? ?? []);
                    return ExpansionTile(
                      leading: const Icon(Icons.content_copy),
                      title: Text('${files.length} fichier(s) à vérifier'),
                      subtitle: Text(d['reason']?.toString() ?? 'Versions proches'),
                      children: files
                          .map(
                            (f) => ListTile(
                              dense: true,
                              title: Text(f.toString()),
                            ),
                          )
                          .toList(),
                    );
                  }),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(12),
              child: SizedBox(
                width: double.infinity,
                child: FilledButton(
                  onPressed: () => Navigator.pop(ctx),
                  child: const Text('Fermer le plan'),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }


  Future<void> _smartGlobalScan() async {
    setState(() {
      loading = true;
      globalScan = true;
      similarGroups = [];
      status = 'Analyse intelligente des dossiers utilisateur...';
    });

    final files = await _globalUserFiles();

    // Phase 1: exact duplicates, grouped cheaply by size before hashing.
    final bySize = <int, List<ExplorerEntry>>{};
    for (final f in files) {
      bySize.putIfAbsent(f.size, () => []).add(f);
    }

    final exactByHash = <String, List<ExplorerEntry>>{};
    for (final candidates in bySize.values.where((g) => g.length > 1)) {
      for (final f in candidates) {
        try {
          final hash = await _hash(f.entity as File);
          exactByHash.putIfAbsent('${f.size}:$hash', () => []).add(f);
        } catch (_) {}
      }
    }

    final groups = <SimilarFileGroup>[];
    final exactPaths = <String>{};

    for (final g in exactByHash.values.where((g) => g.length > 1)) {
      groups.add(SimilarFileGroup(g, 1.0, exact: true));
      exactPaths.addAll(g.map((e) => e.entity.path));
    }

    // Phase 2: probable same content/version using normalized names + type + size.
    // Bucket by first meaningful token to avoid O(n²) over the entire phone.
    final buckets = <String, List<ExplorerEntry>>{};
    for (final f in files) {
      if (exactPaths.contains(f.entity.path)) continue;
      final norm = normalizedFileName(f.entity.path);
      final tokens = norm.split(' ').where((x) => x.length >= 3).toList();
      final key = tokens.isEmpty ? p.extension(f.name).toLowerCase() : tokens.first;
      buckets.putIfAbsent('${f.kind}:$key', () => []).add(f);
    }

    for (final bucket in buckets.values) {
      if (bucket.length < 2) continue;
      final used = <String>{};

      for (int i = 0; i < bucket.length; i++) {
        final a = bucket[i];
        if (used.contains(a.entity.path)) continue;
        final cluster = <ExplorerEntry>[a];
        double bestConfidence = 0;

        for (int j = i + 1; j < bucket.length; j++) {
          final b = bucket[j];
          if (used.contains(b.entity.path)) continue;
          if (p.extension(a.name).toLowerCase() != p.extension(b.name).toLowerCase()) {
            continue;
          }

          final ns = nameSimilarity(a.name, b.name);
          final ss = sizeSimilarity(a.size, b.size);
          final confidence = (ns * 0.72) + (ss * 0.28);

          // High name resemblance can tolerate compression differences.
          if ((ns >= 0.72 && confidence >= 0.72) || (ns >= 0.88 && ss >= 0.45)) {
            cluster.add(b);
            used.add(b.entity.path);
            if (confidence > bestConfidence) bestConfidence = confidence;
          }
        }

        if (cluster.length > 1) {
          used.add(a.entity.path);
          groups.add(SimilarFileGroup(cluster, bestConfidence.clamp(0.0, 0.99)));
        }
      }
    }

    groups.sort((a, b) => b.confidence.compareTo(a.confidence));

    final visual = await _findVisualGroups(files);

    if (!mounted) return;
    setState(() {
      loading = false;
      similarGroups = groups;
      visualGroups = visual;
      status = '${files.length} fichiers utiles • '
          '${groups.length} groupe(s) nom/taille • '
          '${visual.length} groupe(s) visuel(s)';
    });

    await _showSmartPlan(files.length);
  }

  Future<void> _showSmartPlan(int scannedCount) async {
    await showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (ctx) => DraggableScrollableSheet(
        expand: false,
        initialChildSize: .9,
        maxChildSize: .97,
        minChildSize: .55,
        builder: (_, controller) => Column(
          children: [
            ListTile(
              leading: const Icon(Icons.auto_awesome),
              title: const Text(
                'Plan intelligent proposé',
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
              subtitle: Text(
                '$scannedCount fichiers analysés dans les dossiers utilisateur. '
                'Aucune suppression automatique.',
              ),
            ),
            const Divider(height: 1),
            if (visualGroups.isNotEmpty)
              Padding(
                padding: const EdgeInsets.fromLTRB(12, 10, 12, 4),
                child: Align(
                  alignment: Alignment.centerLeft,
                  child: Text(
                    '${visualGroups.length} groupe(s) visuellement très proches détecté(s)',
                    style: const TextStyle(fontWeight: FontWeight.w600),
                  ),
                ),
              ),
            Expanded(
              child: (similarGroups.isEmpty && visualGroups.isEmpty)
                  ? const Center(child: Text('Aucun groupe suffisamment fiable détecté'))
                  : ListView(
                      controller: controller,
                      children: [
                        ...visualGroups.map((group) {
                          final pct = (group.confidence * 100).round();
                          return Card(
                            margin: const EdgeInsets.fromLTRB(10, 7, 10, 7),
                            child: ExpansionTile(
                              leading: const Icon(Icons.visibility_outlined),
                              title: Text(
                                '${group.files.length} fichiers visuellement très proches',
                              ),
                              subtitle: Text(
                                'Confiance $pct % • contenu visuel comparé',
                              ),
                              children: [
                                ...group.files.map(
                                  (f) => ListTile(
                                    dense: true,
                                    leading: Icon(_icon(f.kind)),
                                    title: Text(f.name),
                                    subtitle: Text(
                                      '${formatBytes(f.size)}\n${f.entity.path}',
                                    ),
                                    isThreeLine: true,
                                  ),
                                ),
                                const Padding(
                                  padding: EdgeInsets.all(12),
                                  child: Align(
                                    alignment: Alignment.centerLeft,
                                    child: Text(
                                      'Suggestion : comparer avant suppression. '
                                      'Pour les PDF, la première page est utilisée comme empreinte visuelle dans cette version.',
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          );
                        }),
                        ...similarGroups.map((group) {
                          final pct = (group.confidence * 100).round();
                          final sorted = [...group.files]
                            ..sort((a, b) => b.size.compareTo(a.size));
                          final suggestedKeep = sorted.first;

                          return Card(
                            margin: const EdgeInsets.fromLTRB(10, 7, 10, 7),
                            child: ExpansionTile(
                              leading: Icon(
                                group.exact
                                    ? Icons.verified_outlined
                                    : Icons.auto_awesome_motion,
                              ),
                              title: Text(
                                group.exact
                                    ? '${group.files.length} doublons exacts'
                                    : '${group.files.length} fichiers probablement liés',
                              ),
                              subtitle: Text(
                                group.exact
                                    ? 'Confiance 100 %'
                                    : 'Confiance $pct % • noms et tailles comparés',
                              ),
                              children: [
                                ...sorted.map(
                                  (f) => ListTile(
                                    dense: true,
                                    leading: Icon(_icon(f.kind)),
                                    title: Text(f.name),
                                    subtitle: Text(
                                      '${formatBytes(f.size)}\n${f.entity.path}',
                                    ),
                                    isThreeLine: true,
                                  ),
                                ),
                                Padding(
                                  padding: const EdgeInsets.all(12),
                                  child: Align(
                                    alignment: Alignment.centerLeft,
                                    child: Text(
                                      group.exact
                                          ? 'Suggestion : conserver une copie et déplacer les autres en quarantaine.'
                                          : 'Suggestion provisoire : regrouper ces fichiers. '
                                            'Le plus volumineux (${suggestedKeep.name}) n’est pas supprimé automatiquement.',
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          );
                        }),
                      ],
                    ),
            ),
            Padding(
              padding: const EdgeInsets.all(12),
              child: Row(
                children: [
                  Expanded(
                    child: OutlinedButton(
                      onPressed: () => Navigator.pop(ctx),
                      child: const Text('Fermer'),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: FilledButton.icon(
                      onPressed: () {
                        Navigator.pop(ctx);
                        _showOrganizationProposal();
                      },
                      icon: const Icon(Icons.folder_copy_outlined),
                      label: const Text('Voir rangement'),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _showOrganizationProposal() async {
    final candidates = <String, List<ExplorerEntry>>{};

    for (final group in similarGroups.where((g) => !g.exact && g.confidence >= .72)) {
      final first = group.files.first;
      final norm = normalizedFileName(first.name);
      final words = norm.split(' ').where((w) => w.length >= 3).take(4).toList();
      if (words.isEmpty) continue;
      final folderName = words.map((w) => '${w[0].toUpperCase()}${w.substring(1)}').join(' ');
      candidates.putIfAbsent(folderName, () => []).addAll(group.files);
    }

    await showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Rangement proposé'),
        content: SizedBox(
          width: double.maxFinite,
          height: 430,
          child: candidates.isEmpty
              ? const Center(
                  child: Text(
                    'Pas assez de groupes fiables pour proposer un déplacement automatique.',
                  ),
                )
              : ListView(
                  children: candidates.entries.map((e) {
                    final unique = {for (final f in e.value) f.entity.path: f}.values.toList();
                    return ExpansionTile(
                      leading: const Icon(Icons.folder_outlined),
                      title: Text(e.key),
                      subtitle: Text('${unique.length} fichier(s) à regrouper'),
                      children: unique.map((f) => ListTile(
                        dense: true,
                        title: Text(f.name),
                        subtitle: Text(f.entity.path),
                      )).toList(),
                    );
                  }).toList(),
                ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Fermer'),
          ),
          FilledButton(
            onPressed: candidates.isEmpty
                ? null
                : () {
                    Navigator.pop(ctx);
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(
                        content: Text(
                          'Mode aperçu : aucune modification appliquée. '
                          'La validation destructive sera ajoutée séparément.',
                        ),
                      ),
                    );
                  },
            child: const Text('Prévisualiser seulement'),
          ),
        ],
      ),
    );
  }


  Future<void> _bulkRename() async {
    final files = entries.where((e) => selectedPaths.contains(e.entity.path) && !e.isFolder).toList();
    if (files.isEmpty) return;

    final c = TextEditingController(text: p.basename(currentDirectory.path));
    final prefix = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Renommage en série'),
        content: TextField(
          controller: c,
          decoration: const InputDecoration(
            labelText: 'Nom commun',
            helperText: 'Résultat : Nom_001.ext, Nom_002.ext...',
            border: OutlineInputBorder(),
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Annuler')),
          FilledButton(
            onPressed: () => Navigator.pop(ctx, c.text.trim()),
            child: const Text('Continuer'),
          ),
        ],
      ),
    );

    if (prefix == null || prefix.isEmpty) return;

    final preview = <MapEntry<ExplorerEntry, String>>[];
    for (int i = 0; i < files.length; i++) {
      final ext = p.extension(files[i].name);
      preview.add(MapEntry(
        files[i],
        '${prefix}_${(i + 1).toString().padLeft(3, '0')}$ext',
      ));
    }

    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Prévisualisation'),
        content: SizedBox(
          width: double.maxFinite,
          height: 400,
          child: ListView(
            children: preview.map((x) => ListTile(
              dense: true,
              title: Text(x.key.name),
              subtitle: Text('→ ${x.value}'),
            )).toList(),
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Annuler')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Appliquer')),
        ],
      ),
    );

    if (ok != true) return;

    int renamed = 0;
    for (final x in preview) {
      try {
        final file = x.key.entity as File;
        var dest = p.join(p.dirname(file.path), x.value);
        int n = 2;
        while (await File(dest).exists()) {
          final ext = p.extension(x.value);
          final stem = p.basenameWithoutExtension(x.value);
          dest = p.join(p.dirname(file.path), '${stem}_${n.toString().padLeft(3, '0')}$ext');
          n++;
        }
        await file.rename(dest);
        renamed++;
      } catch (_) {}
    }

    selectedPaths.clear();
    await _loadDirectory(currentDirectory);
    if (mounted) setState(() => status = '$renamed fichier(s) renommé(s)');
  }

  Future<void> _filters() async {
    await showModalBottomSheet(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, local) {
          Widget filter(EntryKind kind, String label) {
            return FilterChip(
              selected: activeFilters.contains(kind),
              label: Text(label),
              onSelected: (v) {
                local(() {
                  setState(() {
                    if (v) {
                      activeFilters.add(kind);
                    } else {
                      activeFilters.remove(kind);
                    }
                  });
                });
              },
            );
          }

          return SafeArea(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Wrap(
                spacing: 8,
                runSpacing: 8,
                children: [
                  filter(EntryKind.image, 'Images'),
                  filter(EntryKind.video, 'Vidéos'),
                  filter(EntryKind.audio, 'Audio'),
                  filter(EntryKind.document, 'Documents'),
                  filter(EntryKind.archive, 'Archives'),
                  filter(EntryKind.apk, 'APK'),
                  filter(EntryKind.other, 'Autres'),
                  ActionChip(
                    label: const Text('Tout afficher'),
                    onPressed: () => local(() => setState(activeFilters.clear)),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  IconData _icon(EntryKind kind) {
    switch (kind) {
      case EntryKind.folder: return Icons.folder;
      case EntryKind.image: return Icons.image_outlined;
      case EntryKind.video: return Icons.movie_outlined;
      case EntryKind.audio: return Icons.music_note_outlined;
      case EntryKind.document: return Icons.description_outlined;
      case EntryKind.archive: return Icons.archive_outlined;
      case EntryKind.apk: return Icons.android_outlined;
      case EntryKind.other: return Icons.insert_drive_file_outlined;
    }
  }

  Widget _leading(ExplorerEntry e) {
    if (e.kind == EntryKind.image && e.entity is File) {
      return ClipRRect(
        borderRadius: BorderRadius.circular(6),
        child: Image.file(
          e.entity as File,
          width: 48,
          height: 48,
          fit: BoxFit.cover,
          cacheWidth: 96,
          errorBuilder: (_, __, ___) => const Icon(Icons.image_outlined, size: 34),
        ),
      );
    }
    return Icon(_icon(e.kind), size: 34);
  }

  String formatBytes(int bytes) {
    if (bytes >= 1073741824) return '${(bytes / 1073741824).toStringAsFixed(2)} Go';
    if (bytes >= 1048576) return '${(bytes / 1048576).toStringAsFixed(2)} Mo';
    if (bytes >= 1024) return '${(bytes / 1024).toStringAsFixed(1)} Ko';
    return '$bytes o';
  }

  String _typeLabel(EntryKind kind) {
    switch (kind) {
      case EntryKind.folder: return 'Dossier';
      case EntryKind.image: return 'Image';
      case EntryKind.video: return 'Vidéo';
      case EntryKind.audio: return 'Audio';
      case EntryKind.document: return 'Document';
      case EntryKind.archive: return 'Archive';
      case EntryKind.apk: return 'APK';
      case EntryKind.other: return 'Fichier';
    }
  }

  @override
  Widget build(BuildContext context) {
    final visible = visibleEntries;
    final selectionMode = selectedPaths.isNotEmpty;

    return PopScope(
      canPop: currentDirectory.path == storageRoot,
      onPopInvokedWithResult: (didPop, _) {
        if (!didPop && currentDirectory.path != storageRoot) _goUp();
      },
      child: Scaffold(
        appBar: AppBar(
          title: Text(selectionMode
              ? '${selectedPaths.length} sélectionné(s)'
              : 'File AI Assistant'),
          leading: currentDirectory.path == storageRoot
              ? null
              : IconButton(icon: const Icon(Icons.arrow_back), onPressed: _goUp),
          actions: [
            if (selectionMode)
              IconButton(
                tooltip: 'Tout sélectionner',
                icon: const Icon(Icons.select_all),
                onPressed: _selectAllVisible,
              ),
            if (selectionMode)
              IconButton(
                tooltip: 'Annuler sélection',
                icon: const Icon(Icons.close),
                onPressed: () => setState(selectedPaths.clear),
              ),
            if (!selectionMode)
              IconButton(
                tooltip: 'Filtres',
                icon: const Icon(Icons.filter_alt_outlined),
                onPressed: _filters,
              ),
          ],
        ),
        body: Column(
          children: [
            Container(
              width: double.infinity,
              padding: const EdgeInsets.fromLTRB(12, 8, 12, 8),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    currentDirectory.path.replaceFirst(storageRoot, 'Stockage'),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 4),
                  Row(
                    children: [
                      Expanded(child: Text(status)),
                      if (loading)
                        const SizedBox(
                          width: 18,
                          height: 18,
                          child: CircularProgressIndicator(strokeWidth: 2),
                        ),
                    ],
                  ),
                ],
              ),
            ),
            const Divider(height: 1),
            Expanded(
              child: visible.isEmpty && !loading
                  ? const Center(child: Text('Aucun élément à afficher'))
                  : ListView.builder(
                      itemCount: visible.length,
                      itemBuilder: (_, i) {
                        final e = visible[i];
                        final selected = selectedPaths.contains(e.entity.path);

                        return ListTile(
                          selected: selected,
                          leading: selectionMode && !e.isFolder
                              ? Checkbox(
                                  value: selected,
                                  onChanged: (_) => _toggleSelection(e),
                                )
                              : _leading(e),
                          title: Text(
                            e.name,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                          ),
                          subtitle: Text(
                            e.isFolder
                                ? 'Dossier'
                                : '${_typeLabel(e.kind)} • ${formatBytes(e.size)}',
                          ),
                          trailing: PopupMenuButton<String>(
                            onSelected: (v) {
                              if (v == 'rename') _rename(e);
                            },
                            itemBuilder: (_) => const [
                              PopupMenuItem(
                                value: 'rename',
                                child: Text('Renommer'),
                              ),
                            ],
                          ),
                          onTap: () {
                            if (selectionMode && !e.isFolder) {
                              _toggleSelection(e);
                            } else if (e.isFolder) {
                              _loadDirectory(e.entity as Directory);
                            }
                          },
                          onLongPress: e.isFolder ? () => _rename(e) : () => _toggleSelection(e),
                        );
                      },
                    ),
            ),
          ],
        ),
        floatingActionButton: selectionMode
            ? FloatingActionButton.extended(
                onPressed: _bulkRename,
                icon: const Icon(Icons.drive_file_rename_outline),
                label: const Text('Renommer en série'),
              )
            : null,
        bottomNavigationBar: SafeArea(
          child: Material(
            elevation: 8,
            child: Padding(
              padding: const EdgeInsets.fromLTRB(8, 4, 8, 8),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  SwitchListTile(
                    dense: true,
                    contentPadding: EdgeInsets.zero,
                    value: recursiveAnalysis,
                    title: const Text('Analyser aussi les sous-dossiers'),
                    onChanged: (v) => setState(() => recursiveAnalysis = v),
                  ),
                  SwitchListTile(
                    contentPadding: EdgeInsets.zero,
                    title: const Text('Analyser tout le stockage accessible'),
                    subtitle: Text(
                      scanWholeStorage
                          ? 'Tous les dossiers accessibles + sous-dossiers'
                          : 'Seulement le dossier actuellement ouvert',
                    ),
                    value: scanWholeStorage,
                    onChanged: (v) => setState(() => scanWholeStorage = v),
                  ),
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      border: Border.all(color: Theme.of(context).dividerColor),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: const Row(
                      children: [
                        Icon(Icons.offline_bolt_outlined),
                        SizedBox(width: 8),
                        Expanded(
                          child: Text(
                            '100 % hors ligne • aucune clé API • aucune donnée envoyée',
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 8),
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      border: Border.all(
                        color: Theme.of(context).dividerColor,
                      ),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text(
                          'Workflow ChatGPT sans API',
                          style: TextStyle(
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        const SizedBox(height: 6),
                        const Text(
                          '1. Créer Snapshot  →  2. Envoyer à ChatGPT  →  '
                          '3. Télécharger FILEAI_PLAN.json  →  4. Choisir le fichier  →  AGIR',
                        ),
                        if (lastSnapshotId.isNotEmpty) ...[
                          const SizedBox(height: 8),
                          Text(
                            'Dernier snapshot : $lastSnapshotId • '
                            '$lastSnapshotFileCount fichiers',
                            style: const TextStyle(fontSize: 12),
                          ),
                        ],
                        const SizedBox(height: 10),
                        Row(
                          children: [
                            Expanded(
                              child: FilledButton.icon(
                                onPressed: snapshotBusy
                                    ? null
                                    : _createPhoneSnapshot,
                                icon: snapshotBusy
                                    ? const SizedBox(
                                        width: 18,
                                        height: 18,
                                        child: CircularProgressIndicator(
                                          strokeWidth: 2,
                                        ),
                                      )
                                    : const Icon(Icons.inventory_2_outlined),
                                label: const Text('Créer Snapshot'),
                              ),
                            ),
                            const SizedBox(width: 8),
                            Expanded(
                              child: OutlinedButton.icon(
                                onPressed: planImportBusy
                                    ? null
                                    : _importLatestChatPlan,
                                icon: planImportBusy
                                    ? const SizedBox(
                                        width: 18,
                                        height: 18,
                                        child: CircularProgressIndicator(
                                          strokeWidth: 2,
                                        ),
                                      )
                                    : const Icon(Icons.upload_file_outlined),
                                label: const Text('Choisir Plan JSON'),
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 10),
                  TextField(
                    controller: aiInstructionController,
                    minLines: 1,
                    maxLines: 3,
                    decoration: InputDecoration(
                      labelText: 'Option locale rapide (facultatif)',
                      hintText: 'Ex : Regroupe les mangas par série...',
                      border: const OutlineInputBorder(),
                      suffixIcon: const Icon(Icons.tune),
                    ),
                  ),
                  const SizedBox(height: 6),
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      border: Border.all(color: Theme.of(context).dividerColor),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: const Text('Assistant intelligent 100 % local'),
                  ),
                  const SizedBox(height: 6),
                  SizedBox(
                    width: double.infinity,
                    child: FilledButton.icon(
                      onPressed: (loading || aiBusy || actionBusy)
                          ? null
                          : _localAssistantPlan,
                      icon: aiBusy
                          ? const SizedBox(
                              width: 18,
                              height: 18,
                              child: CircularProgressIndicator(strokeWidth: 2),
                            )
                          : const Icon(Icons.psychology_alt_outlined),
                      label: const Text('Analyser et proposer'),
                    ),
                  ),
                  const SizedBox(height: 6),
                  SizedBox(
                    width: double.infinity,
                    child: OutlinedButton.icon(
                      onPressed: loading ? null : _smartGlobalScan,
                      icon: const Icon(Icons.auto_awesome),
                      label: const Text('Analyse visuelle légère (max 80)'),
                    ),
                  ),
                  const SizedBox(height: 6),
                  Row(
                    children: [
                      Expanded(
                        child: OutlinedButton.icon(
                          onPressed: _autoSelect,
                          icon: const Icon(Icons.auto_awesome_motion),
                          label: const Text('Sélection auto'),
                        ),
                      ),
                      const SizedBox(width: 8),
                      Expanded(
                        child: FilledButton.icon(
                          onPressed: loading ? null : _duplicates,
                          icon: const Icon(Icons.content_copy),
                          label: const Text('Doublons'),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
