# V13.6 Dependency Fix

Correction du conflit Pub montré par GitHub Actions : `image ^4.5.4` exige `archive 4.x`, alors que V13.5 imposait `archive ^3.6.1`. La version utilise maintenant `archive ^4.0.9`.

# V13.5 Picker + Snapshot Verification

Corrections principales :

* `Importer Plan` ouvre maintenant le sélecteur de fichiers Android.
* Tu peux sélectionner n'importe quel fichier JSON, où qu'il soit accessible par Android.
* Le fichier est lu via le Storage Access Framework / file picker, pas par recherche automatique dans Download.
* Le JSON est vérifié avant toute proposition d'action.
* Le `snapshot_id` doit correspondre au dernier snapshot de l'app.
* Le snapshot ZIP est rouvert et décodé immédiatement après création.
* L'app vérifie que les 7 fichiers obligatoires sont réellement dans le ZIP.
* Un ZIP vide ou trop petit est supprimé et signalé comme invalide.
* `inventory.json` doit être non vide.
* L'app n'affiche plus Snapshot prêt tant que ces vérifications ne passent pas.
* L'archive est épinglée sur une version dont l'API ZipFileEncoder utilisée ici est stable.
* Aucun plan importé n'est exécuté avant l'écran de vérification et le bouton AGIR.

# V13.4 Build Clean

Cette version supprime le point de panne de V13.3 :
le workflow ne lance plus `tool/patch_android10.py`.

La préparation Android est maintenant découpée en étapes séparées :
1. sauvegarde des sources Flutter
2. génération du scaffold Android
3. restauration des sources
4. configuration Android 10 directement dans le workflow
5. vérification indépendante du manifest
6. dépendances
7. analyse Dart
8. build APK

Chaque étape utilise `set -euo pipefail`, donc le nom exact de l'étape indique
immédiatement où se trouve une éventuelle erreur.

# V13.3 Stable Storage

Corrections de fond pour Android 10 :

* tous les fichiers temporaires du snapshot sont créés dans le cache privé de l'application, plus jamais à la racine `/storage/emulated/0/FileAI_Temp`;
* test réel d'écriture dans `Download/FileAI_Exports` avant de commencer un scan long;
* si Android refuse l'écriture, l'app s'arrête immédiatement et propose d'ouvrir ses paramètres;
* `WRITE_EXTERNAL_STORAGE` est déclaré exactement une fois avec `maxSdkVersion=29`;
* `requestLegacyExternalStorage=true` est forcé pour Android 10;
* le workflow bloque si les permissions sont absentes, dupliquées ou mal configurées;
* le dernier `snapshot_id` est restauré après redémarrage de l'application;
* les images de plus de 12 Mo et PDF de plus de 80 Mo sont indexés mais ne sont pas décodés en miniature, pour réduire les crashes mémoire;
* maximum 24 aperçus légers dans un snapshot;
* le plan ChatGPT reste un dry-run : aucune action n'est exécutée avant `AGIR`;
* les doublons vont uniquement en quarantaine.

# V13.2 Chat Bridge Fixed

Correction du build Android : déduplication automatique des permissions dans AndroidManifest.xml avant compilation Gradle.

# V13.1 Chat Bridge Fixed

Correction de compilation du viewer de plan importé.

# File AI Assistant V13 Chat Bridge

Sans API, sans Firebase, sans connexion directe entre ChatGPT et le téléphone.

Workflow :
1. Créer PHONE_SNAPSHOT.zip dans l'app.
2. Uploader ce ZIP dans ChatGPT.
3. Discuter et corriger le plan de rangement dans ChatGPT.
4. Demander à ChatGPT de générer FILEAI_PLAN.json.
5. Télécharger ce JSON dans Android Download.
6. Importer le plan dans l'app.
7. Dry-run et aperçu avant/après.
8. Cocher/décocher les actions.
9. Appuyer sur AGIR.

Le snapshot contient :
- inventory.json
- folder_tree.txt
- statistics.json
- duplicate_candidates.json
- FILEAI_PLAN_SCHEMA.json
- INSTRUCTIONS_FOR_CHATGPT.txt
- previews/index.json
- maximum 24 miniatures légères représentatives

Stabilité Android 10 :
- inventaire écrit progressivement sur disque
- miniatures très limitées
- PDF en aperçu basse résolution
- timeout pour les aperçus
- pauses régulières pendant le scan
- 0/1 octet ignorés
- Android/data, Android/obb, temp et quarantaine ignorés
- aucune exécution immédiate après import du plan
