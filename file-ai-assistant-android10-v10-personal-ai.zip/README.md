# File AI Assistant V10 Personal AI

Cette version reste compatible avec le workflow GitHub de la V9 et Android 10.

Priorité de l'interface :
1. Arranger / regrouper avec IA
2. Regroupement surtout selon la similarité des noms
3. Proposition de sous-dossiers
4. Proposition de format de renommage
5. Détection des doublons / versions proches
6. Analyse locale avancée disponible séparément

La clé API n'est PAS incluse dans le ZIP ni dans GitHub.
Après installation :
- ouvre l'application
- touche l'icône clé dans le champ Assistant
- colle ta clé API
- écris ton instruction
- touche Arranger / regrouper avec IA

Cette V10 affiche d'abord un plan. Elle ne laisse pas l'IA supprimer directement des fichiers.

IMPORTANT SECURITE :
OpenAI recommande de ne pas déployer une clé API dans une application mobile côté client.
Cette version est destinée au prototype personnel demandé. La clé n'est jamais commitée dans GitHub,
mais une application mobile ne peut pas garantir qu'un secret API soit impossible à extraire.
Pour une version distribuée, utiliser un backend.
