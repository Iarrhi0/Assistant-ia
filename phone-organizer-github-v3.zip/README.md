# Phone Organizer

Application Android native permettant de :

1. Choisir un dossier de stockage avec le sélecteur Android.
2. Inspecter récursivement les fichiers accessibles.
3. Calculer SHA-256, taille, MIME, date et chemin.
4. Détecter les doublons certains par hash.
5. Exporter `PHONE_SNAPSHOT_*.json`.
6. Envoyer ce snapshot à ChatGPT et préparer un `PHONE_PLAN.json`.
7. Réimporter le plan dans l'application.
8. Simuler les opérations avant exécution.
9. Exécuter les créations de dossiers, déplacements et renommages.
10. Placer les suppressions demandées dans `_PhoneOrganizer_Trash` au lieu de supprimer définitivement.

## Important

Android protège certains emplacements. L'application utilise Storage Access Framework : l'utilisateur choisit explicitement l'arborescence à laquelle il autorise l'accès.

## Format du plan

```json
{
  "plan_version": 1,
  "operations": [
    {"action":"create_folder","destination":"Documents/Finance"},
    {"action":"move","file_id":"F000001","to":"Documents/Finance/facture.pdf"},
    {"action":"rename","file_id":"F000002","new_name":"CV_2026.pdf"},
    {"action":"trash","file_id":"F000003"}
  ]
}
```

Les chemins sont relatifs à la racine choisie dans l'application.

## Build GitHub

Le workflow `.github/workflows/build-apk.yml` génère automatiquement l'APK Debug.
Après le build : GitHub > Actions > Build Android APK > Artifacts > PhoneOrganizer-debug.


## V3

- Barre de progression avec pourcentage pendant l'inspection.
- Barre de progression pendant l'exécution du plan.
- Inspection limitée au dossier explicitement choisi par l'utilisateur.
- Exclusion des dossiers/fichiers cachés et de plusieurs emplacements système courants.
- Aucun scan global forcé du téléphone.
