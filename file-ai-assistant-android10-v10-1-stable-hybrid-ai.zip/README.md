# V10.1 Stable Hybrid AI
* Android INTERNET and network-state permissions forced by build.
* Hybrid mode falls back to local organization when OpenAI is unreachable.
* Offline mode works without ChatGPT.
* OpenAI-only mode remains available.
* Visual analysis reduced from 1200 to 80 candidates.
* PDF preview rendering reduced to ~256 px to lower RAM pressure.
* Offline organizer prioritizes similar filenames and exact duplicate hashes.
