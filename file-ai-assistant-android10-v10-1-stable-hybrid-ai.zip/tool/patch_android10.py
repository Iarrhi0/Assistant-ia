from pathlib import Path

manifest = Path("android/app/src/main/AndroidManifest.xml")
text = manifest.read_text(encoding="utf-8")

permissions = """    <uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE" />
    <uses-permission android:name="android.permission.WRITE_EXTERNAL_STORAGE" android:maxSdkVersion="29" />
"""

if "android.permission.READ_EXTERNAL_STORAGE" not in text:
    text = text.replace("<manifest", "<manifest", 1)
    pos = text.find(">")
    text = text[:pos+1] + "\n" + permissions + text[pos+1:]

if 'android:requestLegacyExternalStorage="true"' not in text:
    text = text.replace(
        "<application",
        '<application\n        android:requestLegacyExternalStorage="true"',
        1,
    )

text = text.replace('android:label="file_ai_assistant"', 'android:label="File AI Assistant"')
manifest.write_text(text, encoding="utf-8")

# Keep min SDK compatible with Android 10. Flutter defaults are normally already lower,
# but patch common Gradle/KTS forms if present.
gradle_candidates = [
    Path("android/app/build.gradle.kts"),
    Path("android/app/build.gradle"),
]
for gradle in gradle_candidates:
    if not gradle.exists():
        continue
    g = gradle.read_text(encoding="utf-8")
    g = g.replace("minSdk = flutter.minSdkVersion", "minSdk = 23")
    g = g.replace("minSdkVersion flutter.minSdkVersion", "minSdkVersion 23")
    gradle.write_text(g, encoding="utf-8")

print("Android 10 configuration applied.")

from pathlib import Path
manifest=Path("android/app/src/main/AndroidManifest.xml")
if manifest.exists():
    x=manifest.read_text(encoding="utf-8")
    for perm in ['<uses-permission android:name="android.permission.INTERNET"/>','<uses-permission android:name="android.permission.ACCESS_NETWORK_STATE"/>']:
        if perm not in x:
            pos=x.find(">")
            x=x[:pos+1]+"\\n    "+perm+x[pos+1:]
    manifest.write_text(x,encoding="utf-8")
