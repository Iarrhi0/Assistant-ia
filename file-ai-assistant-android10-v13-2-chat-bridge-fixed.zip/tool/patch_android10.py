from pathlib import Path

manifest = Path("android/app/src/main/AndroidManifest.xml")
text = manifest.read_text(encoding="utf-8")

permissions = """    <uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE" />
    <uses-permission android:name="android.permission.WRITE_EXTERNAL_STORAGE" android:maxSdkVersion="29" />
"""

if "android.permission.READ_EXTERNAL_STORAGE" not in text:
    text = text.replace("<manifest", "<manifest", 1)
    pos = text.find(">")
    text = text[:pos+1] + "\n" + permissions + text[pos+1:]

if 'android:requestLegacyExternalStorage="true"' not in text:
    text = text.replace(
        "<application",
        '<application\n        android:requestLegacyExternalStorage="true"',
        1,
    )

text = text.replace('android:label="file_ai_assistant"', 'android:label="File AI Assistant"')
manifest.write_text(text, encoding="utf-8")

# Keep min SDK compatible with Android 10. Flutter defaults are normally already lower,
# but patch common Gradle/KTS forms if present.
gradle_candidates = [
    Path("android/app/build.gradle.kts"),
    Path("android/app/build.gradle"),
]
for gradle in gradle_candidates:
    if not gradle.exists():
        continue
    g = gradle.read_text(encoding="utf-8")
    g = g.replace("minSdk = flutter.minSdkVersion", "minSdk = 23")
    g = g.replace("minSdkVersion flutter.minSdkVersion", "minSdkVersion 23")
    gradle.write_text(g, encoding="utf-8")

print("Android 10 configuration applied.")

from pathlib import Path
manifest=Path("android/app/src/main/AndroidManifest.xml")
if manifest.exists():
    x=manifest.read_text(encoding="utf-8")
    for perm in ['<uses-permission android:name="android.permission.INTERNET"/>','<uses-permission android:name="android.permission.ACCESS_NETWORK_STATE"/>']:
        if perm not in x:
            pos=x.find(">")
            x=x[:pos+1]+"\\n    "+perm+x[pos+1:]
    manifest.write_text(x,encoding="utf-8")

from pathlib import Path
manifest=Path("android/app/src/main/AndroidManifest.xml")
if manifest.exists():
    x=manifest.read_text(encoding="utf-8")
    perms=[
      '<uses-permission android:name="android.permission.INTERNET"/>',
      '<uses-permission android:name="android.permission.ACCESS_NETWORK_STATE"/>',
      '<uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE"/>',
      '<uses-permission android:name="android.permission.WRITE_EXTERNAL_STORAGE" android:maxSdkVersion="28"/>'
    ]
    for perm in perms:
        if perm not in x:
            pos=x.find(">")
            x=x[:pos+1]+"\n    "+perm+x[pos+1:]
    manifest.write_text(x,encoding="utf-8")


# Final manifest permission cleanup: idempotent and duplicate-safe.
from pathlib import Path
import re

manifest = Path("android/app/src/main/AndroidManifest.xml")
if manifest.exists():
    x = manifest.read_text(encoding="utf-8")

    # Remove duplicate uses-permission declarations by android:name,
    # keeping only the first occurrence.
    pattern = re.compile(
        r'\s*<uses-permission\b[^>]*android:name="([^"]+)"[^>]*/>\s*',
        re.MULTILINE,
    )

    seen = set()
    rebuilt = []
    last = 0

    for m in pattern.finditer(x):
        rebuilt.append(x[last:m.start()])
        name = m.group(1)

        if name not in seen:
            seen.add(name)
            rebuilt.append("\n    " + m.group(0).strip())

        last = m.end()

    rebuilt.append(x[last:])
    x = "".join(rebuilt)

    required = [
        '<uses-permission android:name="android.permission.INTERNET"/>',
        '<uses-permission android:name="android.permission.ACCESS_NETWORK_STATE"/>',
        '<uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE"/>',
        '<uses-permission android:name="android.permission.WRITE_EXTERNAL_STORAGE" android:maxSdkVersion="28"/>',
    ]

    # Insert any missing required permission exactly once after <manifest ...>.
    existing_names = set(
        re.findall(
            r'<uses-permission\b[^>]*android:name="([^"]+)"[^>]*/>',
            x,
        )
    )

    insert_at = x.find(">")
    if insert_at != -1:
        additions = []
        for perm in required:
            name_match = re.search(r'android:name="([^"]+)"', perm)
            if not name_match:
                continue
            name = name_match.group(1)
            if name not in existing_names:
                additions.append("    " + perm)
                existing_names.add(name)

        if additions:
            x = x[:insert_at + 1] + "\n" + "\n".join(additions) + x[insert_at + 1:]

    # Normalize excessive blank lines around permissions.
    x = re.sub(r'\n{3,}', '\n\n', x)

    manifest.write_text(x, encoding="utf-8")
