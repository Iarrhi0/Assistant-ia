# File AI Assistant V8 Smart Organizer

Version Android 10 centrée sur l'automatisation.

## Nouveau mode Organiser automatiquement

L'application analyse automatiquement les dossiers utilisateur principaux :
Download, Documents, DCIM, Pictures, Movies, Music, ainsi que le dossier actuellement ouvert.

Elle ignore les zones système et techniques déjà exclues par l'explorateur.

### Détection en deux niveaux

1. Doublons exacts
   - même taille
   - SHA-256 identique
   - confiance 100 %

2. Fichiers probablement liés
   - nom normalisé
   - mots communs
   - même extension/type
   - taille identique, proche ou différente à cause d'une compression
   - score de confiance

L'analyse peut donc rapprocher des fichiers stockés dans des dossiers différents.

### Sécurité

- aucune suppression automatique
- aucun fichier système touché
- les fichiers de 0 ou 1 octet restent ignorés
- le plus gros fichier n'est pas automatiquement considéré comme le meilleur
- les résultats incertains restent des suggestions
- le plan de rangement est prévisualisé avant toute modification

### Important

La comparaison visuelle profonde de pages PDF et d'images recompressées nécessitera une étape supplémentaire
avec perceptual hashing / rendu de pages. La V8 prépare l'architecture et couvre déjà les doublons exacts,
noms très proches et tailles proches/différentes.

## Build GitHub

Mettre le ZIP V8 à la racine du dépôt et le workflow dans `.github/workflows/`.

Actions > Build APK Smart Organizer > Run workflow
