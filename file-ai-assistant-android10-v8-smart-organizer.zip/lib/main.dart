import 'dart:io';
import 'package:crypto/crypto.dart';
import 'package:flutter/material.dart';
import 'package:path/path.dart' as p;
import 'package:permission_handler/permission_handler.dart';


String normalizedFileName(String path) {
  var name = p.basenameWithoutExtension(path).toLowerCase();
  name = name.replaceAll(RegExp(r'[_\-.]+'), ' ');
  name = name.replaceAll(RegExp(r'\b(copy|copie|scan|vf|fr|gratuit|final|new)\b'), ' ');
  name = name.replaceAll(RegExp(r'\s+'), ' ').trim();
  return name;
}

double nameSimilarity(String a, String b) {
  final x = normalizedFileName(a);
  final y = normalizedFileName(b);
  if (x == y) return 1.0;
  if (x.isEmpty || y.isEmpty) return 0.0;

  final ax = x.split(' ').where((e) => e.length > 1).toSet();
  final by = y.split(' ').where((e) => e.length > 1).toSet();
  if (ax.isEmpty || by.isEmpty) return 0.0;

  final intersection = ax.intersection(by).length;
  final union = ax.union(by).length;
  final jaccard = union == 0 ? 0.0 : intersection / union;

  final contains = (x.contains(y) || y.contains(x)) ? 0.18 : 0.0;
  return (jaccard + contains).clamp(0.0, 1.0);
}

double sizeSimilarity(int a, int b) {
  if (a <= 0 || b <= 0) return 0.0;
  final maxSize = a > b ? a : b;
  final minSize = a < b ? a : b;
  return minSize / maxSize;
}

class SimilarFileGroup {
  final List<ExplorerEntry> files;
  final double confidence;
  final bool exact;
  const SimilarFileGroup(this.files, this.confidence, {this.exact = false});
}

void main() => runApp(const FileAiApp());

class FileAiApp extends StatelessWidget {
  const FileAiApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'File AI Assistant',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF2563EB)),
        useMaterial3: true,
      ),
      home: const ExplorerPage(),
    );
  }
}

enum EntryKind { folder, image, video, audio, document, archive, apk, other }

class ExplorerEntry {
  final FileSystemEntity entity;
  final EntryKind kind;
  final int size;
  final DateTime modified;
  const ExplorerEntry(this.entity, this.kind, this.size, this.modified);

  bool get isFolder => entity is Directory;
  String get name => p.basename(entity.path);
}

class ExplorerPage extends StatefulWidget {
  const ExplorerPage({super.key});

  @override
  State<ExplorerPage> createState() => _ExplorerPageState();
}

class _ExplorerPageState extends State<ExplorerPage> {
  static const storageRoot = '/storage/emulated/0';
  static const minimumUsefulFileSize = 2;

  static const ignoredFolderNames = {
    'android',
    '.android_secure',
    'lost.dir',
    '.thumbnails',
    '.trash',
    '.trashed',
    '.recycle',
    '.recyclebin',
    '.git',
    '__pycache__',
    '_fileai_quarantine',
  };

  final Set<String> selectedPaths = {};
  final Set<EntryKind> activeFilters = {};

  Directory currentDirectory = Directory(storageRoot);
  List<ExplorerEntry> entries = [];
  bool loading = false;
  bool recursiveAnalysis = true;
  bool globalScan = false;
  List<SimilarFileGroup> similarGroups = [];
  String status = 'Prêt';

  @override
  void initState() {
    super.initState();
    _start();
  }

  Future<void> _start() async {
    final permission = await Permission.storage.request();
    if (!permission.isGranted) {
      if (permission.isPermanentlyDenied) await openAppSettings();
      if (mounted) setState(() => status = 'Autorisation stockage nécessaire');
      return;
    }
    await _loadDirectory(currentDirectory);
  }

  bool _ignored(String path) {
    final lower = path.toLowerCase().replaceAll('\\', '/');
    if (lower.contains('/android/data/') ||
        lower.contains('/android/obb/') ||
        lower.contains('/android/media/')) {
      return true;
    }

    final parts = p.split(path).map((e) => e.toLowerCase());
    return parts.any(ignoredFolderNames.contains);
  }

  EntryKind _kind(String path, {bool folder = false}) {
    if (folder) return EntryKind.folder;
    final ext = p.extension(path).toLowerCase();

    if ({'.jpg','.jpeg','.png','.webp','.gif','.bmp','.heic'}.contains(ext)) {
      return EntryKind.image;
    }
    if ({'.mp4','.mkv','.avi','.mov','.webm','.3gp','.m4v'}.contains(ext)) {
      return EntryKind.video;
    }
    if ({'.mp3','.wav','.m4a','.aac','.flac','.ogg','.opus'}.contains(ext)) {
      return EntryKind.audio;
    }
    if ({'.pdf','.doc','.docx','.xls','.xlsx','.ppt','.pptx','.txt','.rtf','.csv','.epub'}.contains(ext)) {
      return EntryKind.document;
    }
    if ({'.zip','.rar','.7z','.tar','.gz'}.contains(ext)) {
      return EntryKind.archive;
    }
    if (ext == '.apk') return EntryKind.apk;
    return EntryKind.other;
  }

  Future<ExplorerEntry?> _entry(FileSystemEntity entity) async {
    try {
      if (_ignored(entity.path)) return null;
      final stat = await entity.stat();

      if (entity is Directory) {
        return ExplorerEntry(entity, EntryKind.folder, 0, stat.modified);
      }

      if (entity is File) {
        if (stat.size < minimumUsefulFileSize) return null;
        return ExplorerEntry(entity, _kind(entity.path), stat.size, stat.modified);
      }
    } catch (_) {}
    return null;
  }

  Future<void> _loadDirectory(Directory dir) async {
    setState(() {
      loading = true;
      selectedPaths.clear();
      status = 'Ouverture...';
    });

    final list = <ExplorerEntry>[];

    try {
      await for (final entity in dir.list(followLinks: false)) {
        final item = await _entry(entity);
        if (item != null) list.add(item);
      }

      list.sort((a, b) {
        if (a.isFolder != b.isFolder) return a.isFolder ? -1 : 1;
        return a.name.toLowerCase().compareTo(b.name.toLowerCase());
      });

      if (!mounted) return;
      setState(() {
        currentDirectory = dir;
        entries = list;
        loading = false;
        status = '${list.where((e) => e.isFolder).length} dossier(s) • '
            '${list.where((e) => !e.isFolder).length} fichier(s)';
      });
    } catch (_) {
      if (!mounted) return;
      setState(() {
        loading = false;
        status = 'Dossier inaccessible';
      });
    }
  }

  List<ExplorerEntry> get visibleEntries {
    if (activeFilters.isEmpty) return entries;
    return entries.where((e) => e.isFolder || activeFilters.contains(e.kind)).toList();
  }

  Future<void> _goUp() async {
    if (currentDirectory.path == storageRoot) return;
    final parent = currentDirectory.parent;
    if (parent.path.startsWith(storageRoot)) await _loadDirectory(parent);
  }

  void _toggleSelection(ExplorerEntry entry) {
    if (entry.isFolder) return;
    setState(() {
      if (!selectedPaths.add(entry.entity.path)) {
        selectedPaths.remove(entry.entity.path);
      }
    });
  }

  void _selectAllVisible() {
    setState(() {
      selectedPaths
        ..clear()
        ..addAll(visibleEntries.where((e) => !e.isFolder).map((e) => e.entity.path));
    });
  }

  void _selectKinds(Set<EntryKind> kinds) {
    setState(() {
      selectedPaths
        ..clear()
        ..addAll(entries.where((e) => !e.isFolder && kinds.contains(e.kind))
            .map((e) => e.entity.path));
    });
  }

  Future<void> _autoSelect() async {
    final chosen = <EntryKind>{};

    await showDialog(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, local) => AlertDialog(
          title: const Text('Sélection automatique'),
          content: SingleChildScrollView(
            child: Column(
              children: [
                _kindCheck(local, chosen, EntryKind.image, 'Images', Icons.image_outlined),
                _kindCheck(local, chosen, EntryKind.video, 'Vidéos', Icons.movie_outlined),
                _kindCheck(local, chosen, EntryKind.audio, 'Audio', Icons.music_note_outlined),
                _kindCheck(local, chosen, EntryKind.document, 'Documents / textes', Icons.description_outlined),
                _kindCheck(local, chosen, EntryKind.archive, 'Archives', Icons.archive_outlined),
                _kindCheck(local, chosen, EntryKind.apk, 'APK', Icons.android_outlined),
                _kindCheck(local, chosen, EntryKind.other, 'Autres', Icons.insert_drive_file_outlined),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(ctx),
              child: const Text('Annuler'),
            ),
            FilledButton(
              onPressed: () {
                Navigator.pop(ctx);
                _selectKinds(chosen);
              },
              child: const Text('Sélectionner'),
            ),
          ],
        ),
      ),
    );
  }

  Widget _kindCheck(
    StateSetter local,
    Set<EntryKind> chosen,
    EntryKind kind,
    String label,
    IconData icon,
  ) {
    return CheckboxListTile(
      value: chosen.contains(kind),
      secondary: Icon(icon),
      title: Text(label),
      onChanged: (v) {
        local(() {
          if (v == true) {
            chosen.add(kind);
          } else {
            chosen.remove(kind);
          }
        });
      },
    );
  }

  Future<void> _rename(ExplorerEntry entry) async {
    final c = TextEditingController(text: entry.name);
    final name = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(entry.isFolder ? 'Renommer le dossier' : 'Renommer le fichier'),
        content: TextField(
          controller: c,
          autofocus: true,
          decoration: const InputDecoration(
            labelText: 'Nouveau nom',
            border: OutlineInputBorder(),
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Annuler')),
          FilledButton(
            onPressed: () => Navigator.pop(ctx, c.text.trim()),
            child: const Text('Renommer'),
          ),
        ],
      ),
    );

    if (name == null || name.isEmpty || name == entry.name) return;

    try {
      final target = p.join(p.dirname(entry.entity.path), name);
      if (entry.entity is Directory) {
        await (entry.entity as Directory).rename(target);
      } else {
        await (entry.entity as File).rename(target);
      }
      await _loadDirectory(currentDirectory);
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Renommage impossible')),
        );
      }
    }
  }

  Future<List<ExplorerEntry>> _analysisFiles() async {
    final chosen = entries.where((e) => selectedPaths.contains(e.entity.path) && !e.isFolder).toList();
    if (chosen.isNotEmpty) return chosen;

    if (!recursiveAnalysis) {
      return entries.where((e) => !e.isFolder).toList();
    }

    final result = <ExplorerEntry>[];
    await for (final entity in currentDirectory.list(recursive: true, followLinks: false)) {
      final item = await _entry(entity);
      if (item != null && !item.isFolder) result.add(item);
    }
    return result;
  }

  Future<String> _hash(File file) async {
    final digest = await sha256.bind(file.openRead()).first;
    return digest.toString();
  }

  Future<void> _duplicates() async {
    setState(() {
      loading = true;
      status = 'Recherche des doublons...';
    });

    final files = await _analysisFiles();
    final bySize = <int, List<ExplorerEntry>>{};

    for (final f in files) {
      bySize.putIfAbsent(f.size, () => []).add(f);
    }

    final byHash = <String, List<ExplorerEntry>>{};

    for (final group in bySize.values.where((g) => g.length > 1)) {
      for (final f in group) {
        try {
          final hash = await _hash(f.entity as File);
          byHash.putIfAbsent('${f.size}:$hash', () => []).add(f);
        } catch (_) {}
      }
    }

    final groups = byHash.values.where((g) => g.length > 1).toList();

    if (!mounted) return;
    setState(() {
      loading = false;
      status = '${groups.length} groupe(s) de doublons';
    });

    await showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (ctx) => DraggableScrollableSheet(
        expand: false,
        initialChildSize: .82,
        maxChildSize: .95,
        builder: (_, controller) => Column(
          children: [
            const ListTile(
              title: Text('Doublons exacts', style: TextStyle(fontWeight: FontWeight.bold)),
              subtitle: Text('Même taille + même empreinte SHA-256'),
            ),
            Expanded(
              child: groups.isEmpty
                  ? const Center(child: Text('Aucun doublon exact détecté'))
                  : ListView.builder(
                      controller: controller,
                      itemCount: groups.length,
                      itemBuilder: (_, i) {
                        final group = groups[i];
                        return ExpansionTile(
                          title: Text('${group.length} copies'),
                          subtitle: Text(formatBytes(group.first.size)),
                          children: group.map((e) => ListTile(
                            dense: true,
                            leading: Icon(_icon(e.kind)),
                            title: Text(e.name),
                            subtitle: Text(e.entity.path),
                          )).toList(),
                        );
                      },
                    ),
            ),
          ],
        ),
      ),
    );
  }


  Future<List<ExplorerEntry>> _globalUserFiles() async {
    final roots = <Directory>[
      Directory('$storageRoot/Download'),
      Directory('$storageRoot/Documents'),
      Directory('$storageRoot/DCIM'),
      Directory('$storageRoot/Pictures'),
      Directory('$storageRoot/Movies'),
      Directory('$storageRoot/Music'),
    ];

    // Also include the currently opened user folder even if it is custom.
    if (!roots.any((d) => d.path == currentDirectory.path)) {
      roots.add(currentDirectory);
    }

    final seen = <String>{};
    final result = <ExplorerEntry>[];

    for (final root in roots) {
      if (!await root.exists()) continue;
      try {
        await for (final entity in root.list(recursive: true, followLinks: false)) {
          if (seen.contains(entity.path)) continue;
          seen.add(entity.path);
          final item = await _entry(entity);
          if (item != null && !item.isFolder) result.add(item);
        }
      } catch (_) {}
    }
    return result;
  }

  Future<void> _smartGlobalScan() async {
    setState(() {
      loading = true;
      globalScan = true;
      similarGroups = [];
      status = 'Analyse intelligente des dossiers utilisateur...';
    });

    final files = await _globalUserFiles();

    // Phase 1: exact duplicates, grouped cheaply by size before hashing.
    final bySize = <int, List<ExplorerEntry>>{};
    for (final f in files) {
      bySize.putIfAbsent(f.size, () => []).add(f);
    }

    final exactByHash = <String, List<ExplorerEntry>>{};
    for (final candidates in bySize.values.where((g) => g.length > 1)) {
      for (final f in candidates) {
        try {
          final hash = await _hash(f.entity as File);
          exactByHash.putIfAbsent('${f.size}:$hash', () => []).add(f);
        } catch (_) {}
      }
    }

    final groups = <SimilarFileGroup>[];
    final exactPaths = <String>{};

    for (final g in exactByHash.values.where((g) => g.length > 1)) {
      groups.add(SimilarFileGroup(g, 1.0, exact: true));
      exactPaths.addAll(g.map((e) => e.entity.path));
    }

    // Phase 2: probable same content/version using normalized names + type + size.
    // Bucket by first meaningful token to avoid O(n²) over the entire phone.
    final buckets = <String, List<ExplorerEntry>>{};
    for (final f in files) {
      if (exactPaths.contains(f.entity.path)) continue;
      final norm = normalizedFileName(f.entity.path);
      final tokens = norm.split(' ').where((x) => x.length >= 3).toList();
      final key = tokens.isEmpty ? p.extension(f.name).toLowerCase() : tokens.first;
      buckets.putIfAbsent('${f.kind}:$key', () => []).add(f);
    }

    for (final bucket in buckets.values) {
      if (bucket.length < 2) continue;
      final used = <String>{};

      for (int i = 0; i < bucket.length; i++) {
        final a = bucket[i];
        if (used.contains(a.entity.path)) continue;
        final cluster = <ExplorerEntry>[a];
        double bestConfidence = 0;

        for (int j = i + 1; j < bucket.length; j++) {
          final b = bucket[j];
          if (used.contains(b.entity.path)) continue;
          if (p.extension(a.name).toLowerCase() != p.extension(b.name).toLowerCase()) {
            continue;
          }

          final ns = nameSimilarity(a.name, b.name);
          final ss = sizeSimilarity(a.size, b.size);
          final confidence = (ns * 0.72) + (ss * 0.28);

          // High name resemblance can tolerate compression differences.
          if ((ns >= 0.72 && confidence >= 0.72) || (ns >= 0.88 && ss >= 0.45)) {
            cluster.add(b);
            used.add(b.entity.path);
            if (confidence > bestConfidence) bestConfidence = confidence;
          }
        }

        if (cluster.length > 1) {
          used.add(a.entity.path);
          groups.add(SimilarFileGroup(cluster, bestConfidence.clamp(0.0, 0.99)));
        }
      }
    }

    groups.sort((a, b) => b.confidence.compareTo(a.confidence));

    if (!mounted) return;
    setState(() {
      loading = false;
      similarGroups = groups;
      status = '${files.length} fichiers utiles analysés • ${groups.length} groupe(s) détecté(s)';
    });

    await _showSmartPlan(files.length);
  }

  Future<void> _showSmartPlan(int scannedCount) async {
    await showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (ctx) => DraggableScrollableSheet(
        expand: false,
        initialChildSize: .9,
        maxChildSize: .97,
        minChildSize: .55,
        builder: (_, controller) => Column(
          children: [
            ListTile(
              leading: const Icon(Icons.auto_awesome),
              title: const Text(
                'Plan intelligent proposé',
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
              subtitle: Text(
                '$scannedCount fichiers analysés dans les dossiers utilisateur. '
                'Aucune suppression automatique.',
              ),
            ),
            const Divider(height: 1),
            Expanded(
              child: similarGroups.isEmpty
                  ? const Center(child: Text('Aucun groupe suffisamment fiable détecté'))
                  : ListView.builder(
                      controller: controller,
                      itemCount: similarGroups.length,
                      itemBuilder: (_, index) {
                        final group = similarGroups[index];
                        final pct = (group.confidence * 100).round();
                        final sorted = [...group.files]
                          ..sort((a, b) => b.size.compareTo(a.size));
                        final suggestedKeep = sorted.first;

                        return Card(
                          margin: const EdgeInsets.fromLTRB(10, 7, 10, 7),
                          child: ExpansionTile(
                            leading: Icon(
                              group.exact
                                  ? Icons.verified_outlined
                                  : Icons.auto_awesome_motion,
                            ),
                            title: Text(
                              group.exact
                                  ? '${group.files.length} doublons exacts'
                                  : '${group.files.length} fichiers probablement liés',
                            ),
                            subtitle: Text(
                              group.exact
                                  ? 'Confiance 100 %'
                                  : 'Confiance $pct % • noms et tailles comparés',
                            ),
                            children: [
                              ...sorted.map(
                                (f) => ListTile(
                                  dense: true,
                                  leading: Icon(_icon(f.kind)),
                                  title: Text(f.name),
                                  subtitle: Text(
                                    '${formatBytes(f.size)}\n${f.entity.path}',
                                  ),
                                  isThreeLine: true,
                                ),
                              ),
                              Padding(
                                padding: const EdgeInsets.all(12),
                                child: Align(
                                  alignment: Alignment.centerLeft,
                                  child: Text(
                                    group.exact
                                        ? 'Suggestion : conserver une copie et déplacer les autres en quarantaine.'
                                        : 'Suggestion provisoire : regrouper ces fichiers. '
                                          'Le plus volumineux (${suggestedKeep.name}) n’est pas supprimé automatiquement, '
                                          'car plus lourd ne signifie pas toujours meilleure qualité.',
                                  ),
                                ),
                              ),
                            ],
                          ),
                        );
                      },
                    ),
            ),
            Padding(
              padding: const EdgeInsets.all(12),
              child: Row(
                children: [
                  Expanded(
                    child: OutlinedButton(
                      onPressed: () => Navigator.pop(ctx),
                      child: const Text('Fermer'),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: FilledButton.icon(
                      onPressed: () {
                        Navigator.pop(ctx);
                        _showOrganizationProposal();
                      },
                      icon: const Icon(Icons.folder_copy_outlined),
                      label: const Text('Voir rangement'),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _showOrganizationProposal() async {
    final candidates = <String, List<ExplorerEntry>>{};

    for (final group in similarGroups.where((g) => !g.exact && g.confidence >= .72)) {
      final first = group.files.first;
      final norm = normalizedFileName(first.name);
      final words = norm.split(' ').where((w) => w.length >= 3).take(4).toList();
      if (words.isEmpty) continue;
      final folderName = words.map((w) => '${w[0].toUpperCase()}${w.substring(1)}').join(' ');
      candidates.putIfAbsent(folderName, () => []).addAll(group.files);
    }

    await showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Rangement proposé'),
        content: SizedBox(
          width: double.maxFinite,
          height: 430,
          child: candidates.isEmpty
              ? const Center(
                  child: Text(
                    'Pas assez de groupes fiables pour proposer un déplacement automatique.',
                  ),
                )
              : ListView(
                  children: candidates.entries.map((e) {
                    final unique = {for (final f in e.value) f.entity.path: f}.values.toList();
                    return ExpansionTile(
                      leading: const Icon(Icons.folder_outlined),
                      title: Text(e.key),
                      subtitle: Text('${unique.length} fichier(s) à regrouper'),
                      children: unique.map((f) => ListTile(
                        dense: true,
                        title: Text(f.name),
                        subtitle: Text(f.entity.path),
                      )).toList(),
                    );
                  }).toList(),
                ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Fermer'),
          ),
          FilledButton(
            onPressed: candidates.isEmpty
                ? null
                : () {
                    Navigator.pop(ctx);
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(
                        content: Text(
                          'Mode aperçu : aucune modification appliquée. '
                          'La validation destructive sera ajoutée séparément.',
                        ),
                      ),
                    );
                  },
            child: const Text('Prévisualiser seulement'),
          ),
        ],
      ),
    );
  }


  Future<void> _bulkRename() async {
    final files = entries.where((e) => selectedPaths.contains(e.entity.path) && !e.isFolder).toList();
    if (files.isEmpty) return;

    final c = TextEditingController(text: p.basename(currentDirectory.path));
    final prefix = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Renommage en série'),
        content: TextField(
          controller: c,
          decoration: const InputDecoration(
            labelText: 'Nom commun',
            helperText: 'Résultat : Nom_001.ext, Nom_002.ext...',
            border: OutlineInputBorder(),
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Annuler')),
          FilledButton(
            onPressed: () => Navigator.pop(ctx, c.text.trim()),
            child: const Text('Continuer'),
          ),
        ],
      ),
    );

    if (prefix == null || prefix.isEmpty) return;

    final preview = <MapEntry<ExplorerEntry, String>>[];
    for (int i = 0; i < files.length; i++) {
      final ext = p.extension(files[i].name);
      preview.add(MapEntry(
        files[i],
        '${prefix}_${(i + 1).toString().padLeft(3, '0')}$ext',
      ));
    }

    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Prévisualisation'),
        content: SizedBox(
          width: double.maxFinite,
          height: 400,
          child: ListView(
            children: preview.map((x) => ListTile(
              dense: true,
              title: Text(x.key.name),
              subtitle: Text('→ ${x.value}'),
            )).toList(),
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Annuler')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Appliquer')),
        ],
      ),
    );

    if (ok != true) return;

    int renamed = 0;
    for (final x in preview) {
      try {
        final file = x.key.entity as File;
        var dest = p.join(p.dirname(file.path), x.value);
        int n = 2;
        while (await File(dest).exists()) {
          final ext = p.extension(x.value);
          final stem = p.basenameWithoutExtension(x.value);
          dest = p.join(p.dirname(file.path), '${stem}_${n.toString().padLeft(3, '0')}$ext');
          n++;
        }
        await file.rename(dest);
        renamed++;
      } catch (_) {}
    }

    selectedPaths.clear();
    await _loadDirectory(currentDirectory);
    if (mounted) setState(() => status = '$renamed fichier(s) renommé(s)');
  }

  Future<void> _filters() async {
    await showModalBottomSheet(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, local) {
          Widget filter(EntryKind kind, String label) {
            return FilterChip(
              selected: activeFilters.contains(kind),
              label: Text(label),
              onSelected: (v) {
                local(() {
                  setState(() {
                    if (v) {
                      activeFilters.add(kind);
                    } else {
                      activeFilters.remove(kind);
                    }
                  });
                });
              },
            );
          }

          return SafeArea(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Wrap(
                spacing: 8,
                runSpacing: 8,
                children: [
                  filter(EntryKind.image, 'Images'),
                  filter(EntryKind.video, 'Vidéos'),
                  filter(EntryKind.audio, 'Audio'),
                  filter(EntryKind.document, 'Documents'),
                  filter(EntryKind.archive, 'Archives'),
                  filter(EntryKind.apk, 'APK'),
                  filter(EntryKind.other, 'Autres'),
                  ActionChip(
                    label: const Text('Tout afficher'),
                    onPressed: () => local(() => setState(activeFilters.clear)),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  IconData _icon(EntryKind kind) {
    switch (kind) {
      case EntryKind.folder: return Icons.folder;
      case EntryKind.image: return Icons.image_outlined;
      case EntryKind.video: return Icons.movie_outlined;
      case EntryKind.audio: return Icons.music_note_outlined;
      case EntryKind.document: return Icons.description_outlined;
      case EntryKind.archive: return Icons.archive_outlined;
      case EntryKind.apk: return Icons.android_outlined;
      case EntryKind.other: return Icons.insert_drive_file_outlined;
    }
  }

  Widget _leading(ExplorerEntry e) {
    if (e.kind == EntryKind.image && e.entity is File) {
      return ClipRRect(
        borderRadius: BorderRadius.circular(6),
        child: Image.file(
          e.entity as File,
          width: 48,
          height: 48,
          fit: BoxFit.cover,
          cacheWidth: 96,
          errorBuilder: (_, __, ___) => const Icon(Icons.image_outlined, size: 34),
        ),
      );
    }
    return Icon(_icon(e.kind), size: 34);
  }

  String formatBytes(int bytes) {
    if (bytes >= 1073741824) return '${(bytes / 1073741824).toStringAsFixed(2)} Go';
    if (bytes >= 1048576) return '${(bytes / 1048576).toStringAsFixed(2)} Mo';
    if (bytes >= 1024) return '${(bytes / 1024).toStringAsFixed(1)} Ko';
    return '$bytes o';
  }

  String _typeLabel(EntryKind kind) {
    switch (kind) {
      case EntryKind.folder: return 'Dossier';
      case EntryKind.image: return 'Image';
      case EntryKind.video: return 'Vidéo';
      case EntryKind.audio: return 'Audio';
      case EntryKind.document: return 'Document';
      case EntryKind.archive: return 'Archive';
      case EntryKind.apk: return 'APK';
      case EntryKind.other: return 'Fichier';
    }
  }

  @override
  Widget build(BuildContext context) {
    final visible = visibleEntries;
    final selectionMode = selectedPaths.isNotEmpty;

    return PopScope(
      canPop: currentDirectory.path == storageRoot,
      onPopInvokedWithResult: (didPop, _) {
        if (!didPop && currentDirectory.path != storageRoot) _goUp();
      },
      child: Scaffold(
        appBar: AppBar(
          title: Text(selectionMode
              ? '${selectedPaths.length} sélectionné(s)'
              : 'File AI Assistant'),
          leading: currentDirectory.path == storageRoot
              ? null
              : IconButton(icon: const Icon(Icons.arrow_back), onPressed: _goUp),
          actions: [
            if (selectionMode)
              IconButton(
                tooltip: 'Tout sélectionner',
                icon: const Icon(Icons.select_all),
                onPressed: _selectAllVisible,
              ),
            if (selectionMode)
              IconButton(
                tooltip: 'Annuler sélection',
                icon: const Icon(Icons.close),
                onPressed: () => setState(selectedPaths.clear),
              ),
            if (!selectionMode)
              IconButton(
                tooltip: 'Filtres',
                icon: const Icon(Icons.filter_alt_outlined),
                onPressed: _filters,
              ),
          ],
        ),
        body: Column(
          children: [
            Container(
              width: double.infinity,
              padding: const EdgeInsets.fromLTRB(12, 8, 12, 8),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    currentDirectory.path.replaceFirst(storageRoot, 'Stockage'),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 4),
                  Row(
                    children: [
                      Expanded(child: Text(status)),
                      if (loading)
                        const SizedBox(
                          width: 18,
                          height: 18,
                          child: CircularProgressIndicator(strokeWidth: 2),
                        ),
                    ],
                  ),
                ],
              ),
            ),
            const Divider(height: 1),
            Expanded(
              child: visible.isEmpty && !loading
                  ? const Center(child: Text('Aucun élément à afficher'))
                  : ListView.builder(
                      itemCount: visible.length,
                      itemBuilder: (_, i) {
                        final e = visible[i];
                        final selected = selectedPaths.contains(e.entity.path);

                        return ListTile(
                          selected: selected,
                          leading: selectionMode && !e.isFolder
                              ? Checkbox(
                                  value: selected,
                                  onChanged: (_) => _toggleSelection(e),
                                )
                              : _leading(e),
                          title: Text(
                            e.name,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                          ),
                          subtitle: Text(
                            e.isFolder
                                ? 'Dossier'
                                : '${_typeLabel(e.kind)} • ${formatBytes(e.size)}',
                          ),
                          trailing: PopupMenuButton<String>(
                            onSelected: (v) {
                              if (v == 'rename') _rename(e);
                            },
                            itemBuilder: (_) => const [
                              PopupMenuItem(
                                value: 'rename',
                                child: Text('Renommer'),
                              ),
                            ],
                          ),
                          onTap: () {
                            if (selectionMode && !e.isFolder) {
                              _toggleSelection(e);
                            } else if (e.isFolder) {
                              _loadDirectory(e.entity as Directory);
                            }
                          },
                          onLongPress: e.isFolder ? () => _rename(e) : () => _toggleSelection(e),
                        );
                      },
                    ),
            ),
          ],
        ),
        floatingActionButton: selectionMode
            ? FloatingActionButton.extended(
                onPressed: _bulkRename,
                icon: const Icon(Icons.drive_file_rename_outline),
                label: const Text('Renommer en série'),
              )
            : null,
        bottomNavigationBar: SafeArea(
          child: Material(
            elevation: 8,
            child: Padding(
              padding: const EdgeInsets.fromLTRB(8, 4, 8, 8),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  SwitchListTile(
                    dense: true,
                    contentPadding: EdgeInsets.zero,
                    value: recursiveAnalysis,
                    title: const Text('Analyser aussi les sous-dossiers'),
                    onChanged: (v) => setState(() => recursiveAnalysis = v),
                  ),
                  SizedBox(
                    width: double.infinity,
                    child: FilledButton.icon(
                      onPressed: loading ? null : _smartGlobalScan,
                      icon: const Icon(Icons.auto_awesome),
                      label: const Text('Organiser automatiquement'),
                    ),
                  ),
                  const SizedBox(height: 6),
                  Row(
                    children: [
                      Expanded(
                        child: OutlinedButton.icon(
                          onPressed: _autoSelect,
                          icon: const Icon(Icons.auto_awesome_motion),
                          label: const Text('Sélection auto'),
                        ),
                      ),
                      const SizedBox(width: 8),
                      Expanded(
                        child: FilledButton.icon(
                          onPressed: loading ? null : _duplicates,
                          icon: const Icon(Icons.content_copy),
                          label: const Text('Doublons'),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
