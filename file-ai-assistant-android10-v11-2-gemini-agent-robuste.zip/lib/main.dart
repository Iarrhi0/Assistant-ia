import 'dart:async';
import 'dart:io';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'dart:typed_data';
import 'package:image/image.dart' as img;
import 'package:pdfx/pdfx.dart';
import 'package:crypto/crypto.dart';
import 'package:flutter/material.dart';
import 'package:flutter/foundation.dart' show compute;
import 'package:path/path.dart' as p;
import 'package:permission_handler/permission_handler.dart';


String normalizedFileName(String path) {
  var name = p.basenameWithoutExtension(path).toLowerCase();
  name = name.replaceAll(RegExp(r'[_\-.]+'), ' ');
  name = name.replaceAll(RegExp(r'\b(copy|copie|scan|vf|fr|gratuit|final|new)\b'), ' ');
  name = name.replaceAll(RegExp(r'\s+'), ' ').trim();
  return name;
}

double nameSimilarity(String a, String b) {
  final x = normalizedFileName(a);
  final y = normalizedFileName(b);
  if (x == y) return 1.0;
  if (x.isEmpty || y.isEmpty) return 0.0;

  final ax = x.split(' ').where((e) => e.length > 1).toSet();
  final by = y.split(' ').where((e) => e.length > 1).toSet();
  if (ax.isEmpty || by.isEmpty) return 0.0;

  final intersection = ax.intersection(by).length;
  final union = ax.union(by).length;
  final jaccard = union == 0 ? 0.0 : intersection / union;

  final contains = (x.contains(y) || y.contains(x)) ? 0.18 : 0.0;
  return (jaccard + contains).clamp(0.0, 1.0);
}

double sizeSimilarity(int a, int b) {
  if (a <= 0 || b <= 0) return 0.0;
  final maxSize = a > b ? a : b;
  final minSize = a < b ? a : b;
  return minSize / maxSize;
}

class SimilarFileGroup {
  final List<ExplorerEntry> files;
  final double confidence;
  final bool exact;
  const SimilarFileGroup(this.files, this.confidence, {this.exact = false});
}


class VisualFingerprint {
  final String path;
  final String hash;
  final String sourceType;
  const VisualFingerprint(this.path, this.hash, this.sourceType);
}

String averageHashFromImage(img.Image source) {
  final resized = img.copyResize(source, width: 16, height: 16);
  int total = 0;
  final values = <int>[];

  for (int y = 0; y < resized.height; y++) {
    for (int x = 0; x < resized.width; x++) {
      final pixel = resized.getPixel(x, y);
      final gray = ((pixel.r * 299) + (pixel.g * 587) + (pixel.b * 114)) ~/ 1000;
      values.add(gray);
      total += gray;
    }
  }

  if (values.isEmpty) return '';
  final avg = total / values.length;
  final bits = StringBuffer();
  for (final value in values) {
    bits.write(value >= avg ? '1' : '0');
  }
  return bits.toString();
}

double bitSimilarity(String a, String b) {
  if (a.isEmpty || b.isEmpty || a.length != b.length) return 0.0;
  int equal = 0;
  for (int i = 0; i < a.length; i++) {
    if (a.codeUnitAt(i) == b.codeUnitAt(i)) equal++;
  }
  return equal / a.length;
}

// Runs `task` over `items` with at most `concurrency` operations in flight
// at once. Keeps I/O-heavy work (hashing, decoding) fast without opening
// hundreds of file descriptors or spiking memory on very large libraries —
// the root cause of "too many open files" / OOM crashes on big scans.
// One item's failure never stops the others: `task` is expected to handle
// its own errors, but any escaping exception is swallowed here too.
Future<void> runBounded<T>(
  List<T> items,
  int concurrency,
  Future<void> Function(T item, int index) task,
) async {
  if (items.isEmpty) return;
  var next = 0;
  final workerCount = concurrency < 1
      ? 1
      : (concurrency > items.length ? items.length : concurrency);

  Future<void> worker() async {
    while (true) {
      final i = next;
      if (i >= items.length) return;
      next++;
      try {
        await task(items[i], i);
      } catch (_) {
        // Isolated per-item failure: skip and keep the pool alive.
      }
    }
  }

  await Future.wait(List.generate(workerCount, (_) => worker()));
}

// Top-level (isolate-safe) decode + perceptual hash. Kept as pure Dart with
// no Flutter/platform calls so it can run via compute() on a background
// isolate, off the UI thread — this is what keeps the app fluid and avoids
// native memory spikes when scanning many large images/PDF renders.
String decodeAndHashBytes(Uint8List bytes) {
  try {
    final decoded = img.decodeImage(bytes);
    if (decoded == null) return '';
    return averageHashFromImage(decoded);
  } catch (_) {
    return '';
  }
}

// Top-level (isolate-safe) thumbnail generator for Gemini Vision samples:
// downsizes and re-encodes to a small, cheap-to-transmit JPEG.
String thumbnailBase64(Uint8List bytes, {int maxSide = 256, int quality = 60}) {
  try {
    final decoded = img.decodeImage(bytes);
    if (decoded == null) return '';
    final resized = decoded.width >= decoded.height
        ? img.copyResize(decoded, width: maxSide)
        : img.copyResize(decoded, height: maxSide);
    return base64Encode(img.encodeJpg(resized, quality: quality));
  } catch (_) {
    return '';
  }
}

// Global safety net: an exception during a background scan/hash/decode
// (a corrupt file, a permission hiccup, a plugin glitch...) must never take
// the whole app down. Everything below only logs and keeps the app alive.
void main() {
  FlutterError.onError = (FlutterErrorDetails details) {
    FlutterError.presentError(details);
    debugPrint('FlutterError capturée: ${details.exceptionAsString()}');
  };

  // Errors thrown outside the Flutter framework (raw platform/async errors).
  PlatformDispatcher.instance.onError = (Object error, StackTrace stack) {
    debugPrint('Erreur non interceptée: $error\n$stack');
    return true; // handled: do not crash the process
  };

  runZonedGuarded(() {
    runApp(const FileAiApp());
  }, (Object error, StackTrace stack) {
    debugPrint('Erreur de zone non interceptée: $error\n$stack');
  });
}

class FileAiApp extends StatelessWidget {
  const FileAiApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'File AI Assistant',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF2563EB)),
        useMaterial3: true,
      ),
      home: const ExplorerPage(),
    );
  }
}

enum EntryKind { folder, image, video, audio, document, archive, apk, other }

class ExplorerEntry {
  final FileSystemEntity entity;
  final EntryKind kind;
  final int size;
  final DateTime modified;
  const ExplorerEntry(this.entity, this.kind, this.size, this.modified);

  bool get isFolder => entity is Directory;
  String get name => p.basename(entity.path);
}

class ExplorerPage extends StatefulWidget {
  const ExplorerPage({super.key});

  @override
  State<ExplorerPage> createState() => _ExplorerPageState();
}

class _ExplorerPageState extends State<ExplorerPage> {
  static const storageRoot = '/storage/emulated/0';
  static const minimumUsefulFileSize = 2;

  static const ignoredFolderNames = {
    'android',
    '.android_secure',
    'lost.dir',
    '.thumbnails',
    '.trash',
    '.trashed',
    '.recycle',
    '.recyclebin',
    '.git',
    '__pycache__',
    '_fileai_quarantine',
  };

  final Set<String> selectedPaths = {};
  final Set<EntryKind> activeFilters = {};

  Directory currentDirectory = Directory(storageRoot);
  List<ExplorerEntry> entries = [];
  bool loading = false;
  bool recursiveAnalysis = true;
  bool globalScan = false;
  List<SimilarFileGroup> similarGroups = [];
  List<SimilarFileGroup> visualGroups = [];
  String status = 'Prêt';
  bool aiBusy = false;
  String geminiApiKey = '';
  bool scanWholeStorage = true;
  bool actionBusy = false;
  // Off by default: sending compressed image previews to Gemini requires
  // explicit user consent since real pixel content leaves the device.
  bool includeImageContent = false;
  List<Map<String, dynamic>> pendingActions = [];
  List<Map<String, String>> lastExecutedOps = [];
  final TextEditingController aiInstructionController = TextEditingController(
    text: 'Regroupe les fichiers similaires par nom, conserve les numéros de chapitre quand ils existent, uniformise les noms et signale les doublons.',
  );

  @override
  void initState() {
    super.initState();
    _loadAiSettings();
    _start();
  }

  @override
  void dispose() {
    aiInstructionController.dispose();
    super.dispose();
  }

  Future<void> _loadAiSettings() async {
    final prefs = await SharedPreferences.getInstance();
    final gKey = prefs.getString('gemini_api_key') ?? '';
    final includeImages = prefs.getBool('gemini_include_image_content') ?? false;
    if (mounted) {
      setState(() {
        geminiApiKey = gKey;
        includeImageContent = includeImages;
      });
    }
  }

  Future<void> _start() async {
    final permission = await Permission.storage.request();
    if (!permission.isGranted) {
      if (permission.isPermanentlyDenied) await openAppSettings();
      if (mounted) setState(() => status = 'Autorisation stockage nécessaire');
      return;
    }
    await _loadDirectory(currentDirectory);
  }

  bool _ignored(String path) {
    final lower = path.toLowerCase().replaceAll('\\', '/');
    if (lower.contains('/android/data/') ||
        lower.contains('/android/obb/') ||
        lower.contains('/android/media/')) {
      return true;
    }

    final parts = p.split(path).map((e) => e.toLowerCase());
    return parts.any(ignoredFolderNames.contains);
  }

  EntryKind _kind(String path, {bool folder = false}) {
    if (folder) return EntryKind.folder;
    final ext = p.extension(path).toLowerCase();

    if ({'.jpg','.jpeg','.png','.webp','.gif','.bmp','.heic'}.contains(ext)) {
      return EntryKind.image;
    }
    if ({'.mp4','.mkv','.avi','.mov','.webm','.3gp','.m4v'}.contains(ext)) {
      return EntryKind.video;
    }
    if ({'.mp3','.wav','.m4a','.aac','.flac','.ogg','.opus'}.contains(ext)) {
      return EntryKind.audio;
    }
    if ({'.pdf','.doc','.docx','.xls','.xlsx','.ppt','.pptx','.txt','.rtf','.csv','.epub'}.contains(ext)) {
      return EntryKind.document;
    }
    if ({'.zip','.rar','.7z','.tar','.gz'}.contains(ext)) {
      return EntryKind.archive;
    }
    if (ext == '.apk') return EntryKind.apk;
    return EntryKind.other;
  }

  Future<ExplorerEntry?> _entry(FileSystemEntity entity) async {
    try {
      if (_ignored(entity.path)) return null;
      final stat = await entity.stat();

      if (entity is Directory) {
        return ExplorerEntry(entity, EntryKind.folder, 0, stat.modified);
      }

      if (entity is File) {
        if (stat.size < minimumUsefulFileSize) return null;
        return ExplorerEntry(entity, _kind(entity.path), stat.size, stat.modified);
      }
    } catch (_) {}
    return null;
  }

  Future<void> _loadDirectory(Directory dir) async {
    setState(() {
      loading = true;
      selectedPaths.clear();
      status = 'Ouverture...';
    });

    final list = <ExplorerEntry>[];

    try {
      await for (final entity in dir.list(followLinks: false)) {
        final item = await _entry(entity);
        if (item != null) list.add(item);
      }

      list.sort((a, b) {
        if (a.isFolder != b.isFolder) return a.isFolder ? -1 : 1;
        return a.name.toLowerCase().compareTo(b.name.toLowerCase());
      });

      if (!mounted) return;
      setState(() {
        currentDirectory = dir;
        entries = list;
        loading = false;
        status = '${list.where((e) => e.isFolder).length} dossier(s) • '
            '${list.where((e) => !e.isFolder).length} fichier(s)';
      });
    } catch (_) {
      if (!mounted) return;
      setState(() {
        loading = false;
        status = 'Dossier inaccessible';
      });
    }
  }

  List<ExplorerEntry> get visibleEntries {
    if (activeFilters.isEmpty) return entries;
    return entries.where((e) => e.isFolder || activeFilters.contains(e.kind)).toList();
  }

  Future<void> _goUp() async {
    if (currentDirectory.path == storageRoot) return;
    final parent = currentDirectory.parent;
    if (parent.path.startsWith(storageRoot)) await _loadDirectory(parent);
  }

  void _toggleSelection(ExplorerEntry entry) {
    if (entry.isFolder) return;
    setState(() {
      if (!selectedPaths.add(entry.entity.path)) {
        selectedPaths.remove(entry.entity.path);
      }
    });
  }

  void _selectAllVisible() {
    setState(() {
      selectedPaths
        ..clear()
        ..addAll(visibleEntries.where((e) => !e.isFolder).map((e) => e.entity.path));
    });
  }

  void _selectKinds(Set<EntryKind> kinds) {
    setState(() {
      selectedPaths
        ..clear()
        ..addAll(entries.where((e) => !e.isFolder && kinds.contains(e.kind))
            .map((e) => e.entity.path));
    });
  }

  Future<void> _autoSelect() async {
    final chosen = <EntryKind>{};

    await showDialog(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, local) => AlertDialog(
          title: const Text('Sélection automatique'),
          content: SingleChildScrollView(
            child: Column(
              children: [
                _kindCheck(local, chosen, EntryKind.image, 'Images', Icons.image_outlined),
                _kindCheck(local, chosen, EntryKind.video, 'Vidéos', Icons.movie_outlined),
                _kindCheck(local, chosen, EntryKind.audio, 'Audio', Icons.music_note_outlined),
                _kindCheck(local, chosen, EntryKind.document, 'Documents / textes', Icons.description_outlined),
                _kindCheck(local, chosen, EntryKind.archive, 'Archives', Icons.archive_outlined),
                _kindCheck(local, chosen, EntryKind.apk, 'APK', Icons.android_outlined),
                _kindCheck(local, chosen, EntryKind.other, 'Autres', Icons.insert_drive_file_outlined),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(ctx),
              child: const Text('Annuler'),
            ),
            FilledButton(
              onPressed: () {
                Navigator.pop(ctx);
                _selectKinds(chosen);
              },
              child: const Text('Sélectionner'),
            ),
          ],
        ),
      ),
    );
  }

  Widget _kindCheck(
    StateSetter local,
    Set<EntryKind> chosen,
    EntryKind kind,
    String label,
    IconData icon,
  ) {
    return CheckboxListTile(
      value: chosen.contains(kind),
      secondary: Icon(icon),
      title: Text(label),
      onChanged: (v) {
        local(() {
          if (v == true) {
            chosen.add(kind);
          } else {
            chosen.remove(kind);
          }
        });
      },
    );
  }

  Future<void> _rename(ExplorerEntry entry) async {
    final c = TextEditingController(text: entry.name);
    final name = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(entry.isFolder ? 'Renommer le dossier' : 'Renommer le fichier'),
        content: TextField(
          controller: c,
          autofocus: true,
          decoration: const InputDecoration(
            labelText: 'Nouveau nom',
            border: OutlineInputBorder(),
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Annuler')),
          FilledButton(
            onPressed: () => Navigator.pop(ctx, c.text.trim()),
            child: const Text('Renommer'),
          ),
        ],
      ),
    );

    if (name == null || name.isEmpty || name == entry.name) return;

    try {
      final target = p.join(p.dirname(entry.entity.path), name);
      if (entry.entity is Directory) {
        await (entry.entity as Directory).rename(target);
      } else {
        await (entry.entity as File).rename(target);
      }
      await _loadDirectory(currentDirectory);
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Renommage impossible')),
        );
      }
    }
  }

  Future<List<ExplorerEntry>> _analysisFiles() async {
    final chosen = entries.where((e) => selectedPaths.contains(e.entity.path) && !e.isFolder).toList();
    if (chosen.isNotEmpty) return chosen;

    if (!recursiveAnalysis) {
      return entries.where((e) => !e.isFolder).toList();
    }

    final result = <ExplorerEntry>[];
    await for (final entity in currentDirectory.list(recursive: true, followLinks: false)) {
      final item = await _entry(entity);
      if (item != null && !item.isFolder) result.add(item);
    }
    return result;
  }

  Future<String> _hash(File file) async {
    final digest = await sha256.bind(file.openRead()).first;
    return digest.toString();
  }

  Future<void> _duplicates() async {
    if (loading || actionBusy) return; // anti double-lancement
    setState(() {
      loading = true;
      status = 'Recherche des doublons...';
    });

    final files = await _analysisFiles();
    final bySize = <int, List<ExplorerEntry>>{};

    for (final f in files) {
      bySize.putIfAbsent(f.size, () => []).add(f);
    }

    final byHash = <String, List<ExplorerEntry>>{};
    final toHash = bySize.values.where((g) => g.length > 1).expand((g) => g).toList();

    // Bounded concurrency: fast on big libraries without opening hundreds
    // of file descriptors at once.
    await runBounded<ExplorerEntry>(toHash, 4, (f, _) async {
      final hash = await _hash(f.entity as File);
      byHash.putIfAbsent('${f.size}:$hash', () => []).add(f);
    });

    final groups = byHash.values.where((g) => g.length > 1).toList();

    if (!mounted) return;
    setState(() {
      loading = false;
      status = '${groups.length} groupe(s) de doublons';
    });

    await showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (ctx) => DraggableScrollableSheet(
        expand: false,
        initialChildSize: .82,
        maxChildSize: .95,
        builder: (_, controller) => Column(
          children: [
            const ListTile(
              title: Text('Doublons exacts', style: TextStyle(fontWeight: FontWeight.bold)),
              subtitle: Text('Même taille + même empreinte SHA-256'),
            ),
            Expanded(
              child: groups.isEmpty
                  ? const Center(child: Text('Aucun doublon exact détecté'))
                  : ListView.builder(
                      controller: controller,
                      itemCount: groups.length,
                      itemBuilder: (_, i) {
                        final group = groups[i];
                        return ExpansionTile(
                          title: Text('${group.length} copies'),
                          subtitle: Text(formatBytes(group.first.size)),
                          children: group.map((e) => ListTile(
                            dense: true,
                            leading: Icon(_icon(e.kind)),
                            title: Text(e.name),
                            subtitle: Text(e.entity.path),
                          )).toList(),
                        );
                      },
                    ),
            ),
          ],
        ),
      ),
    );
  }


  Future<List<ExplorerEntry>> _globalUserFiles() async {
    final roots = <Directory>[
      Directory('$storageRoot/Download'),
      Directory('$storageRoot/Documents'),
      Directory('$storageRoot/DCIM'),
      Directory('$storageRoot/Pictures'),
      Directory('$storageRoot/Movies'),
      Directory('$storageRoot/Music'),
    ];

    // Also include the currently opened user folder even if it is custom.
    if (!roots.any((d) => d.path == currentDirectory.path)) {
      roots.add(currentDirectory);
    }

    final seen = <String>{};
    final result = <ExplorerEntry>[];

    for (final root in roots) {
      if (!await root.exists()) continue;
      try {
        await for (final entity in root.list(recursive: true, followLinks: false)) {
          if (seen.contains(entity.path)) continue;
          seen.add(entity.path);
          final item = await _entry(entity);
          if (item != null && !item.isFolder) result.add(item);
        }
      } catch (_) {}
    }
    return result;
  }


  bool _isVisualCandidate(ExplorerEntry entry) {
    final ext = p.extension(entry.name).toLowerCase();
    return entry.kind == EntryKind.image || ext == '.pdf';
  }

  Future<VisualFingerprint?> _fingerprintImage(ExplorerEntry entry) async {
    try {
      final bytes = await (entry.entity as File).readAsBytes();
      // Decode + hash on a background isolate: keeps the UI thread free and
      // avoids stacking native decode buffers on the main isolate when many
      // images are processed back to back.
      final hash = await compute(decodeAndHashBytes, bytes);
      if (hash.isEmpty) return null;
      return VisualFingerprint(entry.entity.path, hash, 'image');
    } catch (_) {
      return null;
    }
  }

  Future<VisualFingerprint?> _fingerprintPdf(ExplorerEntry entry) async {
    PdfDocument? doc;
    PdfPage? page;

    try {
      doc = await PdfDocument.openFile(entry.entity.path);
      if (doc.pagesCount < 1) return null;

      page = await doc.getPage(1);

      final width = page.width <= 0 ? 300.0 : page.width;
      final height = page.height <= 0 ? 420.0 : page.height;

      final scale = width > 256 ? 256 / width : 1.0;
      final targetWidth = (width * scale).round().clamp(64, 320);
      final targetHeight = (height * scale).round().clamp(64, 480);

      final rendered = await page.render(
        width: targetWidth.toDouble(),
        height: targetHeight.toDouble(),
        format: PdfPageImageFormat.png,
      );

      if (rendered == null) return null;

      // Rendering the page must stay on the main isolate (plugin/platform
      // channel call), but the pure-Dart decode + hash step doesn't.
      final hash = await compute(decodeAndHashBytes, Uint8List.fromList(rendered.bytes));
      if (hash.isEmpty) return null;
      return VisualFingerprint(entry.entity.path, hash, 'pdf');
    } catch (_) {
      return null;
    } finally {
      try {
        await page?.close();
      } catch (_) {}
      try {
        await doc?.close();
      } catch (_) {}
    }
  }

  Future<VisualFingerprint?> _visualFingerprint(ExplorerEntry entry) async {
    if (entry.kind == EntryKind.image) {
      return _fingerprintImage(entry);
    }

    if (p.extension(entry.name).toLowerCase() == '.pdf') {
      return _fingerprintPdf(entry);
    }

    return null;
  }

  Future<List<SimilarFileGroup>> _findVisualGroups(
    List<ExplorerEntry> files,
  ) async {
    final candidates = files.where(_isVisualCandidate).toList();
    final fingerprints = <String, VisualFingerprint>{};

    // Limit work per run to keep Android 10 responsive on very large libraries.
    // Exact duplicate scan still covers the full library.
    final limited = candidates.take(80).toList();

    var processed = 0;
    // Bounded to 3 in-flight decodes: fast enough to matter, low enough to
    // never pile up several full-resolution image/PDF buffers at once.
    await runBounded<ExplorerEntry>(limited, 3, (entry, i) async {
      final fp = await _visualFingerprint(entry);
      if (fp != null) {
        fingerprints[entry.entity.path] = fp;
      }
      processed++;
      if (mounted && processed % 10 == 0) {
        setState(() {
          status = 'Analyse visuelle $processed/${limited.length}...';
        });
      }
    });

    final byPath = {for (final f in limited) f.entity.path: f};
    final buckets = <String, List<ExplorerEntry>>{};

    // Bucket by type + approximate size range to avoid comparing everything with everything.
    for (final f in limited) {
      if (!fingerprints.containsKey(f.entity.path)) continue;
      final sizeMb = f.size / (1024 * 1024);
      final bucketBand = (sizeMb / 8).floor();
      final type = p.extension(f.name).toLowerCase() == '.pdf' ? 'pdf' : 'image';
      buckets.putIfAbsent('$type:$bucketBand', () => []).add(f);

      // Also compare with adjacent size band because compressed versions can differ.
      buckets.putIfAbsent('$type:${bucketBand - 1}', () => []).add(f);
      buckets.putIfAbsent('$type:${bucketBand + 1}', () => []).add(f);
    }

    final pairKeys = <String>{};
    final groups = <SimilarFileGroup>[];

    for (final bucket in buckets.values) {
      if (bucket.length < 2) continue;

      for (int i = 0; i < bucket.length; i++) {
        final a = bucket[i];
        final fa = fingerprints[a.entity.path];
        if (fa == null) continue;

        final cluster = <ExplorerEntry>[a];
        double best = 0;

        for (int j = i + 1; j < bucket.length; j++) {
          final b = bucket[j];
          if (a.entity.path == b.entity.path) continue;

          final pair = [a.entity.path, b.entity.path]..sort();
          final pairKey = pair.join('|');
          if (!pairKeys.add(pairKey)) continue;

          final fb = fingerprints[b.entity.path];
          if (fb == null || fa.sourceType != fb.sourceType) continue;

          final visual = bitSimilarity(fa.hash, fb.hash);
          final names = nameSimilarity(a.name, b.name);
          final sizes = sizeSimilarity(a.size, b.size);

          // Visual similarity dominates. Names and size reinforce confidence.
          final confidence = (visual * 0.70) + (names * 0.18) + (sizes * 0.12);

          if (visual >= 0.89 && confidence >= 0.82) {
            cluster.add(b);
            if (confidence > best) best = confidence;
          }
        }

        if (cluster.length > 1) {
          final unique = <String, ExplorerEntry>{};
          for (final f in cluster) {
            unique[f.entity.path] = f;
          }
          final values = unique.values.toList();

          if (values.length > 1) {
            groups.add(
              SimilarFileGroup(
                values,
                best.clamp(0.0, 0.995),
              ),
            );
          }
        }
      }
    }

    // De-duplicate near-identical groups by sorted path signature.
    final seenGroups = <String>{};
    final clean = <SimilarFileGroup>[];

    for (final g in groups) {
      final paths = g.files.map((e) => e.entity.path).toList()..sort();
      final sig = paths.join('||');
      if (seenGroups.add(sig)) clean.add(g);
    }

    clean.sort((a, b) => b.confidence.compareTo(a.confidence));
    return clean.take(150).toList();
  }




  Future<void> _geminiSettings() async {
    final controller = TextEditingController(text: geminiApiKey);
    var visionConsent = includeImageContent;

    final result = await showDialog<Map<String, dynamic>>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setDialogState) => AlertDialog(
          title: const Text('Gemini Assistant'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'Colle ta clé Gemini API. Elle reste enregistrée localement sur ce téléphone.',
              ),
              const SizedBox(height: 12),
              TextField(
                controller: controller,
                obscureText: true,
                autocorrect: false,
                enableSuggestions: false,
                decoration: const InputDecoration(
                  labelText: 'Clé Gemini API',
                  border: OutlineInputBorder(),
                ),
              ),
              const SizedBox(height: 16),
              const Divider(),
              SwitchListTile(
                contentPadding: EdgeInsets.zero,
                value: visionConsent,
                onChanged: (v) => setDialogState(() => visionConsent = v),
                title: const Text('Classer les images par contenu réel'),
                subtitle: const Text(
                  'Envoie à Gemini un aperçu compressé (basse résolution) d’un échantillon '
                  'de tes images, en plus des noms de fichiers, pour un classement plus juste '
                  '(ex. distinguer une photo perso d’un mème ou d’un scan). Désactivé par '
                  'défaut : cela envoie du contenu visuel réel à Google.',
                ),
              ),
            ],
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Annuler')),
            FilledButton(
              onPressed: () => Navigator.pop(ctx, {
                'key': controller.text.trim(),
                'vision': visionConsent,
              }),
              child: const Text('Enregistrer'),
            ),
          ],
        ),
      ),
    );

    if (result != null) {
      final prefs = await SharedPreferences.getInstance();
      final key = result['key'] as String;
      final vision = result['vision'] as bool;
      await prefs.setString('gemini_api_key', key);
      await prefs.setBool('gemini_include_image_content', vision);
      if (mounted) {
        setState(() {
          geminiApiKey = key;
          includeImageContent = vision;
        });
      }
    }
  }

  Future<List<ExplorerEntry>> _scanAccessibleStorage() async {
    final result = <ExplorerEntry>[];
    final seen = <String>{};

    final roots = scanWholeStorage
        ? <Directory>[
            Directory(storageRoot),
          ]
        : <Directory>[currentDirectory];

    const blocked = <String>[
      '/Android/data/',
      '/Android/obb/',
      '/.thumbnails/',
      '/cache/',
    ];

    for (final root in roots) {
      if (!await root.exists()) continue;
      try {
        await for (final entity in root.list(recursive: true, followLinks: false)) {
          if (result.length >= 12000) break;
          final normalized = entity.path.replaceAll('\\', '/');
          if (blocked.any(normalized.contains)) continue;
          if (seen.contains(entity.path)) continue;
          seen.add(entity.path);

          final item = await _entry(entity);
          if (item == null || item.isFolder) continue;
          if (item.size <= 1) continue;
          result.add(item);

          if (mounted && result.length % 250 == 0) {
            setState(() {
              status = 'Inventaire : ${result.length} fichiers accessibles...';
            });
            await Future<void>.delayed(const Duration(milliseconds: 20));
          }
        }
      } catch (_) {}
    }
    return result;
  }

  // Existing folder structure so Gemini reuses it instead of reinventing
  // a new tree on every run. Capped to stay small in the prompt.
  Future<List<String>> _existingFolderPaths() async {
    final root = Directory(storageRoot);
    final result = <String>[];
    if (!await root.exists()) return result;

    try {
      await for (final entity in root.list(recursive: true, followLinks: false)) {
        if (entity is! Directory) continue;
        if (result.length >= 600) break;
        if (_ignored(entity.path)) continue;
        final rel = p.relative(entity.path, from: storageRoot);
        if (rel == '.') continue;
        result.add(rel);
      }
    } catch (_) {}

    result.sort();
    return result;
  }

  // Picks a small, bounded sample of image files from a chunk and turns
  // them into cheap compressed thumbnails Gemini can actually look at.
  // Returns an empty map (no cost, no network of image bytes) unless the
  // user has explicitly opted in via includeImageContent.
  Future<Map<String, String>> _imageSamplesFor(
    List<ExplorerEntry> chunk, {
    int maxSamples = 12,
  }) async {
    if (!includeImageContent) return {};

    final images = chunk.where((f) => f.kind == EntryKind.image).take(maxSamples).toList();
    if (images.isEmpty) return {};

    final samples = <String, String>{};
    await runBounded<ExplorerEntry>(images, 3, (entry, _) async {
      final bytes = await (entry.entity as File).readAsBytes();
      final b64 = await compute(thumbnailBase64, bytes);
      if (b64.isNotEmpty) samples[entry.entity.path] = b64;
    });
    return samples;
  }

  Map<String, dynamic> _geminiSchema() {
    return {
      'type': 'object',
      'properties': {
        'summary': {'type': 'string'},
        'tree_preview': {
          'type': 'array',
          'items': {'type': 'string'}
        },
        'actions': {
          'type': 'array',
          'items': {
            'type': 'object',
            'properties': {
              'type': {
                'type': 'string',
                'enum': ['create_folder', 'move', 'rename', 'quarantine', 'batch_rename']
              },
              'source': {'type': 'string'},
              'destination': {'type': 'string'},
              'reason': {'type': 'string'},
              'confidence': {'type': 'number'},
              'files': {
                'type': 'array',
                'items': {'type': 'string'},
                'description':
                    'Only for batch_rename: ordered list of existing source paths belonging to the same series.'
              },
              'pattern': {
                'type': 'string',
                'description':
                    'Only for batch_rename: filename pattern with a {n} placeholder for the sequence number, e.g. "Naruto_Tome_{n}". Extension is kept automatically.'
              },
              'start_index': {
                'type': 'integer',
                'description': 'Only for batch_rename: first sequence number to use (usually 1).'
              }
            },
            'required': ['type', 'reason', 'confidence']
          }
        }
      },
      'required': ['summary', 'tree_preview', 'actions']
    };
  }

  Future<Map<String, dynamic>> _askGeminiForActions(
    List<ExplorerEntry> files,
    String instruction, {
    List<String> existingFolders = const [],
    String? chunkContext,
    Map<String, String> imageSamples = const {},
  }) async {
    if (geminiApiKey.trim().isEmpty) {
      await _geminiSettings();
      if (geminiApiKey.trim().isEmpty) {
        throw Exception('Clé Gemini absente');
      }
    }

    // Send compact metadata only. The phone remains the file-system authority.
    final compact = files.take(2500).map((f) => {
      'path': f.entity.path,
      'name': f.name,
      'size': f.size,
      'ext': p.extension(f.name).toLowerCase(),
      // Numbers already found in the name help Gemini recognize a series
      // (tome, chapitre, épisode, partie...) instead of guessing blindly.
      'detected_numbers': RegExp(r'\d+').allMatches(f.name).map((m) => m.group(0)).toList(),
    }).toList();

    final prompt = jsonEncode({
      'instruction': instruction,
      if (chunkContext != null) 'context': chunkContext,
      'existing_folders': existingFolders,
      'rules': [
        'Never invent a source path.',
        'Reuse a folder from existing_folders whenever it already fits; only propose create_folder when nothing existing fits.',
        'Prefer grouping files with strongly similar logical names into the same destination folder.',
        'Detect series: files that share a common title/stem but differ mainly by a number (tome, chapitre, episode, partie, saison, part, vol...). '
            'Use detected_numbers to recognize and order these series reliably, even if the numbering in the original names is inconsistent, '
            'missing leading zeros, or uses different separators.',
        'For a detected series of 3 or more files, prefer a single batch_rename action over many individual rename actions: '
            'set files to the ordered list of source paths, pattern to a clean template containing {n} for the sequence number, '
            'and start_index to the first number of the series (usually 1). Do not include the extension in pattern.',
        'For a single isolated rename (not part of a series), use the rename action with source and destination.',
        'Never permanently delete. Duplicate/corrupt candidates must use quarantine.',
        'Do not touch Android system folders.',
        'Return only actions justified by the supplied inventory.',
        'Destination paths (and destination folders for batch_rename) must stay under $storageRoot.',
        if (imageSamples.isNotEmpty)
          'A compressed visual preview is attached (in this exact order) for these image paths: '
              '${imageSamples.keys.toList()}. Use what you actually see in them to classify by real '
              'content (e.g. photo vs meme vs screenshot vs document scan vs receipt) instead of '
              'guessing from the filename alone, whenever that changes the destination folder or the reason.',
      ],
      'inventory': compact,
    });

    final parts = <Map<String, dynamic>>[
      {'text': prompt},
      for (final b64 in imageSamples.values)
        {
          'inlineData': {'mimeType': 'image/jpeg', 'data': b64}
        },
    ];

    final body = {
      'contents': [
        {
          'role': 'user',
          'parts': parts,
        }
      ],
      'generationConfig': {
        'responseMimeType': 'application/json',
        'responseSchema': _geminiSchema(),
        'temperature': 0.2,
      }
    };

    final response = await http.post(
      Uri.parse(
        'https://generativelanguage.googleapis.com/v1beta/models/'
        'gemini-2.5-flash:generateContent',
      ),
      headers: {
        'x-goog-api-key': geminiApiKey.trim(),
        'Content-Type': 'application/json',
      },
      body: jsonEncode(body),
    ).timeout(const Duration(seconds: 75));

    if (response.statusCode < 200 || response.statusCode >= 300) {
      throw Exception('Gemini ${response.statusCode}: ${response.body}');
    }

    final outer = jsonDecode(response.body) as Map<String, dynamic>;
    final candidates = outer['candidates'] as List<dynamic>? ?? [];
    if (candidates.isEmpty) throw Exception('Gemini n’a retourné aucun plan');

    final content = candidates.first['content'] as Map<String, dynamic>?;
    final parts = content?['parts'] as List<dynamic>? ?? [];
    if (parts.isEmpty) throw Exception('Réponse Gemini vide');

    final text = (parts.first as Map<String, dynamic>)['text']?.toString() ?? '';
    if (text.isEmpty) throw Exception('Plan Gemini vide');
    return jsonDecode(text) as Map<String, dynamic>;
  }

  bool _isSafeDestination(String destination) {
    final normalized = p.normalize(destination);
    final root = p.normalize(storageRoot);
    return normalized == root || p.isWithin(root, normalized);
  }

  // Sanitizes one chunk's raw Gemini actions against that chunk's own files.
  // `folderAcc` is mutated with every new folder referenced, so the next
  // chunk (and the next Gemini call) knows about it.
  List<Map<String, dynamic>> _sanitizeActions(
    List<dynamic> rawActions,
    Set<String> validPaths,
    Set<String> folderAcc,
  ) {
    final sanitized = <Map<String, dynamic>>[];

    for (final raw in rawActions) {
      final a = Map<String, dynamic>.from(raw as Map);
      final type = a['type']?.toString() ?? '';

      if (type == 'batch_rename') {
        final destination = p.normalize(a['destination']?.toString() ?? '');
        final pattern = a['pattern']?.toString().trim() ?? '';
        final startIndex = int.tryParse(a['start_index']?.toString() ?? '1') ?? 1;
        final rawFiles = (a['files'] as List<dynamic>? ?? [])
            .map((f) => p.normalize(f.toString()))
            .where(validPaths.contains)
            .toSet()
            .toList();

        if (pattern.isEmpty || rawFiles.length < 2 || !_isSafeDestination(destination)) {
          continue;
        }

        // Keep the series in a stable, human order (by detected numbers,
        // falling back to the name) rather than trusting Gemini's raw order.
        rawFiles.sort((x, y) {
          final nx = RegExp(r'\d+').firstMatch(p.basename(x))?.group(0);
          final ny = RegExp(r'\d+').firstMatch(p.basename(y))?.group(0);
          if (nx != null && ny != null) {
            final cmp = int.parse(nx).compareTo(int.parse(ny));
            if (cmp != 0) return cmp;
          }
          return p.basename(x).toLowerCase().compareTo(p.basename(y).toLowerCase());
        });

        a['destination'] = destination;
        a['files'] = rawFiles;
        a['pattern'] = pattern;
        a['start_index'] = startIndex;
        a['selected'] = true;
        folderAcc.add(p.relative(destination, from: storageRoot));
        sanitized.add(a);
        continue;
      }

      final source = p.normalize(a['source']?.toString() ?? '');
      final destination = p.normalize(a['destination']?.toString() ?? '');

      if (!{'create_folder', 'move', 'rename', 'quarantine'}.contains(type)) continue;
      if (!_isSafeDestination(destination)) continue;
      if (type != 'create_folder' && !validPaths.contains(source)) continue;

      a['source'] = source;
      a['destination'] = destination;
      a['selected'] = true;
      sanitized.add(a);

      if (type == 'create_folder') {
        folderAcc.add(p.relative(destination, from: storageRoot));
      } else if (type == 'move' || type == 'rename') {
        folderAcc.add(p.relative(p.dirname(destination), from: storageRoot));
      }
    }

    return sanitized;
  }

  Future<void> _geminiAssistantPlan() async {
    if (aiBusy) return;
    setState(() {
      aiBusy = true;
      status = scanWholeStorage
          ? 'Gemini prépare l’inventaire du stockage...'
          : 'Gemini analyse ce dossier...';
    });

    try {
      final files = await _scanAccessibleStorage();
      if (files.isEmpty) throw Exception('Aucun fichier accessible détecté');

      final instruction = aiInstructionController.text.trim().isEmpty
          ? 'Range mes fichiers par groupes logiques. Uniformise les noms et mets les doublons en quarantaine.'
          : aiInstructionController.text.trim();

      // Group near-identical names together before chunking, so a whole
      // series of tomes/chapitres/épisodes tends to land in the same chunk
      // and Gemini can propose one batch_rename instead of splitting it.
      final ordered = [...files]..sort((a, b) {
          final na = normalizedFileName(a.name);
          final nb = normalizedFileName(b.name);
          final cmp = na.compareTo(nb);
          if (cmp != 0) return cmp;
          return a.name.compareTo(b.name);
        });

      const chunkSize = 2500;
      final chunks = <List<ExplorerEntry>>[];
      for (var i = 0; i < ordered.length; i += chunkSize) {
        chunks.add(ordered.sublist(i, (i + chunkSize).clamp(0, ordered.length)));
      }

      final folderAcc = (await _existingFolderPaths()).toSet();
      final allSanitized = <Map<String, dynamic>>[];
      final summaries = <String>[];
      final treePreview = <String>{};

      for (var i = 0; i < chunks.length; i++) {
        final chunk = chunks[i];
        setState(() {
          status = chunks.length > 1
              ? 'Gemini réfléchit au plan de rangement... (lot ${i + 1}/${chunks.length})'
              : 'Gemini réfléchit au plan de rangement...';
        });

        final imageSamples = await _imageSamplesFor(chunk);
        if (imageSamples.isNotEmpty && mounted) {
          setState(() {
            status = chunks.length > 1
                ? 'Gemini regarde ${imageSamples.length} image(s) du lot ${i + 1}/${chunks.length}...'
                : 'Gemini regarde ${imageSamples.length} image(s)...';
          });
        }

        final plan = await _askGeminiForActions(
          chunk,
          instruction,
          existingFolders: folderAcc.toList()..sort(),
          chunkContext: chunks.length > 1
              ? 'Lot ${i + 1} sur ${chunks.length} d’un inventaire trop volumineux pour un seul appel. '
                  'Reste cohérent avec les dossiers déjà listés dans existing_folders.'
              : null,
          imageSamples: imageSamples,
        );

        final validPaths = {for (final f in chunk) p.normalize(f.entity.path)};
        final sanitized = _sanitizeActions(
          (plan['actions'] as List<dynamic>? ?? []),
          validPaths,
          folderAcc,
        );

        allSanitized.addAll(sanitized);
        final s = plan['summary']?.toString();
        if (s != null && s.isNotEmpty) summaries.add(s);
        treePreview.addAll(
          (plan['tree_preview'] as List<dynamic>? ?? []).map((e) => e.toString()),
        );
      }

      final mergedPlan = {
        'summary': summaries.join(' '),
        'tree_preview': treePreview.toList(),
      };

      if (!mounted) return;
      setState(() {
        pendingActions = allSanitized;
        status = '${allSanitized.length} action(s) proposées'
            '${chunks.length > 1 ? ' • ${files.length} fichiers analysés en ${chunks.length} lot(s)' : ''}';
      });
      await _showGeminiActionPlan(mergedPlan, allSanitized);
    } catch (e) {
      if (!mounted) return;
      await showDialog(
        context: context,
        builder: (ctx) => AlertDialog(
          title: const Text('Gemini Assistant'),
          content: Text('$e'),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Fermer')),
          ],
        ),
      );
    } finally {
      if (mounted) setState(() => aiBusy = false);
    }
  }

  Future<void> _showGeminiActionPlan(
    Map<String, dynamic> plan,
    List<Map<String, dynamic>> actions,
  ) async {
    final tree = (plan['tree_preview'] as List<dynamic>? ?? []).map((e) => e.toString()).toList();

    await showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setSheetState) => DraggableScrollableSheet(
          expand: false,
          initialChildSize: .94,
          maxChildSize: .98,
          minChildSize: .60,
          builder: (_, controller) => Column(
            children: [
              ListTile(
                leading: const Icon(Icons.psychology_alt_outlined),
                title: const Text('Plan de Gemini', style: TextStyle(fontWeight: FontWeight.bold)),
                subtitle: Text(plan['summary']?.toString() ?? 'Organisation proposée'),
              ),
              if (tree.isNotEmpty)
                Container(
                  width: double.infinity,
                  margin: const EdgeInsets.symmetric(horizontal: 12),
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    border: Border.all(color: Theme.of(ctx).dividerColor),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Text(
                    tree.take(30).join('\n'),
                    style: const TextStyle(fontFamily: 'monospace'),
                  ),
                ),
              const Divider(),
              Expanded(
                child: ListView.builder(
                  controller: controller,
                  itemCount: actions.length,
                  itemBuilder: (_, i) {
                    final a = actions[i];
                    final isBatch = a['type'] == 'batch_rename';
                    final title = isBatch
                        ? 'Renommage en série → ${p.basename(a['destination'].toString())}'
                        : '${a['type']} → ${p.basename(a['destination'].toString())}';
                    final detail = isBatch
                        ? '${a['reason']}\n'
                            '${(a['files'] as List).length} fichier(s) • motif "${a['pattern']}"\n'
                            '→ ${a['destination']}'
                        : '${a['reason']}\n'
                            '${a['source']}\n→ ${a['destination']}';

                    return CheckboxListTile(
                      value: a['selected'] == true,
                      onChanged: (v) {
                        setSheetState(() => a['selected'] = v == true);
                      },
                      title: Text(title),
                      subtitle: Text(detail),
                      isThreeLine: true,
                      controlAffinity: ListTileControlAffinity.leading,
                    );
                  },
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(12),
                child: Row(
                  children: [
                    Expanded(
                      child: OutlinedButton(
                        onPressed: () => Navigator.pop(ctx),
                        child: const Text('Modifier plus tard'),
                      ),
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: FilledButton.icon(
                        onPressed: actions.any((a) => a['selected'] == true)
                            ? () async {
                                Navigator.pop(ctx);
                                await _confirmAndExecuteActions(actions);
                              }
                            : null,
                        icon: const Icon(Icons.play_arrow),
                        label: Text(
                          'AGIR (${actions.where((a) => a['selected'] == true).length})',
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // Picks a stable digit padding for a batch_rename series: at least 2
  // digits, or more if the series itself needs it (e.g. 100+ chapters).
  int _paddingFor(int count, int startIndex) {
    final maxIndex = startIndex + count - 1;
    final digits = maxIndex.toString().length;
    return digits < 2 ? 2 : digits;
  }

  Future<void> _confirmAndExecuteActions(List<Map<String, dynamic>> actions) async {
    final selected = actions.where((a) => a['selected'] == true).toList();
    final batchFileCount = selected
        .where((a) => a['type'] == 'batch_rename')
        .fold<int>(0, (sum, a) => sum + (a['files'] as List).length);
    final simpleCount = selected.where((a) => a['type'] != 'batch_rename').length;

    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Appliquer les actions ?'),
        content: Text(
          '${simpleCount + batchFileCount} opération(s) seront exécutées'
          '${batchFileCount > 0 ? ' (dont $batchFileCount fichier(s) en renommage de série)' : ''}.\n\n'
          'Les suppressions définitives ne sont pas autorisées : '
          'les fichiers concernés passent par Quarantaine.',
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Annuler')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('AGIR')),
        ],
      ),
    );
    if (ok != true) return;

    setState(() {
      actionBusy = true;
      status = 'Application des actions...';
    });

    int done = 0, failed = 0;
    final executedOps = <Map<String, String>>[];
    final quarantine = Directory(p.join(storageRoot, 'FileAI_Quarantaine'));
    try {
      for (final a in selected) {
        try {
          final type = a['type'].toString();

          if (type == 'batch_rename') {
            final destFolder = a['destination'].toString();
            final pattern = a['pattern'].toString();
            final startIndex = (a['start_index'] as int?) ?? 1;
            final sources = (a['files'] as List).cast<String>();
            if (!_isSafeDestination(destFolder)) { failed++; continue; }

            await Directory(destFolder).create(recursive: true);
            final padding = _paddingFor(sources.length, startIndex);

            for (var i = 0; i < sources.length; i++) {
              final source = sources[i];
              try {
                final src = File(source);
                if (!await src.exists()) { failed++; continue; }
                final number = (startIndex + i).toString().padLeft(padding, '0');
                final filled = pattern.replaceAll('{n}', number);
                var destination = p.join(destFolder, '$filled${p.extension(source)}');
                if (await File(destination).exists() && p.normalize(destination) != p.normalize(source)) {
                  destination = p.join(
                    destFolder,
                    '${filled}_${DateTime.now().millisecondsSinceEpoch}${p.extension(source)}',
                  );
                }
                await src.rename(destination);
                executedOps.add({'from': destination, 'to': source});
                done++;
              } catch (_) {
                failed++;
              }
            }
            if (mounted) setState(() => status = 'Actions : $done réussie(s), $failed échec(s)');
            continue;
          }

          var source = a['source'].toString();
          var destination = a['destination'].toString();

          if (!_isSafeDestination(destination)) {
            failed++;
            continue;
          }

          if (type == 'create_folder') {
            await Directory(destination).create(recursive: true);
          } else if (type == 'quarantine') {
            await quarantine.create(recursive: true);
            final src = File(source);
            if (!await src.exists()) { failed++; continue; }
            destination = p.join(
              quarantine.path,
              '${DateTime.now().millisecondsSinceEpoch}_${p.basename(source)}',
            );
            await src.rename(destination);
            executedOps.add({'from': destination, 'to': source});
          } else if (type == 'move' || type == 'rename') {
            final src = File(source);
            if (!await src.exists()) { failed++; continue; }
            await Directory(p.dirname(destination)).create(recursive: true);
            if (await File(destination).exists()) {
              final ext = p.extension(destination);
              final stem = p.basenameWithoutExtension(destination);
              destination = p.join(
                p.dirname(destination),
                '${stem}_${DateTime.now().millisecondsSinceEpoch}$ext',
              );
            }
            await src.rename(destination);
            executedOps.add({'from': destination, 'to': source});
          }
          done++;
        } catch (_) {
          failed++;
        }
        if (mounted) setState(() => status = 'Actions : $done réussie(s), $failed échec(s)');
      }
      await _loadDirectory(currentDirectory);
      lastExecutedOps = executedOps;
      if (mounted && executedOps.isNotEmpty) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('$done action(s) appliquée(s) • $failed échec(s)'),
            action: SnackBarAction(label: 'ANNULER', onPressed: _undoLastBatch),
            duration: const Duration(seconds: 8),
          ),
        );
      }
    } finally {
      if (mounted) {
        setState(() {
          actionBusy = false;
          status = '$done action(s) appliquée(s) • $failed échec(s)';
        });
      }
    }
  }

  // Reverses the last executed batch (move/rename/quarantine/batch_rename),
  // most recent operation first, in case Gemini's plan was wrong.
  Future<void> _undoLastBatch() async {
    if (lastExecutedOps.isEmpty) return;
    final ops = lastExecutedOps.reversed.toList();

    setState(() {
      actionBusy = true;
      status = 'Annulation en cours...';
    });

    int done = 0, failed = 0;
    for (final op in ops) {
      try {
        final from = File(op['from']!);
        final to = op['to']!;
        if (!await from.exists()) { failed++; continue; }
        await Directory(p.dirname(to)).create(recursive: true);
        await from.rename(to);
        done++;
      } catch (_) {
        failed++;
      }
    }

    lastExecutedOps = [];
    await _loadDirectory(currentDirectory);
    if (mounted) {
      setState(() {
        actionBusy = false;
        status = 'Annulation : $done fichier(s) restauré(s)${failed > 0 ? ' • $failed échec(s)' : ''}';
      });
    }
  }

  Future<void> _smartGlobalScan() async {
    if (loading || aiBusy || actionBusy) return; // anti double-lancement
    setState(() {
      loading = true;
      globalScan = true;
      similarGroups = [];
      status = 'Analyse intelligente des dossiers utilisateur...';
    });

    final files = await _globalUserFiles();

    // Phase 1: exact duplicates, grouped cheaply by size before hashing.
    final bySize = <int, List<ExplorerEntry>>{};
    for (final f in files) {
      bySize.putIfAbsent(f.size, () => []).add(f);
    }

    final exactByHash = <String, List<ExplorerEntry>>{};
    final toHash = bySize.values.where((g) => g.length > 1).expand((g) => g).toList();

    // Bounded concurrency: hashing is I/O-bound, but unbounded parallel
    // reads on a large phone library is exactly what causes "too many open
    // files" crashes. 4 in-flight reads is a safe, still-fast middle ground.
    await runBounded<ExplorerEntry>(toHash, 4, (f, _) async {
      final hash = await _hash(f.entity as File);
      exactByHash.putIfAbsent('${f.size}:$hash', () => []).add(f);
    });

    final groups = <SimilarFileGroup>[];
    final exactPaths = <String>{};

    for (final g in exactByHash.values.where((g) => g.length > 1)) {
      groups.add(SimilarFileGroup(g, 1.0, exact: true));
      exactPaths.addAll(g.map((e) => e.entity.path));
    }

    // Phase 2: probable same content/version using normalized names + type + size.
    // Bucket by first meaningful token to avoid O(n²) over the entire phone.
    final buckets = <String, List<ExplorerEntry>>{};
    for (final f in files) {
      if (exactPaths.contains(f.entity.path)) continue;
      final norm = normalizedFileName(f.entity.path);
      final tokens = norm.split(' ').where((x) => x.length >= 3).toList();
      final key = tokens.isEmpty ? p.extension(f.name).toLowerCase() : tokens.first;
      buckets.putIfAbsent('${f.kind}:$key', () => []).add(f);
    }

    for (final bucket in buckets.values) {
      if (bucket.length < 2) continue;
      final used = <String>{};

      for (int i = 0; i < bucket.length; i++) {
        final a = bucket[i];
        if (used.contains(a.entity.path)) continue;
        final cluster = <ExplorerEntry>[a];
        double bestConfidence = 0;

        for (int j = i + 1; j < bucket.length; j++) {
          final b = bucket[j];
          if (used.contains(b.entity.path)) continue;
          if (p.extension(a.name).toLowerCase() != p.extension(b.name).toLowerCase()) {
            continue;
          }

          final ns = nameSimilarity(a.name, b.name);
          final ss = sizeSimilarity(a.size, b.size);
          final confidence = (ns * 0.72) + (ss * 0.28);

          // High name resemblance can tolerate compression differences.
          if ((ns >= 0.72 && confidence >= 0.72) || (ns >= 0.88 && ss >= 0.45)) {
            cluster.add(b);
            used.add(b.entity.path);
            if (confidence > bestConfidence) bestConfidence = confidence;
          }
        }

        if (cluster.length > 1) {
          used.add(a.entity.path);
          groups.add(SimilarFileGroup(cluster, bestConfidence.clamp(0.0, 0.99)));
        }
      }
    }

    groups.sort((a, b) => b.confidence.compareTo(a.confidence));

    final visual = await _findVisualGroups(files);

    if (!mounted) return;
    setState(() {
      loading = false;
      similarGroups = groups;
      visualGroups = visual;
      status = '${files.length} fichiers utiles • '
          '${groups.length} groupe(s) nom/taille • '
          '${visual.length} groupe(s) visuel(s)';
    });

    await _showSmartPlan(files.length);
  }

  Future<void> _showSmartPlan(int scannedCount) async {
    await showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (ctx) => DraggableScrollableSheet(
        expand: false,
        initialChildSize: .9,
        maxChildSize: .97,
        minChildSize: .55,
        builder: (_, controller) => Column(
          children: [
            ListTile(
              leading: const Icon(Icons.auto_awesome),
              title: const Text(
                'Plan intelligent proposé',
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
              subtitle: Text(
                '$scannedCount fichiers analysés dans les dossiers utilisateur. '
                'Aucune suppression automatique.',
              ),
            ),
            const Divider(height: 1),
            if (visualGroups.isNotEmpty)
              Padding(
                padding: const EdgeInsets.fromLTRB(12, 10, 12, 4),
                child: Align(
                  alignment: Alignment.centerLeft,
                  child: Text(
                    '${visualGroups.length} groupe(s) visuellement très proches détecté(s)',
                    style: const TextStyle(fontWeight: FontWeight.w600),
                  ),
                ),
              ),
            Expanded(
              child: (similarGroups.isEmpty && visualGroups.isEmpty)
                  ? const Center(child: Text('Aucun groupe suffisamment fiable détecté'))
                  : ListView(
                      controller: controller,
                      children: [
                        ...visualGroups.map((group) {
                          final pct = (group.confidence * 100).round();
                          return Card(
                            margin: const EdgeInsets.fromLTRB(10, 7, 10, 7),
                            child: ExpansionTile(
                              leading: const Icon(Icons.visibility_outlined),
                              title: Text(
                                '${group.files.length} fichiers visuellement très proches',
                              ),
                              subtitle: Text(
                                'Confiance $pct % • contenu visuel comparé',
                              ),
                              children: [
                                ...group.files.map(
                                  (f) => ListTile(
                                    dense: true,
                                    leading: Icon(_icon(f.kind)),
                                    title: Text(f.name),
                                    subtitle: Text(
                                      '${formatBytes(f.size)}\n${f.entity.path}',
                                    ),
                                    isThreeLine: true,
                                  ),
                                ),
                                const Padding(
                                  padding: EdgeInsets.all(12),
                                  child: Align(
                                    alignment: Alignment.centerLeft,
                                    child: Text(
                                      'Suggestion : comparer avant suppression. '
                                      'Pour les PDF, la première page est utilisée comme empreinte visuelle dans cette version.',
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          );
                        }),
                        ...similarGroups.map((group) {
                          final pct = (group.confidence * 100).round();
                          final sorted = [...group.files]
                            ..sort((a, b) => b.size.compareTo(a.size));
                          final suggestedKeep = sorted.first;

                          return Card(
                            margin: const EdgeInsets.fromLTRB(10, 7, 10, 7),
                            child: ExpansionTile(
                              leading: Icon(
                                group.exact
                                    ? Icons.verified_outlined
                                    : Icons.auto_awesome_motion,
                              ),
                              title: Text(
                                group.exact
                                    ? '${group.files.length} doublons exacts'
                                    : '${group.files.length} fichiers probablement liés',
                              ),
                              subtitle: Text(
                                group.exact
                                    ? 'Confiance 100 %'
                                    : 'Confiance $pct % • noms et tailles comparés',
                              ),
                              children: [
                                ...sorted.map(
                                  (f) => ListTile(
                                    dense: true,
                                    leading: Icon(_icon(f.kind)),
                                    title: Text(f.name),
                                    subtitle: Text(
                                      '${formatBytes(f.size)}\n${f.entity.path}',
                                    ),
                                    isThreeLine: true,
                                  ),
                                ),
                                Padding(
                                  padding: const EdgeInsets.all(12),
                                  child: Align(
                                    alignment: Alignment.centerLeft,
                                    child: Text(
                                      group.exact
                                          ? 'Suggestion : conserver une copie et déplacer les autres en quarantaine.'
                                          : 'Suggestion provisoire : regrouper ces fichiers. '
                                            'Le plus volumineux (${suggestedKeep.name}) n’est pas supprimé automatiquement.',
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          );
                        }),
                      ],
                    ),
            ),
            Padding(
              padding: const EdgeInsets.all(12),
              child: Row(
                children: [
                  Expanded(
                    child: OutlinedButton(
                      onPressed: () => Navigator.pop(ctx),
                      child: const Text('Fermer'),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: FilledButton.icon(
                      onPressed: () {
                        Navigator.pop(ctx);
                        _showOrganizationProposal();
                      },
                      icon: const Icon(Icons.folder_copy_outlined),
                      label: const Text('Voir rangement'),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _showOrganizationProposal() async {
    final candidates = <String, List<ExplorerEntry>>{};

    for (final group in similarGroups.where((g) => !g.exact && g.confidence >= .72)) {
      final first = group.files.first;
      final norm = normalizedFileName(first.name);
      final words = norm.split(' ').where((w) => w.length >= 3).take(4).toList();
      if (words.isEmpty) continue;
      final folderName = words.map((w) => '${w[0].toUpperCase()}${w.substring(1)}').join(' ');
      candidates.putIfAbsent(folderName, () => []).addAll(group.files);
    }

    await showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Rangement proposé'),
        content: SizedBox(
          width: double.maxFinite,
          height: 430,
          child: candidates.isEmpty
              ? const Center(
                  child: Text(
                    'Pas assez de groupes fiables pour proposer un déplacement automatique.',
                  ),
                )
              : ListView(
                  children: candidates.entries.map((e) {
                    final unique = {for (final f in e.value) f.entity.path: f}.values.toList();
                    return ExpansionTile(
                      leading: const Icon(Icons.folder_outlined),
                      title: Text(e.key),
                      subtitle: Text('${unique.length} fichier(s) à regrouper'),
                      children: unique.map((f) => ListTile(
                        dense: true,
                        title: Text(f.name),
                        subtitle: Text(f.entity.path),
                      )).toList(),
                    );
                  }).toList(),
                ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Fermer'),
          ),
          FilledButton(
            onPressed: candidates.isEmpty
                ? null
                : () {
                    Navigator.pop(ctx);
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(
                        content: Text(
                          'Mode aperçu : aucune modification appliquée. '
                          'La validation destructive sera ajoutée séparément.',
                        ),
                      ),
                    );
                  },
            child: const Text('Prévisualiser seulement'),
          ),
        ],
      ),
    );
  }


  Future<void> _bulkRename() async {
    final files = entries.where((e) => selectedPaths.contains(e.entity.path) && !e.isFolder).toList();
    if (files.isEmpty) return;

    final c = TextEditingController(text: p.basename(currentDirectory.path));
    final prefix = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Renommage en série'),
        content: TextField(
          controller: c,
          decoration: const InputDecoration(
            labelText: 'Nom commun',
            helperText: 'Résultat : Nom_001.ext, Nom_002.ext...',
            border: OutlineInputBorder(),
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Annuler')),
          FilledButton(
            onPressed: () => Navigator.pop(ctx, c.text.trim()),
            child: const Text('Continuer'),
          ),
        ],
      ),
    );

    if (prefix == null || prefix.isEmpty) return;

    final preview = <MapEntry<ExplorerEntry, String>>[];
    for (int i = 0; i < files.length; i++) {
      final ext = p.extension(files[i].name);
      preview.add(MapEntry(
        files[i],
        '${prefix}_${(i + 1).toString().padLeft(3, '0')}$ext',
      ));
    }

    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Prévisualisation'),
        content: SizedBox(
          width: double.maxFinite,
          height: 400,
          child: ListView(
            children: preview.map((x) => ListTile(
              dense: true,
              title: Text(x.key.name),
              subtitle: Text('→ ${x.value}'),
            )).toList(),
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Annuler')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Appliquer')),
        ],
      ),
    );

    if (ok != true) return;

    int renamed = 0;
    for (final x in preview) {
      try {
        final file = x.key.entity as File;
        var dest = p.join(p.dirname(file.path), x.value);
        int n = 2;
        while (await File(dest).exists()) {
          final ext = p.extension(x.value);
          final stem = p.basenameWithoutExtension(x.value);
          dest = p.join(p.dirname(file.path), '${stem}_${n.toString().padLeft(3, '0')}$ext');
          n++;
        }
        await file.rename(dest);
        renamed++;
      } catch (_) {}
    }

    selectedPaths.clear();
    await _loadDirectory(currentDirectory);
    if (mounted) setState(() => status = '$renamed fichier(s) renommé(s)');
  }

  Future<void> _filters() async {
    await showModalBottomSheet(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, local) {
          Widget filter(EntryKind kind, String label) {
            return FilterChip(
              selected: activeFilters.contains(kind),
              label: Text(label),
              onSelected: (v) {
                local(() {
                  setState(() {
                    if (v) {
                      activeFilters.add(kind);
                    } else {
                      activeFilters.remove(kind);
                    }
                  });
                });
              },
            );
          }

          return SafeArea(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Wrap(
                spacing: 8,
                runSpacing: 8,
                children: [
                  filter(EntryKind.image, 'Images'),
                  filter(EntryKind.video, 'Vidéos'),
                  filter(EntryKind.audio, 'Audio'),
                  filter(EntryKind.document, 'Documents'),
                  filter(EntryKind.archive, 'Archives'),
                  filter(EntryKind.apk, 'APK'),
                  filter(EntryKind.other, 'Autres'),
                  ActionChip(
                    label: const Text('Tout afficher'),
                    onPressed: () => local(() => setState(activeFilters.clear)),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  IconData _icon(EntryKind kind) {
    switch (kind) {
      case EntryKind.folder: return Icons.folder;
      case EntryKind.image: return Icons.image_outlined;
      case EntryKind.video: return Icons.movie_outlined;
      case EntryKind.audio: return Icons.music_note_outlined;
      case EntryKind.document: return Icons.description_outlined;
      case EntryKind.archive: return Icons.archive_outlined;
      case EntryKind.apk: return Icons.android_outlined;
      case EntryKind.other: return Icons.insert_drive_file_outlined;
    }
  }

  Widget _leading(ExplorerEntry e) {
    if (e.kind == EntryKind.image && e.entity is File) {
      return ClipRRect(
        borderRadius: BorderRadius.circular(6),
        child: Image.file(
          e.entity as File,
          width: 48,
          height: 48,
          fit: BoxFit.cover,
          cacheWidth: 96,
          errorBuilder: (_, __, ___) => const Icon(Icons.image_outlined, size: 34),
        ),
      );
    }
    return Icon(_icon(e.kind), size: 34);
  }

  String formatBytes(int bytes) {
    if (bytes >= 1073741824) return '${(bytes / 1073741824).toStringAsFixed(2)} Go';
    if (bytes >= 1048576) return '${(bytes / 1048576).toStringAsFixed(2)} Mo';
    if (bytes >= 1024) return '${(bytes / 1024).toStringAsFixed(1)} Ko';
    return '$bytes o';
  }

  String _typeLabel(EntryKind kind) {
    switch (kind) {
      case EntryKind.folder: return 'Dossier';
      case EntryKind.image: return 'Image';
      case EntryKind.video: return 'Vidéo';
      case EntryKind.audio: return 'Audio';
      case EntryKind.document: return 'Document';
      case EntryKind.archive: return 'Archive';
      case EntryKind.apk: return 'APK';
      case EntryKind.other: return 'Fichier';
    }
  }

  @override
  Widget build(BuildContext context) {
    final visible = visibleEntries;
    final selectionMode = selectedPaths.isNotEmpty;

    return PopScope(
      canPop: currentDirectory.path == storageRoot,
      onPopInvokedWithResult: (didPop, _) {
        if (!didPop && currentDirectory.path != storageRoot) _goUp();
      },
      child: Scaffold(
        appBar: AppBar(
          title: Text(selectionMode
              ? '${selectedPaths.length} sélectionné(s)'
              : 'File AI Assistant'),
          leading: currentDirectory.path == storageRoot
              ? null
              : IconButton(icon: const Icon(Icons.arrow_back), onPressed: _goUp),
          actions: [
            if (selectionMode)
              IconButton(
                tooltip: 'Tout sélectionner',
                icon: const Icon(Icons.select_all),
                onPressed: _selectAllVisible,
              ),
            if (selectionMode)
              IconButton(
                tooltip: 'Annuler sélection',
                icon: const Icon(Icons.close),
                onPressed: () => setState(selectedPaths.clear),
              ),
            if (!selectionMode)
              IconButton(
                tooltip: 'Filtres',
                icon: const Icon(Icons.filter_alt_outlined),
                onPressed: _filters,
              ),
          ],
        ),
        body: Column(
          children: [
            Container(
              width: double.infinity,
              padding: const EdgeInsets.fromLTRB(12, 8, 12, 8),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    currentDirectory.path.replaceFirst(storageRoot, 'Stockage'),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 4),
                  Row(
                    children: [
                      Expanded(child: Text(status)),
                      if (loading)
                        const SizedBox(
                          width: 18,
                          height: 18,
                          child: CircularProgressIndicator(strokeWidth: 2),
                        ),
                    ],
                  ),
                ],
              ),
            ),
            const Divider(height: 1),
            Expanded(
              child: visible.isEmpty && !loading
                  ? const Center(child: Text('Aucun élément à afficher'))
                  : ListView.builder(
                      itemCount: visible.length,
                      itemBuilder: (_, i) {
                        final e = visible[i];
                        final selected = selectedPaths.contains(e.entity.path);

                        return ListTile(
                          selected: selected,
                          leading: selectionMode && !e.isFolder
                              ? Checkbox(
                                  value: selected,
                                  onChanged: (_) => _toggleSelection(e),
                                )
                              : _leading(e),
                          title: Text(
                            e.name,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                          ),
                          subtitle: Text(
                            e.isFolder
                                ? 'Dossier'
                                : '${_typeLabel(e.kind)} • ${formatBytes(e.size)}',
                          ),
                          trailing: PopupMenuButton<String>(
                            onSelected: (v) {
                              if (v == 'rename') _rename(e);
                            },
                            itemBuilder: (_) => const [
                              PopupMenuItem(
                                value: 'rename',
                                child: Text('Renommer'),
                              ),
                            ],
                          ),
                          onTap: () {
                            if (selectionMode && !e.isFolder) {
                              _toggleSelection(e);
                            } else if (e.isFolder) {
                              _loadDirectory(e.entity as Directory);
                            }
                          },
                          onLongPress: e.isFolder ? () => _rename(e) : () => _toggleSelection(e),
                        );
                      },
                    ),
            ),
          ],
        ),
        floatingActionButton: selectionMode
            ? FloatingActionButton.extended(
                onPressed: _bulkRename,
                icon: const Icon(Icons.drive_file_rename_outline),
                label: const Text('Renommer en série'),
              )
            : null,
        bottomNavigationBar: SafeArea(
          child: Material(
            elevation: 8,
            child: Padding(
              padding: const EdgeInsets.fromLTRB(8, 4, 8, 8),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  SwitchListTile(
                    dense: true,
                    contentPadding: EdgeInsets.zero,
                    value: recursiveAnalysis,
                    title: const Text('Analyser aussi les sous-dossiers'),
                    onChanged: (v) => setState(() => recursiveAnalysis = v),
                  ),
                  SwitchListTile(
                    contentPadding: EdgeInsets.zero,
                    title: const Text('Analyser tout le stockage accessible'),
                    subtitle: Text(
                      scanWholeStorage
                          ? 'Tous les dossiers accessibles + sous-dossiers'
                          : 'Seulement le dossier actuellement ouvert',
                    ),
                    value: scanWholeStorage,
                    onChanged: (v) => setState(() => scanWholeStorage = v),
                  ),
                  Row(
                    children: [
                      Expanded(
                        child: FilledButton.tonalIcon(
                          onPressed: _geminiSettings,
                          icon: const Icon(Icons.key_outlined),
                          label: const Text('Clé Gemini'),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  TextField(
                    controller: aiInstructionController,
                    minLines: 1,
                    maxLines: 3,
                    decoration: InputDecoration(
                      labelText: 'Instruction à l’assistant',
                      hintText: 'Ex : Regroupe les mangas par série...',
                      border: const OutlineInputBorder(),
                      suffixIcon: IconButton(
                        tooltip: 'Clé Gemini',
                        onPressed: _geminiSettings,
                        icon: const Icon(Icons.key_outlined),
                      ),
                    ),
                  ),
                  const SizedBox(height: 6),
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      border: Border.all(color: Theme.of(context).dividerColor),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: const Text('Assistant principal : Gemini + moteur local'),
                  ),
                  const SizedBox(height: 6),
                  SizedBox(
                    width: double.infinity,
                    child: FilledButton.icon(
                      onPressed: (loading || aiBusy || actionBusy)
                          ? null
                          : _geminiAssistantPlan,
                      icon: aiBusy
                          ? const SizedBox(
                              width: 18,
                              height: 18,
                              child: CircularProgressIndicator(strokeWidth: 2),
                            )
                          : const Icon(Icons.psychology_alt_outlined),
                      label: const Text('Gemini : analyser et proposer'),
                    ),
                  ),
                  const SizedBox(height: 6),
                  SizedBox(
                    width: double.infinity,
                    child: OutlinedButton.icon(
                      onPressed: loading ? null : _smartGlobalScan,
                      icon: const Icon(Icons.auto_awesome),
                      label: const Text('Analyse visuelle légère (max 80)'),
                    ),
                  ),
                  const SizedBox(height: 6),
                  Row(
                    children: [
                      Expanded(
                        child: OutlinedButton.icon(
                          onPressed: _autoSelect,
                          icon: const Icon(Icons.auto_awesome_motion),
                          label: const Text('Sélection auto'),
                        ),
                      ),
                      const SizedBox(width: 8),
                      Expanded(
                        child: FilledButton.icon(
                          onPressed: loading ? null : _duplicates,
                          icon: const Icon(Icons.content_copy),
                          label: const Text('Doublons'),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
