# File AI Assistant V11 Gemini Agent

Main workflow:
1. Scan the current folder or all accessible shared storage recursively.
2. Build a compact local inventory.
3. Send metadata to Gemini 2.5 Flash.
4. Gemini returns structured JSON: summary, tree preview, and actions.
5. The app validates every source/destination path.
6. The user reviews selectable actions.
7. Nothing happens until the user presses AGIR.
8. Duplicate/corrupt candidates go to FileAI_Quarantaine, never permanent deletion.

Safety/performance:
- Android/data, Android/obb, caches and thumbnails are skipped.
- 0/1-byte files are ignored.
- Inventory is capped at 12,000 accessible files per scan.
- Gemini receives at most 2,500 compact metadata entries per request.
- Existing lightweight local duplicate/similarity features remain in the project.
- Visual analysis remains separate and limited.
- Gemini cannot invent a valid source path: the app rejects paths absent from the scanned inventory.
- Destination paths outside shared storage are rejected.

Android limitation:
The app can only inspect paths Android grants to the application. It does not bypass Android storage sandbox restrictions.
