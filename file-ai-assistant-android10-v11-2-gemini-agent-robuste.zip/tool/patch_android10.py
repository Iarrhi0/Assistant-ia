import re
from pathlib import Path

manifest = Path("android/app/src/main/AndroidManifest.xml")
text = manifest.read_text(encoding="utf-8")

# Permissions requises (une seule fois chacune, peu importe le format déjà présent)
permissions = [
    '<uses-permission android:name="android.permission.INTERNET" />',
    '<uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />',
    '<uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE" />',
    '<uses-permission android:name="android.permission.WRITE_EXTERNAL_STORAGE" android:maxSdkVersion="29" />',
]

for perm in permissions:
    # Extrait le nom de la permission pour detecter toute variante deja presente
    name_match = re.search(r'android:name="([^"]+)"', perm)
    perm_name = name_match.group(1)
    if perm_name not in text:
        pos = text.find(">")
        text = text[:pos + 1] + "\n    " + perm + text[pos + 1:]

# Stockage externe "legacy" pour compatibilite Android 10
if 'android:requestLegacyExternalStorage="true"' not in text:
    text = text.replace(
        "<application",
        '<application\n        android:requestLegacyExternalStorage="true"',
        1,
    )

text = text.replace('android:label="file_ai_assistant"', 'android:label="File AI Assistant"')
manifest.write_text(text, encoding="utf-8")

# Garder un minSdk compatible Android 10 (Gradle / Gradle Kotlin DSL)
gradle_candidates = [
    Path("android/app/build.gradle.kts"),
    Path("android/app/build.gradle"),
]
for gradle in gradle_candidates:
    if not gradle.exists():
        continue
    g = gradle.read_text(encoding="utf-8")
    g = g.replace("minSdk = flutter.minSdkVersion", "minSdk = 23")
    g = g.replace("minSdkVersion flutter.minSdkVersion", "minSdkVersion 23")
    gradle.write_text(g, encoding="utf-8")

print("Android 10 configuration applied.")
