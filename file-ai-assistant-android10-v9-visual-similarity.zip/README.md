# File AI Assistant V9 Visual Similarity

V9 ajoute une vraie couche de comparaison visuelle locale.

## Ce que la V9 compare

### Images
- lecture locale de l'image
- réduction à 16 x 16
- conversion en niveaux de gris
- average hash perceptuel
- comparaison bit à bit
- noms et tailles utilisés comme renfort de confiance

Cela permet de repérer des images très proches même si elles ont été recompressées ou redimensionnées.

### PDF
- ouverture locale du PDF
- rendu de la première page
- création d'une empreinte visuelle
- comparaison avec d'autres PDF
- nom et taille utilisés comme indices secondaires

Ainsi, deux PDF ayant des noms différents et des poids différents peuvent être rapprochés si leur première page est visuellement très proche.

## Limite volontaire V9

Pour préserver la vitesse et la mémoire sur Android 10 :
- maximum 1 200 candidats visuels par analyse
- première page uniquement pour les PDF
- aucune suppression automatique
- les résultats sont des suggestions

La prochaine amélioration logique serait de comparer plusieurs pages représentatives d'un PDF, par exemple première, milieu et dernière page.

## Détection globale conservée

- SHA-256 pour doublons exacts
- noms normalisés
- tailles proches ou différentes
- recherche dans Download, Documents, DCIM, Pictures, Movies, Music et dossier actuel
- exclusion des dossiers système Android
- fichiers de 0 ou 1 octet ignorés

## Build

ZIP : `file-ai-assistant-android10-v9-visual-similarity.zip`

Workflow : `build-apk-visual-similarity.yml`

Actions > Build APK Visual Similarity > Run workflow
