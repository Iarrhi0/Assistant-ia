# File AI Assistant Android

Application Android Flutter pour analyser et organiser des fichiers localement.

## Fonctions incluses

- scan récursif d'un dossier Android
- doublons exacts par SHA-256
- détection de noms similaires
- détection de tailles proches
- suggestions de renommage uniforme
- détection de Chapitre, Partie, Tome et Volume
- score de confiance
- validation avant renommage
- quarantaine pour les doublons
- commandes texte locales
- aucune suppression définitive automatique

## Exemples de commandes

- trouve les doublons
- trouve les noms similaires
- trouve les tailles proches
- uniformise les noms de ce dossier
- renomme tous les fichiers de cette série
- mets les doublons en quarantaine

## Accès aux fichiers Android

L'application demande l'accès au stockage. Sur Android 11 et plus, l'utilisateur peut devoir autoriser
manuellement Accès à tous les fichiers dans les paramètres.

Cette permission est adaptée à une application personnelle de gestion de fichiers, mais elle peut être
restreinte pour une publication sur Google Play.

## Construire l'APK sur GitHub

Si les fichiers du projet sont directement dans le dépôt :

Actions > Build Android APK > Run workflow

Si tu mets uniquement le ZIP dans le dépôt :

Actions > Unzip And Build Android APK > Run workflow

Le fichier final est disponible dans :

Actions > run terminé > Artifacts > File-AI-Assistant-APK
