package com.fileai.assistant

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
