# File AI Assistant

Assistant local de gestion de fichiers pour Windows.

## Fonctions V2

- Scan récursif d'un dossier
- Détection des doublons exacts par SHA-256
- Détection des noms similaires
- Détection des tailles proches
- Détection des images visuellement similaires avec perceptual hash
- Vérification basique des images corrompues
- Regroupement des fichiers suspects
- Prévisualisation avant action
- Quarantaine au lieu de suppression directe
- Renommage automatique avec suffixes numériques
- Assistant texte local pour interpréter des commandes simples
- Export CSV des résultats
- GitHub Actions pour générer un EXE Windows

## Installation locale

```bash
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
python main.py
```

## Commandes comprises par l'assistant

Exemples :

- trouve les doublons
- trouve les images similaires
- trouve les fichiers corrompus
- trouve les noms similaires
- montre les fichiers de tailles proches
- mets les doublons en quarantaine
- renomme les fichiers avec le même nom
- analyse tout

La V1 utilise un interpréteur local et ne nécessite aucune clé API.

## Générer un EXE sur GitHub

1. Crée un dépôt GitHub.
2. Envoie tous les fichiers du projet.
3. Va dans `Actions`.
4. Lance `Build Windows EXE`.
5. Télécharge l'artefact `File-AI-Assistant-Windows`.

## Sécurité

Aucune suppression définitive automatique.

Les fichiers envoyés en quarantaine sont déplacés dans :

`_FileAI_Quarantine`

Un journal `file_ai_history.jsonl` est créé dans le dossier analysé.

## Limites V1

- La détection de corruption concerne principalement les images.
- La similarité visuelle utilise pHash et non un modèle CLIP.
- L'assistant texte comprend des commandes prédéfinies.
- Les PDF, vidéos et documents Office seront renforcés dans une V2.


## Renommage intelligent V2

L'application peut détecter qu'un dossier contient une même série de fichiers avec des noms incohérents.

Exemple :

```text
Un_Atout_Maitre_Scan_VF_FR_Gratuit.pdf
Chapitre_084_Partie_03_Un_Atout_Maitre.pdf
Chapitre_085_Partie_03_Un_Atout_Maitre.pdf
```

Elle propose alors :

```text
Un_Atout_Maitre_001.pdf
Un_Atout_Maitre_Chapitre_084_Partie_03.pdf
Un_Atout_Maitre_Chapitre_085_Partie_03.pdf
```

Fonctions :
- aperçu avant/après
- niveau de confiance
- cas incertains décochés automatiquement
- format personnalisé
- validation obligatoire avant renommage
- protection contre les collisions de noms
- historique des renommages

Variables disponibles :

```text
{title}
{chapter}
{part}
{volume}
{index}
{ext}
```
