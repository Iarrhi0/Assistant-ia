from dataclasses import dataclass

@dataclass
class Intent:
    action: str
    explanation: str

def interpret(text: str) -> Intent:
    t = text.strip().lower()

    if any(x in t for x in ["analyse tout", "analyser tout", "scan complet", "tout analyser"]):
        return Intent("all", "Je vais lancer toutes les analyses disponibles.")

    if "corromp" in t:
        return Intent("corrupt", "Je vais rechercher les images illisibles ou corrompues.")

    if "image" in t and any(x in t for x in ["sembl", "simil", "presque", "ident"]):
        return Intent("images", "Je vais rechercher les images visuellement similaires.")

    if "nom" in t and any(x in t for x in ["sembl", "simil", "proche", "même"]):
        return Intent("names", "Je vais rechercher les noms de fichiers similaires.")

    if "taille" in t and any(x in t for x in ["proche", "simil", "même"]):
        return Intent("sizes", "Je vais rechercher les fichiers ayant des tailles proches.")

    if "doublon" in t or "double" in t or "copie" in t:
        return Intent("duplicates", "Je vais rechercher les doublons exacts.")

    if "quarantaine" in t:
        return Intent("quarantine_selected", "Je peux déplacer les éléments sélectionnés vers la quarantaine.")

    if "renomm" in t or "uniform" in t or "normalis" in t:
        return Intent("smart_rename", "Je vais analyser le dossier et proposer un format uniforme avant toute modification.")

    return Intent(
        "unknown",
        "Je n'ai pas reconnu précisément la commande. Essaie par exemple : trouve les doublons, images similaires, noms similaires, tailles proches ou fichiers corrompus."
    )
