import hashlib
from collections import defaultdict
from pathlib import Path
from rapidfuzz.fuzz import ratio
from PIL import Image
import imagehash

from .models import Finding

IMAGE_EXTS = {".jpg", ".jpeg", ".png", ".webp", ".bmp", ".gif", ".tif", ".tiff"}

def sha256_file(path: Path, chunk_size=1024 * 1024):
    h = hashlib.sha256()
    with path.open("rb") as f:
        while True:
            chunk = f.read(chunk_size)
            if not chunk:
                break
            h.update(chunk)
    return h.hexdigest()

def exact_duplicates(records, progress=None):
    groups = defaultdict(list)
    total = max(1, len(records))
    for i, r in enumerate(records):
        try:
            r.sha256 = sha256_file(r.path)
            groups[(r.size, r.sha256)].append(r.path)
        except Exception as e:
            r.error = str(e)
        if progress:
            progress(i + 1, total)
    return [
        Finding("Doublon exact", 1.0, paths, "Même taille et même empreinte SHA-256")
        for paths in groups.values() if len(paths) > 1
    ]

def similar_names(records, threshold=88):
    findings = []
    same_ext = defaultdict(list)
    for r in records:
        same_ext[r.suffix].append(r)

    seen = set()
    for ext, group in same_ext.items():
        for i in range(len(group)):
            a = group[i]
            stem_a = a.path.stem.lower()
            for j in range(i + 1, len(group)):
                b = group[j]
                key = tuple(sorted((str(a.path), str(b.path))))
                if key in seen:
                    continue
                stem_b = b.path.stem.lower()
                score = ratio(stem_a, stem_b)
                if score >= threshold:
                    seen.add(key)
                    findings.append(
                        Finding(
                            "Nom similaire",
                            score / 100.0,
                            [a.path, b.path],
                            f"Noms similaires à {score:.0f}%"
                        )
                    )
    return findings

def similar_sizes(records, tolerance=0.03):
    findings = []
    ordered = sorted([r for r in records if r.size > 0], key=lambda r: r.size)
    for i, a in enumerate(ordered):
        for b in ordered[i+1:i+20]:
            denom = max(a.size, b.size)
            diff = abs(a.size - b.size) / denom
            if diff <= tolerance:
                findings.append(
                    Finding(
                        "Taille proche",
                        max(0.0, 1.0 - diff),
                        [a.path, b.path],
                        f"Écart de taille {diff*100:.2f}%"
                    )
                )
            elif b.size > a.size * (1 + tolerance):
                break
    return findings

def image_hashes(records):
    result = []
    for r in records:
        if r.suffix not in IMAGE_EXTS:
            continue
        try:
            with Image.open(r.path) as img:
                img.verify()
            with Image.open(r.path) as img:
                r.phash = str(imagehash.phash(img.convert("RGB")))
            result.append(r)
        except Exception as e:
            r.corrupted = True
            r.error = str(e)
    return result

def corrupted_images(records):
    image_hashes(records)
    return [
        Finding(
            "Fichier corrompu",
            1.0,
            [r.path],
            r.error or "Image illisible"
        )
        for r in records if r.corrupted
    ]

def similar_images(records, max_distance=6):
    imgs = image_hashes(records)
    findings = []
    for i, a in enumerate(imgs):
        if not a.phash:
            continue
        ha = imagehash.hex_to_hash(a.phash)
        for b in imgs[i+1:]:
            if not b.phash:
                continue
            hb = imagehash.hex_to_hash(b.phash)
            d = ha - hb
            if d <= max_distance:
                confidence = max(0.0, 1.0 - d / 64.0)
                findings.append(
                    Finding(
                        "Image similaire",
                        confidence,
                        [a.path, b.path],
                        f"Distance pHash {d}"
                    )
                )
    return findings
