from pathlib import Path
from .models import FileRecord

SKIP_DIRS = {"_FileAI_Quarantine", ".git", ".venv", "__pycache__"}

def scan_folder(folder: Path):
    records = []
    for p in folder.rglob("*"):
        try:
            if any(part in SKIP_DIRS for part in p.parts):
                continue
            if not p.is_file():
                continue
            stat = p.stat()
            records.append(
                FileRecord(
                    path=p,
                    name=p.name,
                    suffix=p.suffix.lower(),
                    size=stat.st_size,
                )
            )
        except OSError:
            continue
    return records
