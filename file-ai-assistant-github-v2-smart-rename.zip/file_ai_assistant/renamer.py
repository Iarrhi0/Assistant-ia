import re
from dataclasses import dataclass
from pathlib import Path
from collections import Counter

@dataclass
class RenameSuggestion:
    original: Path
    suggested_name: str
    confidence: float
    reason: str
    selected_by_default: bool = True

STOPWORDS = {
    "scan", "vf", "fr", "gratuit", "free", "pdf", "final", "copie", "copy",
    "new", "nouveau", "version", "ver", "document"
}

CHAPTER_PATTERNS = [
    re.compile(r"(?:chapitre|chapter|chap|ch)[ _.-]*(\d{1,4})", re.I),
]
PART_PATTERNS = [
    re.compile(r"(?:partie|part|pt)[ _.-]*(\d{1,3})", re.I),
]
VOLUME_PATTERNS = [
    re.compile(r"(?:volume|vol|tome)[ _.-]*(\d{1,3})", re.I),
]

def _clean_tokens(stem: str):
    s = re.sub(r"[_\-.]+", " ", stem)
    s = re.sub(r"\s+", " ", s).strip()
    return [t for t in s.split(" ") if t]

def _extract_num(patterns, stem):
    for p in patterns:
        m = p.search(stem)
        if m:
            return int(m.group(1))
    return None

def _dominant_title(paths):
    token_counter = Counter()
    ordered_candidates = []

    for p in paths:
        tokens = _clean_tokens(Path(p).stem)
        useful = []
        for t in tokens:
            low = t.lower()
            if low in STOPWORDS or low.isdigit() or len(low) < 2:
                continue
            if low in {"chapitre", "chapter", "chap", "ch", "partie", "part", "pt", "vol", "volume", "tome"}:
                continue
            useful.append(t)
            token_counter[low] += 1
        ordered_candidates.append(useful)

    if not token_counter:
        return "Fichier"

    threshold = max(2, int(len(paths) * 0.4))
    common = {t for t, c in token_counter.items() if c >= threshold}

    for candidate in ordered_candidates:
        chosen = [t for t in candidate if t.lower() in common]
        if chosen:
            return "_".join(chosen[:6])

    return token_counter.most_common(1)[0][0].title()

def suggest_folder_renames(paths, custom_format=None):
    paths = [Path(p) for p in paths if Path(p).is_file()]
    if not paths:
        return []

    title = _dominant_title(paths)
    suggestions = []
    used = set()

    for idx, p in enumerate(sorted(paths, key=lambda x: x.name.lower()), start=1):
        stem = p.stem
        chapter = _extract_num(CHAPTER_PATTERNS, stem)
        part = _extract_num(PART_PATTERNS, stem)
        volume = _extract_num(VOLUME_PATTERNS, stem)

        confidence = 0.45
        reasons = [f"Titre dominant détecté : {title}"]

        if chapter is not None:
            confidence += 0.30
            reasons.append(f"chapitre détecté : {chapter}")
        if part is not None:
            confidence += 0.15
            reasons.append(f"partie détectée : {part}")
        if volume is not None:
            confidence += 0.10
            reasons.append(f"volume/tome détecté : {volume}")

        confidence = min(confidence, 0.99)

        if custom_format:
            name = custom_format
            replacements = {
                "{title}": title,
                "{chapter}": f"{chapter:03d}" if chapter is not None else "???",
                "{part}": f"{part:02d}" if part is not None else "??",
                "{volume}": f"{volume:02d}" if volume is not None else "??",
                "{index}": f"{idx:03d}",
                "{ext}": p.suffix,
            }
            for k, v in replacements.items():
                name = name.replace(k, v)
            if not name.lower().endswith(p.suffix.lower()):
                name += p.suffix
        else:
            bits = [title]
            if volume is not None:
                bits.append(f"Tome_{volume:02d}")
            if chapter is not None:
                bits.append(f"Chapitre_{chapter:03d}")
            if part is not None:
                bits.append(f"Partie_{part:02d}")
            if chapter is None and part is None and volume is None:
                bits.append(f"{idx:03d}")
                confidence = min(confidence, 0.69)
                reasons.append("structure non détectée, index proposé")
            name = "_".join(bits) + p.suffix

        candidate = name
        base = Path(name).stem
        ext = Path(name).suffix or p.suffix
        n = 2
        while candidate.lower() in used:
            candidate = f"{base}_{n:03d}{ext}"
            n += 1
        used.add(candidate.lower())

        selected = confidence >= 0.75
        if not selected:
            reasons.append("validation manuelle recommandée")

        suggestions.append(
            RenameSuggestion(
                original=p,
                suggested_name=candidate,
                confidence=confidence,
                reason="; ".join(reasons),
                selected_by_default=selected,
            )
        )

    return suggestions
