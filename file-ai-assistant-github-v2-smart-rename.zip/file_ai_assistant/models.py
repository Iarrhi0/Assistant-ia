from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

@dataclass
class FileRecord:
    path: Path
    name: str
    suffix: str
    size: int
    sha256: Optional[str] = None
    phash: Optional[str] = None
    corrupted: bool = False
    error: Optional[str] = None

@dataclass
class Finding:
    kind: str
    confidence: float
    files: list[Path] = field(default_factory=list)
    reason: str = ""
