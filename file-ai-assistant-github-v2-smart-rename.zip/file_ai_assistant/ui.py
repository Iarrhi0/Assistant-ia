import csv
from pathlib import Path

from PySide6.QtCore import Qt, QThread, Signal
from PySide6.QtWidgets import (
    QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QPushButton, QLabel,
    QFileDialog, QLineEdit, QTableWidget, QTableWidgetItem, QMessageBox,
    QProgressBar, QTextEdit, QHeaderView, QDialog, QDialogButtonBox, QCheckBox, QFormLayout
)

from .scanner import scan_folder
from .analyzers import (
    exact_duplicates, similar_names, similar_sizes,
    similar_images, corrupted_images
)
from .assistant import interpret
from .actions import quarantine, apply_rename_suggestions
from .renamer import suggest_folder_renames

class Worker(QThread):
    done = Signal(object)
    failed = Signal(str)
    progress = Signal(int)

    def __init__(self, fn):
        super().__init__()
        self.fn = fn

    def run(self):
        try:
            result = self.fn(self.progress.emit)
            self.done.emit(result)
        except Exception as e:
            self.failed.emit(str(e))

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("File AI Assistant")
        self.resize(1180, 760)

        self.folder = None
        self.records = []
        self.findings = []
        self.worker = None

        root = QWidget()
        self.setCentralWidget(root)
        layout = QVBoxLayout(root)

        top = QHBoxLayout()
        self.folder_label = QLabel("Aucun dossier sélectionné")
        choose = QPushButton("Choisir un dossier")
        choose.clicked.connect(self.choose_folder)
        scan = QPushButton("Scanner")
        scan.clicked.connect(self.scan)
        top.addWidget(choose)
        top.addWidget(scan)
        top.addWidget(self.folder_label, 1)
        layout.addLayout(top)

        self.progress = QProgressBar()
        self.progress.setValue(0)
        layout.addWidget(self.progress)

        assistant_row = QHBoxLayout()
        self.command = QLineEdit()
        self.command.setPlaceholderText("Ex: Trouve les images similaires et les doublons...")
        ask = QPushButton("Exécuter la demande")
        ask.clicked.connect(self.run_command)
        assistant_row.addWidget(self.command, 1)
        assistant_row.addWidget(ask)
        layout.addLayout(assistant_row)

        self.answer = QTextEdit()
        self.answer.setReadOnly(True)
        self.answer.setMaximumHeight(90)
        self.answer.setPlainText(
            "Assistant local prêt. Commence par choisir un dossier puis clique sur Scanner."
        )
        layout.addWidget(self.answer)

        buttons = QHBoxLayout()
        for text, fn in [
            ("Doublons exacts", self.find_duplicates),
            ("Noms similaires", self.find_names),
            ("Tailles proches", self.find_sizes),
            ("Images similaires", self.find_images),
            ("Corrompus", self.find_corrupt),
            ("Suggérer renommage", self.smart_rename_dialog),
        ]:
            b = QPushButton(text)
            b.clicked.connect(fn)
            buttons.addWidget(b)
        layout.addLayout(buttons)

        self.table = QTableWidget(0, 5)
        self.table.setHorizontalHeaderLabels(
            ["Type", "Confiance", "Fichier 1", "Fichier 2+", "Raison"]
        )
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.ResizeToContents)
        self.table.horizontalHeader().setStretchLastSection(True)
        self.table.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
        self.table.setSelectionMode(QTableWidget.SelectionMode.ExtendedSelection)
        layout.addWidget(self.table, 1)

        bottom = QHBoxLayout()
        quarantine_btn = QPushButton("Mettre la sélection en quarantaine")
        quarantine_btn.clicked.connect(self.quarantine_selected)
        export_btn = QPushButton("Exporter CSV")
        export_btn.clicked.connect(self.export_csv)
        bottom.addWidget(quarantine_btn)
        bottom.addStretch(1)
        bottom.addWidget(export_btn)
        layout.addLayout(bottom)

    def choose_folder(self):
        path = QFileDialog.getExistingDirectory(self, "Choisir le dossier à analyser")
        if path:
            self.folder = Path(path)
            self.folder_label.setText(path)
            self.answer.setPlainText("Dossier sélectionné. Clique sur Scanner.")

    def scan(self):
        if not self.folder:
            QMessageBox.warning(self, "Dossier requis", "Choisis d'abord un dossier.")
            return

        def task(progress):
            progress(10)
            r = scan_folder(self.folder)
            progress(100)
            return r

        self._run_worker(task, self._scan_done)

    def _scan_done(self, records):
        self.records = records
        self.progress.setValue(100)
        total = sum(r.size for r in records)
        self.answer.setPlainText(
            f"Scan terminé : {len(records)} fichiers, {total / (1024**2):.2f} Mo analysables."
        )

    def _ensure_scan(self):
        if not self.records:
            QMessageBox.information(self, "Scan requis", "Scanne d'abord le dossier.")
            return False
        return True

    def _run_worker(self, fn, on_done):
        self.progress.setValue(0)
        self.worker = Worker(fn)
        self.worker.progress.connect(self.progress.setValue)
        self.worker.done.connect(on_done)
        self.worker.failed.connect(lambda e: QMessageBox.critical(self, "Erreur", e))
        self.worker.start()

    def _show(self, findings):
        self.findings = findings
        self.table.setRowCount(0)
        for f in findings:
            row = self.table.rowCount()
            self.table.insertRow(row)
            vals = [
                f.kind,
                f"{f.confidence*100:.1f}%",
                str(f.files[0]) if f.files else "",
                " | ".join(str(x) for x in f.files[1:]),
                f.reason,
            ]
            for col, val in enumerate(vals):
                self.table.setItem(row, col, QTableWidgetItem(val))
        self.answer.setPlainText(f"{len(findings)} groupe(s) ou fichier(s) détecté(s).")

    def find_duplicates(self):
        if not self._ensure_scan(): return
        def task(progress):
            return exact_duplicates(self.records, lambda a,b: progress(int(a/b*100)))
        self._run_worker(task, self._show)

    def find_names(self):
        if not self._ensure_scan(): return
        self._show(similar_names(self.records))

    def find_sizes(self):
        if not self._ensure_scan(): return
        self._show(similar_sizes(self.records))

    def find_images(self):
        if not self._ensure_scan(): return
        def task(progress):
            progress(5)
            out = similar_images(self.records)
            progress(100)
            return out
        self._run_worker(task, self._show)

    def find_corrupt(self):
        if not self._ensure_scan(): return
        def task(progress):
            progress(5)
            out = corrupted_images(self.records)
            progress(100)
            return out
        self._run_worker(task, self._show)

    def run_command(self):
        if not self._ensure_scan(): return
        intent = interpret(self.command.text())
        self.answer.setPlainText(intent.explanation)

        if intent.action == "duplicates":
            self.find_duplicates()
        elif intent.action == "names":
            self.find_names()
        elif intent.action == "sizes":
            self.find_sizes()
        elif intent.action == "images":
            self.find_images()
        elif intent.action == "corrupt":
            self.find_corrupt()
        elif intent.action == "all":
            self.run_all()
        elif intent.action == "quarantine_selected":
            self.quarantine_selected()
        elif intent.action == "smart_rename":
            self.smart_rename_dialog()

    def run_all(self):
        if not self._ensure_scan(): return
        def task(progress):
            all_findings = []
            progress(5)
            all_findings += exact_duplicates(self.records)
            progress(35)
            all_findings += similar_names(self.records)
            progress(50)
            all_findings += similar_sizes(self.records)
            progress(65)
            all_findings += similar_images(self.records)
            progress(85)
            all_findings += corrupted_images(self.records)
            progress(100)
            return all_findings
        self._run_worker(task, self._show)

    def selected_paths(self):
        rows = sorted({idx.row() for idx in self.table.selectionModel().selectedRows()})
        paths = []
        for row in rows:
            if row >= len(self.findings):
                continue
            paths.extend(self.findings[row].files[1:] or self.findings[row].files[:1])
        return list(dict.fromkeys(paths))

    def quarantine_selected(self):
        if not self.folder:
            return
        paths = self.selected_paths()
        if not paths:
            QMessageBox.information(self, "Sélection", "Sélectionne au moins une ligne.")
            return

        confirm = QMessageBox.question(
            self,
            "Confirmer",
            f"Déplacer {len(paths)} fichier(s) dans _FileAI_Quarantine ?",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
        )
        if confirm != QMessageBox.StandardButton.Yes:
            return

        moved = quarantine(paths, self.folder)
        QMessageBox.information(
            self, "Terminé",
            f"{len(moved)} fichier(s) déplacé(s) en quarantaine."
        )
        self.scan()


def smart_rename_dialog(self):
    if not self._ensure_scan():
        return

    dialog = QDialog(self)
    dialog.setWindowTitle("Suggestions de renommage")
    dialog.resize(1100, 650)
    v = QVBoxLayout(dialog)

    info = QLabel(
        "Analyse du dossier et proposition d'un format commun. "
        "Aucun fichier n'est renommé avant validation."
    )
    info.setWordWrap(True)
    v.addWidget(info)

    form = QFormLayout()
    custom = QLineEdit()
    custom.setPlaceholderText("{title}_Chapitre_{chapter}_Partie_{part}{ext}")
    form.addRow("Format personnalisé :", custom)
    v.addLayout(form)

    table = QTableWidget(0, 5)
    table.setHorizontalHeaderLabels(
        ["Appliquer", "Nom actuel", "Nom suggéré", "Confiance", "Raison"]
    )
    table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.ResizeToContents)
    table.horizontalHeader().setStretchLastSection(True)
    v.addWidget(table, 1)

    current_suggestions = []

    def load_suggestions():
        nonlocal current_suggestions
        fmt = custom.text().strip() or None
        current_suggestions = suggest_folder_renames(
            [r.path for r in self.records], custom_format=fmt
        )
        table.setRowCount(0)
        for s in current_suggestions:
            row = table.rowCount()
            table.insertRow(row)

            chk = QCheckBox()
            chk.setChecked(s.selected_by_default)
            table.setCellWidget(row, 0, chk)

            table.setItem(row, 1, QTableWidgetItem(s.original.name))
            table.setItem(row, 2, QTableWidgetItem(s.suggested_name))
            table.setItem(row, 3, QTableWidgetItem(f"{s.confidence*100:.0f}%"))
            table.setItem(row, 4, QTableWidgetItem(s.reason))

    refresh = QPushButton("Actualiser les suggestions")
    refresh.clicked.connect(load_suggestions)
    v.addWidget(refresh)

    buttons = QDialogButtonBox(
        QDialogButtonBox.StandardButton.Apply |
        QDialogButtonBox.StandardButton.Cancel
    )
    buttons.button(QDialogButtonBox.StandardButton.Apply).setText(
        "Appliquer les renommages cochés"
    )
    buttons.button(QDialogButtonBox.StandardButton.Cancel).setText("Annuler")
    v.addWidget(buttons)

    def apply():
        chosen = []
        for row, s in enumerate(current_suggestions):
            widget = table.cellWidget(row, 0)
            if widget and widget.isChecked():
                chosen.append(s)

        if not chosen:
            QMessageBox.information(dialog, "Aucune sélection", "Aucun renommage sélectionné.")
            return

        confirm = QMessageBox.question(
            dialog,
            "Confirmer le renommage",
            f"Appliquer {len(chosen)} renommage(s) ?",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
        )
        if confirm != QMessageBox.StandardButton.Yes:
            return

        renamed = apply_rename_suggestions(chosen, self.folder)
        QMessageBox.information(
            dialog, "Terminé", f"{len(renamed)} fichier(s) renommé(s)."
        )
        dialog.accept()
        self.scan()

    buttons.accepted.connect(apply)
    buttons.rejected.connect(dialog.reject)

    load_suggestions()
    dialog.exec()

    def export_csv(self):
        if not self.findings:
            QMessageBox.information(self, "Aucun résultat", "Aucun résultat à exporter.")
            return
        path, _ = QFileDialog.getSaveFileName(
            self, "Exporter les résultats", "file_ai_results.csv", "CSV (*.csv)"
        )
        if not path:
            return
        with open(path, "w", newline="", encoding="utf-8-sig") as f:
            w = csv.writer(f)
            w.writerow(["type", "confidence", "files", "reason"])
            for item in self.findings:
                w.writerow([
                    item.kind,
                    f"{item.confidence:.4f}",
                    " | ".join(map(str, item.files)),
                    item.reason
                ])
        QMessageBox.information(self, "Export", "Export CSV terminé.")
