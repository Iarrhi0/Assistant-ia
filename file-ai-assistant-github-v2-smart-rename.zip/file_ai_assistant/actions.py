import json
import shutil
from datetime import datetime
from pathlib import Path

def _log(base: Path, payload: dict):
    log = base / "file_ai_history.jsonl"
    payload = {"time": datetime.now().isoformat(timespec="seconds"), **payload}
    with log.open("a", encoding="utf-8") as f:
        f.write(json.dumps(payload, ensure_ascii=False) + "\n")

def quarantine(paths, base: Path):
    q = base / "_FileAI_Quarantine"
    q.mkdir(exist_ok=True)
    moved = []
    for src in paths:
        src = Path(src)
        if not src.exists() or not src.is_file():
            continue
        dest = q / src.name
        n = 1
        while dest.exists():
            dest = q / f"{src.stem}_{n:03d}{src.suffix}"
            n += 1
        shutil.move(str(src), str(dest))
        moved.append((src, dest))
        _log(base, {"action": "quarantine", "from": str(src), "to": str(dest)})
    return moved

def rename_numbered(paths, base: Path):
    renamed = []
    grouped = {}
    for p in map(Path, paths):
        grouped.setdefault((p.parent, p.stem.lower(), p.suffix.lower()), []).append(p)

    for _, group in grouped.items():
        if len(group) < 2:
            continue
        for idx, src in enumerate(sorted(group), start=1):
            if not src.exists():
                continue
            dest = src.with_name(f"{src.stem}_{idx:03d}{src.suffix}")
            if dest == src:
                continue
            n = idx
            while dest.exists():
                n += 1
                dest = src.with_name(f"{src.stem}_{n:03d}{src.suffix}")
            src.rename(dest)
            renamed.append((src, dest))
            _log(base, {"action": "rename", "from": str(src), "to": str(dest)})
    return renamed


def apply_rename_suggestions(suggestions, base: Path):
    base = Path(base)
    prepared = []

    for s in suggestions:
        src = Path(s.original)
        if not src.exists() or not src.is_file():
            continue
        dest = src.with_name(s.suggested_name)
        if src == dest:
            continue
        prepared.append((src, dest))

    staged = []
    for i, (src, dest) in enumerate(prepared, start=1):
        tmp = src.with_name(f".__fileai_tmp_{i:06d}{src.suffix}")
        n = i
        while tmp.exists():
            n += 1
            tmp = src.with_name(f".__fileai_tmp_{n:06d}{src.suffix}")
        src.rename(tmp)
        staged.append((src, tmp, dest))

    renamed = []
    for original, tmp, desired in staged:
        dest = desired
        n = 2
        while dest.exists():
            dest = desired.with_name(f"{desired.stem}_{n:03d}{desired.suffix}")
            n += 1
        tmp.rename(dest)
        renamed.append((original, dest))
        _log(base, {"action": "smart_rename", "from": str(original), "to": str(dest)})

    return renamed
