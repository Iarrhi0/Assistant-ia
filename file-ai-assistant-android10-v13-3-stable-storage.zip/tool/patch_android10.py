from pathlib import Path
import re

manifest = Path("android/app/src/main/AndroidManifest.xml")
text = manifest.read_text(encoding="utf-8")

# Android 10 (API 29): legacy shared-storage access is intentionally enabled
# because this personal file-manager needs to scan, move and rename files in
# shared storage. Keep each permission exactly once.
required_permissions = [
    '<uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE" />',
    '<uses-permission android:name="android.permission.WRITE_EXTERNAL_STORAGE" android:maxSdkVersion="29" />',
]

# Remove every existing READ/WRITE declaration first, regardless of spacing or maxSdk.
text = re.sub(
    r'\s*<uses-permission\b[^>]*android:name="android\.permission\.(?:READ_EXTERNAL_STORAGE|WRITE_EXTERNAL_STORAGE)"[^>]*/>\s*',
    '\n',
    text,
    flags=re.MULTILINE,
)

manifest_end = text.find('>')
if manifest_end == -1:
    raise RuntimeError('Invalid AndroidManifest.xml: <manifest> not found')

text = (
    text[:manifest_end + 1]
    + '\n    '
    + '\n    '.join(required_permissions)
    + text[manifest_end + 1:]
)

if 'android:requestLegacyExternalStorage="true"' not in text:
    text = text.replace(
        '<application',
        '<application\n        android:requestLegacyExternalStorage="true"',
        1,
    )

text = text.replace(
    'android:label="file_ai_assistant"',
    'android:label="File AI Assistant"',
)
text = re.sub(r'\n{3,}', '\n\n', text)
manifest.write_text(text, encoding='utf-8')

for gradle in [
    Path('android/app/build.gradle.kts'),
    Path('android/app/build.gradle'),
]:
    if not gradle.exists():
        continue
    g = gradle.read_text(encoding='utf-8')
    g = g.replace('minSdk = flutter.minSdkVersion', 'minSdk = 23')
    g = g.replace('minSdkVersion flutter.minSdkVersion', 'minSdkVersion 23')
    gradle.write_text(g, encoding='utf-8')

print('Android 10 storage configuration applied.')
