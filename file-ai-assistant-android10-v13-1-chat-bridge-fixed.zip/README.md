# V13.1 Chat Bridge Fixed

Correction de compilation du viewer de plan importé.

# File AI Assistant V13 Chat Bridge

Sans API, sans Firebase, sans connexion directe entre ChatGPT et le téléphone.

Workflow :
1. Créer PHONE_SNAPSHOT.zip dans l'app.
2. Uploader ce ZIP dans ChatGPT.
3. Discuter et corriger le plan de rangement dans ChatGPT.
4. Demander à ChatGPT de générer FILEAI_PLAN.json.
5. Télécharger ce JSON dans Android Download.
6. Importer le plan dans l'app.
7. Dry-run et aperçu avant/après.
8. Cocher/décocher les actions.
9. Appuyer sur AGIR.

Le snapshot contient :
- inventory.json
- folder_tree.txt
- statistics.json
- duplicate_candidates.json
- FILEAI_PLAN_SCHEMA.json
- INSTRUCTIONS_FOR_CHATGPT.txt
- previews/index.json
- maximum 24 miniatures légères représentatives

Stabilité Android 10 :
- inventaire écrit progressivement sur disque
- miniatures très limitées
- PDF en aperçu basse résolution
- timeout pour les aperçus
- pauses régulières pendant le scan
- 0/1 octet ignorés
- Android/data, Android/obb, temp et quarantaine ignorés
- aucune exécution immédiate après import du plan
