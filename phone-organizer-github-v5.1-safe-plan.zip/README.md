# Phone Organizer

Application Android native permettant de :

1. Choisir un dossier de stockage avec le sélecteur Android.
2. Inspecter récursivement les fichiers accessibles.
3. Calculer SHA-256, taille, MIME, date et chemin.
4. Détecter les doublons certains par hash.
5. Exporter `PHONE_SNAPSHOT_*.json`.
6. Envoyer ce snapshot à ChatGPT et préparer un `PHONE_PLAN.json`.
7. Réimporter le plan dans l'application.
8. Simuler les opérations avant exécution.
9. Exécuter les créations de dossiers, déplacements et renommages.
10. Placer les suppressions demandées dans `_PhoneOrganizer_Trash` au lieu de supprimer définitivement.

## Important

Android protège certains emplacements. L'application utilise Storage Access Framework : l'utilisateur choisit explicitement l'arborescence à laquelle il autorise l'accès.

## Format du plan

```json
{
  "plan_version": 2,
  "operations": [
    {"action":"create_folder","destination":"Documents/Finance"},
    {"action":"move","file_id":"F000001","source_path":"Download/facture.pdf","source_size":12540,"source_quick_hash":"...","source_sha256":"","to":"Documents/Finance/facture.pdf"},
    {"action":"rename","file_id":"F000002","source_path":"Download/CV.pdf","source_size":45000,"source_quick_hash":"...","source_sha256":"...","new_name":"CV_2026.pdf"},
    {"action":"trash","file_id":"F000003","source_path":"Pictures/doublon.jpg","source_size":9000,"source_quick_hash":"...","source_sha256":"..."}
  ]
}
```

Les chemins sont relatifs à la racine choisie dans l'application.

Après avoir importé un plan, relancer obligatoirement l'inspection avant la
simulation. V5.1 résout les fichiers par `source_path` et vérifie la taille et
les empreintes disponibles. Les anciens identifiants `Fxxxxxx` restent acceptés
pour compatibilité, mais ne sont plus utilisés seuls dans un plan V2.

## Build GitHub

Le workflow `.github/workflows/build-apk.yml` génère automatiquement l'APK Debug.
Après le build : GitHub > Actions > Build Android APK > Artifacts > PhoneOrganizer-debug.


## V3

- Barre de progression avec pourcentage pendant l'inspection.
- Barre de progression pendant l'exécution du plan.
- Inspection limitée au dossier explicitement choisi par l'utilisateur.
- Exclusion des dossiers/fichiers cachés et de plusieurs emplacements système courants.
- Aucun scan global forcé du téléphone.

## V5 Fast Scan
- Les dossiers commençant par `.` restent scannés.
- Ignore seulement les zones système ciblées : Android/data, Android/obb, LOST.DIR, System Volume Information, .android_secure.
- Android/media reste scanné.
- Empreinte rapide sur les 256 premiers Kio de chaque fichier.
- SHA-256 complet seulement pour les candidats doublons de même taille + même empreinte rapide.
- Snapshot V2 : ajout de quick_hash. sha256 peut être vide si aucune vérification complète n'était nécessaire.
- Avant suppression d'une source déplacée, une vérification SHA-256 complète reste obligatoire.

## V5.1 Safe Plan

- Force une nouvelle inspection après l'import du plan.
- Ne dépend plus uniquement des identifiants volatils `Fxxxxxx`.
- Vérifie chemin, taille, empreinte rapide et SHA-256 lorsqu'ils sont disponibles.
- Bloque une opération si sa source est absente ou a changé.
