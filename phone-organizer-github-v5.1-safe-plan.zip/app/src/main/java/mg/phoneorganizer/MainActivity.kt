package mg.phoneorganizer

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.DocumentsContract
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.documentfile.provider.DocumentFile
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedInputStream
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.*
import kotlin.concurrent.thread

class MainActivity : AppCompatActivity() {
    private val PICK_TREE = 10
    private val SAVE_SNAPSHOT = 11
    private val PICK_PLAN = 12

    private var rootUri: Uri? = null
    private var snapshotJson: String? = null
    private var planJson: String? = null
    private val indexed = LinkedHashMap<String, FileEntry>()

    private lateinit var status: TextView
    private lateinit var progress: ProgressBar
    private lateinit var progressText: TextView
    private lateinit var btnScan: Button
    private lateinit var btnExport: Button
    private lateinit var btnImport: Button
    private lateinit var btnSimulate: Button
    private lateinit var btnExecute: Button

    data class FileEntry(
        val id: String,
        val uri: Uri,
        val path: String,
        val name: String,
        val size: Long,
        val modified: Long,
        val mime: String,
        val quickHash: String,
        val sha256: String
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val scroll = ScrollView(this)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(36, 48, 36, 48)
        }
        scroll.addView(box)

        fun title(t: String, size: Float) = TextView(this).apply {
            text = t
            textSize = size
            setPadding(0, 8, 0, 16)
        }
        fun button(t: String) = Button(this).apply {
            text = t
            isAllCaps = false
        }

        box.addView(title("Phone Organizer V5.1", 28f))
        box.addView(title("Inspecter → exporter → importer le plan → réinspecter → simuler → exécuter", 16f))

        val choose = button("1. Choisir le dossier à inspecter")
        btnScan = button("2. Inspection rapide et doublons")
        btnExport = button("3. Exporter le Snapshot JSON")
        btnImport = button("4. Importer PHONE_PLAN.json")
        btnSimulate = button("5. Simuler le plan")
        btnExecute = button("6. Exécuter le plan")
        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            visibility = View.GONE
            isIndeterminate = false
            max = 100
            progress = 0
        }
        progressText = TextView(this).apply {
            text = "0%"
            textSize = 16f
            gravity = Gravity.CENTER_HORIZONTAL
            visibility = View.GONE
            setPadding(0, 8, 0, 8)
        }
        status = TextView(this).apply {
            text = "Aucun dossier sélectionné."
            textSize = 15f
            setPadding(0, 24, 0, 24)
        }

        listOf(choose, btnScan, btnExport, btnImport, btnSimulate, btnExecute).forEach { box.addView(it) }
        box.addView(progress)
        box.addView(progressText)
        box.addView(status)
        setContentView(scroll)

        btnScan.isEnabled = false
        btnExport.isEnabled = false
        btnSimulate.isEnabled = false
        btnExecute.isEnabled = false

        choose.setOnClickListener { chooseTree() }
        btnScan.setOnClickListener { scan() }
        btnExport.setOnClickListener { saveSnapshot() }
        btnImport.setOnClickListener { pickPlan() }
        btnSimulate.setOnClickListener { simulatePlan() }
        btnExecute.setOnClickListener { executePlan() }
    }

    private fun chooseTree() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).apply {
            addFlags(
                Intent.FLAG_GRANT_READ_URI_PERMISSION or
                Intent.FLAG_GRANT_WRITE_URI_PERMISSION or
                Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION or
                Intent.FLAG_GRANT_PREFIX_URI_PERMISSION
            )
        }
        startActivityForResult(intent, PICK_TREE)
    }

    @Deprecated("Deprecated in Android API, kept for broad compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != Activity.RESULT_OK || data?.data == null) return
        val uri = data.data!!

        when (requestCode) {
            PICK_TREE -> {
                rootUri = uri
                try {
                    contentResolver.takePersistableUriPermission(
                        uri,
                        Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                    )
                } catch (_: Exception) {}
                btnScan.isEnabled = true
                status.text = "Dossier sélectionné. Seul ce dossier et ses sous-dossiers seront inspectés.\n$uri"
            }
            SAVE_SNAPSHOT -> {
                snapshotJson?.let { json ->
                    contentResolver.openOutputStream(uri)?.bufferedWriter()?.use { it.write(json) }
                    status.text = "Snapshot enregistré."
                }
            }
            PICK_PLAN -> {
                val text = contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
                if (text != null) {
                    try {
                        val obj = JSONObject(text)
                        if (!obj.has("operations")) throw Exception("operations manquant")
                        planJson = text
                        // ACTION_OPEN_DOCUMENT peut recréer l’activité et tout index en
                        // mémoire devient alors inutilisable. Une nouvelle inspection est
                        // obligatoire et les plans V2 seront résolus par chemin vérifié.
                        indexed.clear()
                        btnSimulate.isEnabled = false
                        btnExecute.isEnabled = false
                        status.text = "Plan importé : ${obj.getJSONArray("operations").length()} opérations.\nRelance maintenant l’inspection, puis simule."
                    } catch (e: Exception) {
                        status.text = "Plan invalide : ${e.message}"
                    }
                }
            }
        }
    }

    private fun scan() {
        val uri = rootUri ?: return
        progress.visibility = View.VISIBLE
        progress.progress = 0
        progressText.visibility = View.VISIBLE
        progressText.text = "0%"
        btnScan.isEnabled = false
        status.text = "Préparation de l'inspection…"

        thread {
            try {
                indexed.clear()
                val root = DocumentFile.fromTreeUri(this, uri) ?: error("Racine inaccessible")
                val raw = mutableListOf<Pair<DocumentFile, String>>()

                runOnUiThread {
                    status.text = "Analyse de l'arborescence du dossier sélectionné…"
                }

                collect(root, "", raw)

                val total = raw.size.coerceAtLeast(1)
                var n = 0

                data class Candidate(
                    val id: String, val doc: DocumentFile, val path: String,
                    val name: String, val size: Long, val modified: Long,
                    val mime: String, val quick: String
                )

                val candidates = mutableListOf<Candidate>()

                // Passe rapide : seulement 256 Kio lus par fichier.
                raw.forEach { (doc, path) ->
                    n++
                    val id = "F" + n.toString().padStart(6, '0')
                    candidates.add(Candidate(
                        id, doc, path, doc.name ?: "sans_nom",
                        doc.length(), doc.lastModified(),
                        doc.type ?: "application/octet-stream",
                        quickHash(doc.uri)
                    ))

                    val percent = ((n * 65.0) / total).toInt().coerceIn(0, 65)
                    if (n == 1 || n % 20 == 0 || n == total) {
                        runOnUiThread {
                            progress.progress = percent
                            progressText.text = "$percent%"
                            status.text = "Scan rapide : $n / ${raw.size} fichiers"
                        }
                    }
                }

                // SHA-256 complet uniquement si taille + empreinte rapide correspondent.
                val plausible = candidates.groupBy { Pair(it.size, it.quick) }
                    .filter { (key, list) ->
                        key.first > 0L && key.second.isNotBlank() && list.size > 1
                    }

                val fullHashes = HashMap<String, String>()
                var checked = 0
                val plausibleCount = plausible.values.sumOf { it.size }.coerceAtLeast(1)
                plausible.values.flatten().forEach { c ->
                    fullHashes[c.id] = sha256(c.doc.uri)
                    checked++
                    val percent = (65 + checked * 35.0 / plausibleCount).toInt().coerceIn(65, 100)
                    if (checked == 1 || checked % 10 == 0 || checked == plausibleCount) {
                        runOnUiThread {
                            progress.progress = percent
                            progressText.text = "$percent%"
                            status.text = "Vérification doublons : $checked / $plausibleCount candidats"
                        }
                    }
                }

                val hashGroups = HashMap<String, MutableList<String>>()
                candidates.forEach { c ->
                    val hash = fullHashes[c.id] ?: ""
                    indexed[c.id] = FileEntry(
                        c.id, c.doc.uri, c.path, c.name, c.size, c.modified,
                        c.mime, c.quick, hash
                    )
                    if (hash.isNotBlank()) hashGroups.getOrPut(hash) { mutableListOf() }.add(c.id)
                }

                val files = JSONArray()
                indexed.values.forEach { e ->
                    files.put(JSONObject().apply {
                        put("id", e.id)
                        put("path", e.path)
                        put("name", e.name)
                        put("size", e.size)
                        put("modified", e.modified)
                        put("mime", e.mime)
                        put("quick_hash", e.quickHash)
                        put("sha256", e.sha256)
                    })
                }

                val duplicates = JSONArray()
                hashGroups.filter { it.key.isNotBlank() && it.value.size > 1 }.forEach { (hash, ids) ->
                    duplicates.put(JSONObject().apply {
                        put("sha256", hash)
                        put("file_ids", JSONArray(ids))
                        put("count", ids.size)
                    })
                }

                val rootObj = JSONObject().apply {
                    put("snapshot_version", 2)
                    put("generated_at", SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssXXX", Locale.US).format(Date()))
                    put("scan_scope", "selected_folder_only")
                    put("system_files_excluded", true)
                    put("hash_strategy", "quick_hash_all_full_sha256_duplicate_candidates_only")
                    put("file_count", indexed.size)
                    put("duplicate_groups", duplicates)
                    put("files", files)
                }
                snapshotJson = rootObj.toString(2)

                runOnUiThread {
                    progress.progress = 100
                    progressText.text = "100%"
                    btnScan.isEnabled = true
                    btnExport.isEnabled = true
                    btnSimulate.isEnabled = planJson != null
                    status.text = "Inspection terminée.\n${indexed.size} fichiers analysés.\n${duplicates.length()} groupes de doublons certains."
                }
            } catch (e: Exception) {
                runOnUiThread {
                    progress.visibility = View.GONE
                    progressText.visibility = View.GONE
                    btnScan.isEnabled = true
                    status.text = "Erreur d'inspection : ${e.message}"
                }
            }
        }
    }

    private fun collect(dir: DocumentFile, prefix: String, out: MutableList<Pair<DocumentFile, String>>) {
        val children = try { dir.listFiles() } catch (_: Exception) { emptyArray() }
        children.forEach { f ->
            val name = f.name ?: "sans_nom"
            val path = if (prefix.isBlank()) name else "$prefix/$name"

            // Un nom commençant par "." n'est pas une raison d'exclusion.
            if (f.isDirectory && isSystemDirectory(path)) return@forEach

            if (f.isDirectory) collect(f, path, out)
            else if (f.isFile) out.add(f to path)
        }
    }

    private fun isSystemDirectory(rawPath: String): Boolean {
        val p = rawPath.replace("\\", "/").trim('/').lowercase(Locale.ROOT)
        val parts = p.split("/").filter { it.isNotBlank() }

        if (parts.size == 1 && parts[0] in setOf(
                "lost.dir", "system volume information", ".android_secure"
            )
        ) return true

        // Android/media reste scanné : il peut contenir les médias utilisateur.
        for (i in 0 until parts.size - 1) {
            if (parts[i] == "android" &&
                (parts[i + 1] == "data" || parts[i + 1] == "obb")
            ) return true
        }
        return false
    }

    private fun quickHash(uri: Uri): String {
        val md = MessageDigest.getInstance("SHA-256")
        contentResolver.openInputStream(uri)?.use { raw ->
            BufferedInputStream(raw).use { input ->
                val buffer = ByteArray(256 * 1024)
                val read = input.read(buffer)
                if (read > 0) md.update(buffer, 0, read)
            }
        } ?: return ""
        return md.digest().joinToString("") { "%02x".format(it) }.take(24)
    }

    private fun sha256(uri: Uri): String {
        val md = MessageDigest.getInstance("SHA-256")
        contentResolver.openInputStream(uri)?.use { raw ->
            BufferedInputStream(raw).use { input ->
                val buffer = ByteArray(1024 * 1024)
                while (true) {
                    val read = input.read(buffer)
                    if (read <= 0) break
                    md.update(buffer, 0, read)
                }
            }
        } ?: return ""
        return md.digest().joinToString("") { "%02x".format(it) }
    }

    private fun saveSnapshot() {
        if (snapshotJson == null) return
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            type = "application/json"
            putExtra(Intent.EXTRA_TITLE, "PHONE_SNAPSHOT_$stamp.json")
        }
        startActivityForResult(intent, SAVE_SNAPSHOT)
    }

    private fun pickPlan() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            type = "*/*"
            addCategory(Intent.CATEGORY_OPENABLE)
        }
        startActivityForResult(intent, PICK_PLAN)
    }

    private fun simulatePlan() {
        val text = planJson ?: return
        try {
            val ops = JSONObject(text).getJSONArray("operations")
            var create = 0; var move = 0; var rename = 0; var trash = 0; var invalid = 0
            for (i in 0 until ops.length()) {
                val o = ops.getJSONObject(i)
                when (o.optString("action")) {
                    "create_folder" -> create++
                    "move" -> if (resolveEntry(o) != null) move++ else invalid++
                    "rename" -> if (resolveEntry(o) != null) rename++ else invalid++
                    "trash" -> if (resolveEntry(o) != null) trash++ else invalid++
                    else -> invalid++
                }
            }
            btnExecute.isEnabled = invalid == 0
            status.text = """
                SIMULATION
                Dossiers à créer : $create
                Déplacements : $move
                Renommages : $rename
                Mise en quarantaine : $trash
                Opérations invalides : $invalid

                ${if (invalid == 0) "Plan exécutable." else if (indexed.isEmpty()) "Index absent : relancer l’inspection APRÈS avoir importé le plan." else "Exécution bloquée : sources absentes ou modifiées."}
            """.trimIndent()
        } catch (e: Exception) {
            status.text = "Simulation impossible : ${e.message}"
        }
    }

    private fun executePlan() {
        val uri = rootUri ?: return
        val text = planJson ?: return
        btnExecute.isEnabled = false
        progress.visibility = View.VISIBLE
        progress.progress = 0
        progressText.visibility = View.VISIBLE
        progressText.text = "0%"
        status.text = "Exécution en cours…"

        thread {
            var ok = 0
            val errors = mutableListOf<String>()
            try {
                val root = DocumentFile.fromTreeUri(this, uri) ?: error("Racine inaccessible")
                val ops = JSONObject(text).getJSONArray("operations")
                for (i in 0 until ops.length()) {
                    val o = ops.getJSONObject(i)
                    val percent = (((i + 1) * 100.0) / ops.length().coerceAtLeast(1)).toInt()
                    runOnUiThread {
                        progress.progress = percent
                        progressText.text = "$percent%"
                        status.text = "Exécution : ${i + 1} / ${ops.length()} opérations"
                    }
                    try {
                        when (o.getString("action")) {
                            "create_folder" -> {
                                ensureDir(root, cleanPath(o.getString("destination")))
                                ok++
                            }
                            "rename" -> {
                                val e = resolveEntry(o) ?: error("Source absente ou modifiée")
                                val doc = DocumentFile.fromSingleUri(this, e.uri) ?: error("Fichier inaccessible")
                                if (!doc.renameTo(safeName(o.getString("new_name")))) error("Renommage refusé")
                                ok++
                            }
                            "move" -> {
                                val e = resolveEntry(o) ?: error("Source absente ou modifiée")
                                val to = cleanPath(o.getString("to"))
                                moveByCopy(root, e, to)
                                ok++
                            }
                            "trash" -> {
                                val e = resolveEntry(o) ?: error("Source absente ou modifiée")
                                val target = "_PhoneOrganizer_Trash/${System.currentTimeMillis()}_${safeName(e.name)}"
                                moveByCopy(root, e, target)
                                ok++
                            }
                        }
                    } catch (e: Exception) {
                        errors.add("Op ${i + 1}: ${e.message}")
                    }
                }
            } catch (e: Exception) {
                errors.add(e.message ?: "Erreur inconnue")
            }

            runOnUiThread {
                progress.visibility = View.GONE
                status.text = "Exécution terminée.\nRéussies : $ok\nErreurs : ${errors.size}" +
                    if (errors.isNotEmpty()) "\n\n" + errors.take(15).joinToString("\n") else ""
            }
        }
    }

    /**
     * Plans V2 identify a source by its snapshot path instead of relying only
     * on the volatile Fxxxxxx number.  The size and hashes prevent a different
     * file at the same path from being selected silently.
     */
    private fun resolveEntry(o: JSONObject): FileEntry? {
        val sourcePath = cleanPath(o.optString("source_path"))
        val candidate = if (sourcePath.isNotBlank()) {
            indexed.values.firstOrNull { cleanPath(it.path) == sourcePath }
        } else {
            indexed[o.optString("file_id")]
        } ?: return null

        if (o.has("source_size") && o.optLong("source_size", -1L) != candidate.size) return null

        val expectedSha = o.optString("source_sha256")
        if (expectedSha.isNotBlank() && candidate.sha256.isNotBlank() && expectedSha != candidate.sha256) return null

        val expectedQuick = o.optString("source_quick_hash")
        if (expectedQuick.isNotBlank() && candidate.quickHash.isNotBlank() && expectedQuick != candidate.quickHash) return null

        return candidate
    }

    private fun moveByCopy(root: DocumentFile, e: FileEntry, destination: String) {
        val parts = destination.split("/").filter { it.isNotBlank() }
        if (parts.isEmpty()) error("Destination vide")
        val fileName = safeName(parts.last())
        val dirPath = parts.dropLast(1).joinToString("/")
        val destDir = ensureDir(root, dirPath)
        val existing = destDir.findFile(fileName)
        if (existing != null) error("Destination existe déjà : $destination")

        val mime = e.mime.ifBlank { "application/octet-stream" }
        val created = destDir.createFile(mime, fileName) ?: error("Création impossible : $destination")
        try {
            contentResolver.openInputStream(e.uri)?.use { input ->
                contentResolver.openOutputStream(created.uri)?.use { output ->
                    input.copyTo(output, 1024 * 1024)
                } ?: error("Sortie inaccessible")
            } ?: error("Source inaccessible")

            // Vérification forte avant suppression de la source.
            val copiedHash = sha256(created.uri)
            val sourceHash = if (e.sha256.isNotBlank()) e.sha256 else sha256(e.uri)
            if (copiedHash != sourceHash) {
                created.delete()
                error("Hash différent après copie. Source conservée.")
            }
            val source = DocumentFile.fromSingleUri(this, e.uri) ?: error("Source inaccessible après copie")
            if (!source.delete()) {
                error("Copie vérifiée mais suppression source refusée. Les deux fichiers sont conservés.")
            }
        } catch (ex: Exception) {
            if (created.exists()) {
                val sourceHash = if (e.sha256.isNotBlank()) e.sha256 else sha256(e.uri)
                if (sha256(created.uri) != sourceHash) created.delete()
            }
            throw ex
        }
    }

    private fun ensureDir(root: DocumentFile, rawPath: String): DocumentFile {
        var current = root
        cleanPath(rawPath).split("/").filter { it.isNotBlank() }.forEach { part ->
            val name = safeName(part)
            val found = current.findFile(name)
            current = when {
                found == null -> current.createDirectory(name) ?: error("Impossible de créer $name")
                found.isDirectory -> found
                else -> error("$name existe déjà comme fichier")
            }
        }
        return current
    }

    private fun cleanPath(p: String): String {
        val s = p.replace("\\", "/").trim().trim('/')
        if (s.split("/").any { it == ".." }) error("Chemin interdit")
        return s
    }

    private fun safeName(name: String): String {
        val n = name.trim()
        if (n.isBlank() || n == "." || n == ".." || n.contains("/") || n.contains("\\")) error("Nom invalide")
        return n
    }
}
